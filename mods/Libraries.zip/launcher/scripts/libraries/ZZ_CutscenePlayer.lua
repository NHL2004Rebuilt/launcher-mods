-- ============================================================
-- NHL 2004 Launcher - Cutscene Player Library
--
-- Exposes:
--
-- Launcher.Game.CutscenePlayer()
--
-- Returns the dressed PlayerID (0-39) of the player currently
-- being used by the generic player presentation/cutscene path.
--
-- Reverse-engineered native values at 0x00594AFA:
--
--   EBP          = dressed-player slot (0-19)
--   [ESP+0x150]  = team side (0 or 1)
--
-- PlayerID = slot + (team * 20)
-- ============================================================


Launcher.Game.CutscenePlayerState =
    Launcher.Game.CutscenePlayerState or {}

local State =
    Launcher.Game.CutscenePlayerState

State.Buffer =
    State.Buffer or 0

State.HookASM =
    State.HookASM or 0

State.HookInstalled =
    State.HookInstalled or false

local function FindExistingHook()

    local rel =
        Launcher.Mem.Long(0x00594AFB)

    if rel >= 0x80000000 then
        rel = rel - 0x100000000
    end

    local Target =
        0x00594AFF + rel

    -- Original NHL 2004 call target: no hook installed yet.
    if Target == 0x005E8790 then
        return false
    end

    -- Our helper stores the buffer address as the immediate value
    -- in: mov ecx, BUFFER
    State.HookASM = Target
    State.Buffer =
        Launcher.Mem.Long(Target + 0x0F)

    State.HookInstalled = true

    return true
end


local function InstallCutscenePlayerHook()

    -- First see if another instance of this library
    -- already installed the native hook.
    if FindExistingHook() then
        return true
    end


    State.Buffer =
        Launcher.Mem.Alloc(4)

    if State.Buffer == 0 then
        return false
    end

    Launcher.Mem.WriteLong(
        State.Buffer,
        -1
    )



    local ASM = string.format([[
push eax
push ecx

mov eax,[esp+0x15C]

imul eax,eax,20
add eax,ebp

mov ecx,0x%X
mov [ecx],eax

pop ecx
pop eax

push 0x005E8790
ret
]],
        State.Buffer
    )


    State.HookASM =
        Launcher.Mem.AssembleString(ASM)


    if State.HookASM == 0 then
        return false
    end


    Launcher.Mem.WriteCall(
        0x00594AFA,
        State.HookASM
    )


    State.HookInstalled = true

    return true

end


Launcher.Game.CutscenePlayer = function()

    if State.Buffer == 0 then
        return -1
    end

    local PlayerID = Launcher.Mem.Long(State.Buffer)

    return PlayerID
end



-- Install immediately when the library loads.
InstallCutscenePlayerHook()