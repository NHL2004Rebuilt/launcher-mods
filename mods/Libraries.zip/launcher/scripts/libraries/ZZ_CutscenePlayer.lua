-- ============================================================
-- NHL 2004 Launcher - Cutscene Player Library
--
-- Exposes:
--
--   Launcher.Game.CutscenePlayer()
--
-- Returns the dressed PlayerID (0-39) for the player used by
-- the current player presentation/cutscene path, or -1 when
-- no valid player is available.
--
-- Native sources:
--
--   0x007AD19C
--     Presentation-player value observed to correctly track
--     Exhibition goalie CUT17 and normal player spotlights.
--
--   Hook at 0x00594AFA
--     Original fallback path.
--
-- Reverse-engineered values at 0x00594AFA:
--
--   EBP          = dressed-player slot (0-19)
--   [ESP+0x150]  = team side (0 or 1)
--
--   PlayerID = slot + (team * 20)
--
-- NOTE:
--   Native addresses are build-specific.
-- ============================================================

Launcher.Game.CutscenePlayerState =
    Launcher.Game.CutscenePlayerState or {}

local State = Launcher.Game.CutscenePlayerState

State.Buffer = State.Buffer or 0
State.HookASM = State.HookASM or 0
State.HookInstalled = State.HookInstalled or false

local PRESENTATION_PLAYER_ADDRESS = 0x007AD19C
local ORIGINAL_CALL_ADDRESS = 0x00594AFA
local ORIGINAL_CALL_TARGET = 0x005E8790


local function IsValidPlayerID(PlayerID)
    return PlayerID ~= nil
       and PlayerID >= 0
       and PlayerID <= 39
end


local function FindExistingHook()

    local rel = Launcher.Mem.Long(ORIGINAL_CALL_ADDRESS + 1)

    if rel == nil then
        return false
    end

    if rel >= 0x80000000 then
        rel = rel - 0x100000000
    end

    local Target =
        ORIGINAL_CALL_ADDRESS + 5 + rel

    -- Original NHL 2004 call target: no hook installed yet.
    if Target == ORIGINAL_CALL_TARGET then
        return false
    end

    -- Our helper stores the buffer address as the immediate value
    -- in: mov ecx, BUFFER
    local ExistingBuffer =
        Launcher.Mem.Long(Target + 0x0F)

    if ExistingBuffer == nil or ExistingBuffer == 0 then
        return false
    end

    State.HookASM = Target
    State.Buffer = ExistingBuffer
    State.HookInstalled = true

    return true
end


local function InstallCutscenePlayerHook()

    -- Another copy/instance may already have installed the hook.
    if FindExistingHook() then
        return true
    end

    State.Buffer = Launcher.Mem.Alloc(4)

    if State.Buffer == 0 then
        return false
    end

    Launcher.Mem.WriteLong(State.Buffer, -1)

    local ASM = string.format([[
push eax
push ecx

mov eax,[esp+0x15C]

imul eax,eax,20
add eax,ebp

mov ecx,0x%X
mov [ecx],eax

pop ecx
pop eax

push 0x%X
ret
]],
        State.Buffer,
        ORIGINAL_CALL_TARGET
    )

    State.HookASM =
        Launcher.Mem.AssembleString(ASM)

    if State.HookASM == 0 then
        return false
    end

    Launcher.Mem.WriteCall(
        ORIGINAL_CALL_ADDRESS,
        State.HookASM
    )

    State.HookInstalled = true

    return true
end


Launcher.Game.CutscenePlayer = function()

    -- Preferred presentation-player source.
    --
    -- This is required for Exhibition goalie CUT17, which bypasses
    -- the original 0x00594AFA hook. It has also behaved correctly
    -- during normal player spotlight testing.
    local PlayerID =
        Launcher.Mem.Long(PRESENTATION_PLAYER_ADDRESS)

    if IsValidPlayerID(PlayerID) then
        return PlayerID
    end

    -- Fall back to the original native hook.
    if State.Buffer == 0 then
        return -1
    end

    PlayerID =
        Launcher.Mem.Long(State.Buffer)

    if IsValidPlayerID(PlayerID) then
        return PlayerID
    end

    return -1
end


-- Install immediately when the library loads.
InstallCutscenePlayerHook()
