-- NHL 2004 Launcher - Goalie Season Stats
--
-- Season counting stats are the pregame cumulative totals stored by the game.
-- GAA and Save Percentage are recalculated live during gameplay using:
--   season totals + current-game goalie GA / SA / time
--
-- Public API:
--   Launcher.Player.SeasonGoalieGames(PlayerID)
--   Launcher.Player.SeasonGoalieGoals(PlayerID)
--   Launcher.Player.SeasonGoalieAssists(PlayerID)
--   Launcher.Player.SeasonGoaliePIM(PlayerID)
--   Launcher.Player.SeasonGoalieMinutes(PlayerID)
--   Launcher.Player.SeasonGoalieGoalsAgainst(PlayerID)
--   Launcher.Player.SeasonGoalieShotsAgainst(PlayerID)
--   Launcher.Player.SeasonGoalieSaves(PlayerID)
--   Launcher.Player.SeasonGoalieWins(PlayerID)
--   Launcher.Player.SeasonGoalieLosses(PlayerID)
--   Launcher.Player.SeasonGoalieTies(PlayerID)
--   Launcher.Player.SeasonGoalieShutouts(PlayerID)
--   Launcher.Player.SeasonGoalieGAA(PlayerID)
--   Launcher.Player.SeasonGoalieSavePercentage(PlayerID)
--   Launcher.Player.GameGoalieGoalsAgainst(PlayerID)
--
-- Dressed goalie PlayerIDs:
--   Home: 18 / 19
--   Away: 38 / 39

Launcher.Player = Launcher.Player or {}

local ROOT_PTR = 0x007971C0
local RECORDS_OFFSET = 0x1490
local RECORD_SIZE = 0x20

-- Always-live current-game goalie records for this NHL 2004 build.
-- Current-game Goals Against is BYTE [record + 0x06].
local GAME_GOALIE_RECORDS = {
    [18] = 0x007A97F8,
    [19] = 0x007A980C,
    [38] = 0x007A9988,
    [39] = 0x007A999C,
}

local function ReadU8(Address)
    local Aligned = Address - (Address % 4)
    local Value = Launcher.Mem.Long(Aligned)

    if Value == nil then
        return nil
    end

    if Value < 0 then
        Value = Value + 0x100000000
    end

    local Shift = (Address - Aligned) * 8
    return math.floor(Value / (2 ^ Shift)) % 0x100
end

local function ReadU16(Address)
    local Aligned = Address - (Address % 4)
    local Value = Launcher.Mem.Long(Aligned)

    if Value == nil then
        return nil
    end

    if Value < 0 then
        Value = Value + 0x100000000
    end

    local Shift = (Address - Aligned) * 8
    return math.floor(Value / (2 ^ Shift)) % 0x10000
end

local function ReadU32(Address)
    local Value = Launcher.Mem.Long(Address)

    if Value == nil then
        return nil
    end

    if Value < 0 then
        Value = Value + 0x100000000
    end

    return Value
end

local function IsGoaliePlayerID(PlayerID)
    if type(PlayerID) ~= "number" or PlayerID < 0 or PlayerID > 39 then
        return false
    end

    local Slot = PlayerID % 20
    return Slot == 18 or Slot == 19
end

local function GetStatsObject()
    local Root = Launcher.Mem.Long(ROOT_PTR)

    if Root == nil or Root == 0 then
        return nil
    end

    local RootType = Launcher.Mem.Long(Root)
    local Parent

    if RootType == 1 or RootType == 2 then
        Parent = Launcher.Mem.Long(Root + 0x04)
    elseif RootType == 3 then
        Parent = Launcher.Mem.Long(Root + 0x08)
    else
        return nil
    end

    if Parent == nil or Parent == 0 then
        return nil
    end

    return Parent + 0x24
end

local function GetSeasonGoalieRecord(PlayerID)
    if not IsGoaliePlayerID(PlayerID) then
        return nil
    end

    local StatsObject = GetStatsObject()
    if StatsObject == nil then
        return nil
    end

    local Team = math.floor(PlayerID / 20)
    local Slot = PlayerID % 20
    local Index = Slot + (Team * 2)

    return StatsObject + RECORDS_OFFSET + (Index * RECORD_SIZE)
end

local function ReadSeasonWord(PlayerID, Offset)
    local Record = GetSeasonGoalieRecord(PlayerID)
    if Record == nil then
        return nil
    end

    return ReadU16(Record + Offset)
end

local function ReadSeasonDword(PlayerID, Offset)
    local Record = GetSeasonGoalieRecord(PlayerID)
    if Record == nil then
        return nil
    end

    return ReadU32(Record + Offset)
end

local function CurrentGameGoalsAgainst(PlayerID)
    if not IsGoaliePlayerID(PlayerID) then
        return nil
    end

    local Record = GAME_GOALIE_RECORDS[PlayerID]
    if Record == nil then
        return nil
    end

    return ReadU8(Record + 0x06)
end

local function CurrentGameShotsAgainst(PlayerID)
    if not IsGoaliePlayerID(PlayerID) then
        return nil
    end

    if Launcher.Player.ShotsAgainst == nil then
        return nil
    end

    return Launcher.Player.ShotsAgainst(PlayerID)
end

local function CurrentGameTime(PlayerID)
    if not IsGoaliePlayerID(PlayerID) then
        return nil
    end

    if Launcher.Player.Time == nil then
        return nil
    end

    return Launcher.Player.Time(PlayerID)
end

Launcher.Player.SeasonGoalieGames = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x00)
end

Launcher.Player.SeasonGoalieGoals = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x02)
end

Launcher.Player.SeasonGoalieAssists = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x04)
end

Launcher.Player.SeasonGoaliePIM = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x06)
end

-- +0x08 is the game's goalie Star Points field; intentionally not exposed.

Launcher.Player.SeasonGoalieMinutes = function(PlayerID)
    return ReadSeasonDword(PlayerID, 0x0C)
end

Launcher.Player.SeasonGoalieGoalsAgainst = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x10)
end

Launcher.Player.SeasonGoalieShotsAgainst = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x12)
end

Launcher.Player.SeasonGoalieSaves = function(PlayerID)
    local SA = Launcher.Player.SeasonGoalieShotsAgainst(PlayerID)
    local GA = Launcher.Player.SeasonGoalieGoalsAgainst(PlayerID)

    if SA == nil or GA == nil then
        return nil
    end

    return SA - GA
end

Launcher.Player.SeasonGoalieWins = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x14)
end

Launcher.Player.SeasonGoalieLosses = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x16)
end

Launcher.Player.SeasonGoalieTies = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x18)
end

Launcher.Player.SeasonGoalieShutouts = function(PlayerID)
    return ReadSeasonWord(PlayerID, 0x1A)
end

Launcher.Player.GameGoalieGoalsAgainst = function(PlayerID)
    return CurrentGameGoalsAgainst(PlayerID)
end

Launcher.Player.SeasonGoalieGAA = function(PlayerID)
    local SeasonGA = Launcher.Player.SeasonGoalieGoalsAgainst(PlayerID)
    local SeasonMinutes = Launcher.Player.SeasonGoalieMinutes(PlayerID)

    if SeasonGA == nil or SeasonMinutes == nil then
        return nil
    end

    local GameGA = CurrentGameGoalsAgainst(PlayerID)
    local GameTimeSeconds = CurrentGameTime(PlayerID)

    if GameGA ~= nil and GameTimeSeconds ~= nil then
        local LiveMinutes = SeasonMinutes + (GameTimeSeconds / 60)

        if LiveMinutes <= 0 then
            return 0
        end

        return ((SeasonGA + GameGA) * 60) / LiveMinutes
    end

    if SeasonMinutes <= 0 then
        return 0
    end

    return (SeasonGA * 60) / SeasonMinutes
end

Launcher.Player.SeasonGoalieSavePercentage = function(PlayerID)
    local SeasonSA = Launcher.Player.SeasonGoalieShotsAgainst(PlayerID)
    local SeasonGA = Launcher.Player.SeasonGoalieGoalsAgainst(PlayerID)

    if SeasonSA == nil or SeasonGA == nil then
        return nil
    end

    local GameSA = CurrentGameShotsAgainst(PlayerID)
    local GameGA = CurrentGameGoalsAgainst(PlayerID)

    if GameSA ~= nil and GameGA ~= nil then
        local LiveSA = SeasonSA + GameSA
        local LiveGA = SeasonGA + GameGA

        if LiveSA <= 0 then
            return 0
        end

        return (LiveSA - LiveGA) / LiveSA
    end

    if SeasonSA <= 0 then
        return 0
    end

    return (SeasonSA - SeasonGA) / SeasonSA
end
