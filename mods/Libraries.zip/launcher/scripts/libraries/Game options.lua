--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.GameOption = {}
Launcher.GameOption.PeriodTime = function()
    return ((Launcher.Mem.Long(0x7A9548) >> 2) & 0xf) + 5
end
Launcher.GameOption.OTMode = function()
    return (Launcher.Mem.Long(0x7A9548) >> 0x13) & 7
end