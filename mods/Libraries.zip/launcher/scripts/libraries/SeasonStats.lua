-- ============================================================
-- NHL 2004 Launcher - Season Stats Library
--
-- Reverse-engineered native NHL 2004 season-stat access.
--
-- Exposes:
--
-- Launcher.Player.PregameGoals(PlayerID)
-- Launcher.Player.PregameAssists(PlayerID)
--
-- Launcher.Player.SeasonGoals(PlayerID)
-- Launcher.Player.SeasonAssists(PlayerID)
-- Launcher.Player.SeasonPoints(PlayerID)
--
-- Pregame values = season totals when the game was loaded.
-- Season values  = pregame totals + current-game totals.
--
-- PlayerID:
--     0-19  = Team 0
--     20-39 = Team 1
--
-- Native selectors discovered:
--     3 = Goals
--     4 = Assists
-- ============================================================


local SeasonStats = {}

local GetterASM    = 0
local TeamBuffer   = 0
local SlotBuffer   = 0
local SelectBuffer = 0
local ResultBuffer = 0


-- ============================================================
-- Native getter initialization
-- ============================================================

local function BuildGetter()

    if GetterASM ~= 0 then
        return true
    end


    TeamBuffer   = Launcher.Mem.Alloc(4)
    SlotBuffer   = Launcher.Mem.Alloc(4)
    SelectBuffer = Launcher.Mem.Alloc(4)
    ResultBuffer = Launcher.Mem.Alloc(4)


    if TeamBuffer == 0
    or SlotBuffer == 0
    or SelectBuffer == 0
    or ResultBuffer == 0 then

        return false

    end


    local ASM = string.format([[
pushad

mov ecx,[0x007971C0]

mov eax,0x0046E930
call eax

test eax,eax
jz failed


mov edx,[eax]
mov ecx,eax

call dword [edx+0x2C]

test eax,eax
jz failed


mov ecx,eax

push dword [0x%X]
push 0
push dword [0x%X]
push dword [0x%X]

mov edx,[ecx]
call dword [edx+0x20]


mov ecx,0x%X
mov [ecx],eax

popad
ret


failed:

mov eax,-999

mov ecx,0x%X
mov [ecx],eax

popad
ret
]],
        SelectBuffer,
        SlotBuffer,
        TeamBuffer,
        ResultBuffer,
        ResultBuffer
    )


    GetterASM = Launcher.Mem.AssembleString(ASM)


    if GetterASM == 0 then
        return false
    end


    return true

end



-- ============================================================
-- Convert dressed PlayerID into NHL04 native team/slot values
-- ============================================================

local function DecodePlayerID(PlayerID)

    if PlayerID == nil then
        return nil,nil
    end


    if PlayerID < 0 or PlayerID > 39 then
        return nil,nil
    end


    local Team = 0
    local Slot = PlayerID


    if PlayerID >= 20 then

        Team = 1
        Slot = PlayerID - 20

    end


    return Team,Slot

end



-- ============================================================
-- Raw NHL04 pregame season-stat query
-- ============================================================

local function NativePregameStat(PlayerID,Selector)

    local Team,Slot = DecodePlayerID(PlayerID)


    if Team == nil then
        return -999
    end


    if GetterASM == 0 then

        if not BuildGetter() then
            return -999
        end

    end


    Launcher.Mem.WriteLong(
        TeamBuffer,
        Team
    )


    Launcher.Mem.WriteLong(
        SlotBuffer,
        Slot
    )


    Launcher.Mem.WriteLong(
        SelectBuffer,
        Selector
    )


    Launcher.Mem.WriteLong(
        ResultBuffer,
        -999
    )


    Launcher.Mem.Call(
        GetterASM
    )


    return Launcher.Mem.Long(
        ResultBuffer
    )

end



-- ============================================================
-- Public pregame API
-- ============================================================

Launcher.Player.PregameGoals = function(PlayerID)

    -- Native selector 3
    return NativePregameStat(
        PlayerID,
        3
    )

end



Launcher.Player.PregameAssists = function(PlayerID)

    -- Native selector 4
    return NativePregameStat(
        PlayerID,
        4
    )

end



-- ============================================================
-- Public live season API
-- ============================================================

Launcher.Player.SeasonGoals = function(PlayerID)

    local Pregame =
        Launcher.Player.PregameGoals(
            PlayerID
        )


    if Pregame == -999 then
        return -999
    end


    local Game =
        Launcher.Player.Goals(
            PlayerID
        )


    return Pregame + Game

end



Launcher.Player.SeasonAssists = function(PlayerID)

    local Pregame =
        Launcher.Player.PregameAssists(
            PlayerID
        )


    if Pregame == -999 then
        return -999
    end


    local Game =
        Launcher.Player.Assists(
            PlayerID
        )


    return Pregame + Game

end



Launcher.Player.SeasonPoints = function(PlayerID)

    local Goals =
        Launcher.Player.SeasonGoals(
            PlayerID
        )


    local Assists =
        Launcher.Player.SeasonAssists(
            PlayerID
        )


    if Goals == -999
    or Assists == -999 then

        return -999

    end


    return Goals + Assists

end