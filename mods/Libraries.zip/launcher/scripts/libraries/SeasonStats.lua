-- NHL 2004 Launcher - Season Stats Library v1.1
-- Native player and team season-statistics access for Launcher Lua.
-- Requires Launcher.Player, Launcher.Mem and the supported NHL 2004
-- executable memory layout. Native addresses are build-dependent;
-- maintainers must verify compatibility with their target executable.
--
-- Public API
--
-- Player pregame totals (native season data):
--   Launcher.Player.PregameGoals(PlayerID)
--   Launcher.Player.PregameAssists(PlayerID)
--
-- Player live season totals (pregame + current match):
--   Launcher.Player.SeasonGoals(PlayerID)
--   Launcher.Player.SeasonAssists(PlayerID)
--   Launcher.Player.SeasonPoints(PlayerID)
--
-- Team special teams (native presentation slot 0 or 1):
--   Launcher.Team.PPGoals(slot)
--   Launcher.Team.PPOpportunities(slot)
--   Launcher.Team.PKGoalsAgainst(slot)
--   Launcher.Team.PKOpportunities(slot)
--   Launcher.Team.PPRank(slot)
--   Launcher.Team.PKRank(slot)
--   Launcher.Team.PPPercent(slot)
--   Launcher.Team.PKPercent(slot)
--
-- Team season statistics:
--   Launcher.Team.SeasonStatBySlot(slot, selector)
--   Launcher.Team.SeasonStatsBySlot(slot)
--
-- Additional library members:
--   SeasonStats.TeamStatSelectors
--   SeasonStats.SpecialTeamsSelectors
--   SeasonStats.GetTeamStatBySlot(slot, selector)
--   SeasonStats.GetTeamStatsBySlot(slot)
--   SeasonStats.SetSpecialTeamsGetter(getter)
--
-- Player IDs: 0-19 = team slot 0; 20-39 = team slot 1.
-- Team presentation slots are NOT permanent roster/database team IDs.
-- Player getters and single-value PP/PK getters return -999 on failure.
-- Team SeasonStatBySlot / SeasonStatsBySlot return nil, error on failure.
-- Percentages are expressed as 0-100, not 0-1.
-- The two native getters and their calling conventions are separate.
--
-- Examples (during an active match):
--   local team0 = Launcher.Team.SeasonStatsBySlot(0)
--   local ppRate = Launcher.Team.PPPercent(1)
--   local goals = Launcher.Player.SeasonGoals(0)

local SeasonStats = {}

local GetterASM    = 0
local TeamBuffer   = 0
local SlotBuffer   = 0
local SelectBuffer = 0
local ResultBuffer = 0

-- Native player-statistics getter.
local function BuildGetter()
    if GetterASM ~= 0 then
        return true
    end

    TeamBuffer = Launcher.Mem.Alloc(4)
    SlotBuffer = Launcher.Mem.Alloc(4)
    SelectBuffer = Launcher.Mem.Alloc(4)
    ResultBuffer = Launcher.Mem.Alloc(4)

    if TeamBuffer == 0 or SlotBuffer == 0
    or SelectBuffer == 0 or ResultBuffer == 0 then
        return false
    end

    local ASM = string.format([[
pushad

mov ecx,[0x007971C0]

mov eax,0x0046E930
call eax

test eax,eax
jz failed


mov edx,[eax]
mov ecx,eax

call dword [edx+0x2C]

test eax,eax
jz failed


mov ecx,eax

push dword [0x%X]
push 0
push dword [0x%X]
push dword [0x%X]

mov edx,[ecx]
call dword [edx+0x20]


mov ecx,0x%X
mov [ecx],eax

popad
ret


failed:

mov eax,-999

mov ecx,0x%X
mov [ecx],eax

popad
ret
]],
        SelectBuffer, SlotBuffer, TeamBuffer, ResultBuffer, ResultBuffer)
    GetterASM = Launcher.Mem.AssembleString(ASM)

    if GetterASM == 0 then
        return false
    end
    return true
end

-- Convert a dressed PlayerID to the native team and player slots.
local function DecodePlayerID(PlayerID)
    if PlayerID == nil then
        return nil, nil
    end
    if PlayerID < 0 or PlayerID > 39 then
        return nil, nil
    end

    local Team = 0
    local Slot = PlayerID
    if PlayerID >= 20 then
        Team = 1
        Slot = PlayerID - 20
    end
    return Team, Slot
end

local function NativePregameStat(PlayerID, Selector)
    local Team, Slot = DecodePlayerID(PlayerID)
    if Team == nil then
        return -999
    end

    if GetterASM == 0 then
        if not BuildGetter() then
            return -999
        end
    end

    Launcher.Mem.WriteLong(TeamBuffer, Team)
    Launcher.Mem.WriteLong(SlotBuffer, Slot)
    Launcher.Mem.WriteLong(SelectBuffer, Selector)
    Launcher.Mem.WriteLong(ResultBuffer, -999)
    Launcher.Mem.Call(GetterASM)
    return Launcher.Mem.Long(ResultBuffer)
end

-- Pregame season statistics.
Launcher.Player.PregameGoals = function(PlayerID)
    return NativePregameStat(PlayerID, 3)
end

Launcher.Player.PregameAssists = function(PlayerID)
    return NativePregameStat(PlayerID, 4)
end

-- Live season statistics (pregame totals + current game).
Launcher.Player.SeasonGoals = function(PlayerID)
    local Pregame = Launcher.Player.PregameGoals(PlayerID)
    if Pregame == -999 then
        return -999
    end
    local Game = Launcher.Player.Goals(PlayerID)
    return Pregame + Game
end

Launcher.Player.SeasonAssists = function(PlayerID)
    local Pregame = Launcher.Player.PregameAssists(PlayerID)
    if Pregame == -999 then
        return -999
    end
    local Game = Launcher.Player.Assists(PlayerID)
    return Pregame + Game
end

Launcher.Player.SeasonPoints = function(PlayerID)
    local Goals = Launcher.Player.SeasonGoals(PlayerID)
    local Assists = Launcher.Player.SeasonAssists(PlayerID)
    if Goals == -999 or Assists == -999 then
        return -999
    end
    return Goals + Assists
end

-- Team season statistics: native selector mappings
-- These selectors belong to the native TEAM getter, not the player getter.
-- Home/away losses (0x05, 0x08) include overtime losses.
-- Selectors 0x12, 0x13 and 0x14 are not part of the supported API.

Launcher.Team = Launcher.Team or {}

SeasonStats.TeamStatSelectors = {
    Wins = 0x00,
    Losses = 0x01,
    Ties = 0x02,
    OTLosses = 0x03,
    HomeWins = 0x04,
    HomeLossesIncludingOT = 0x05,
    HomeTies = 0x06,
    AwayWins = 0x07,
    AwayLossesIncludingOT = 0x08,
    AwayTies = 0x09,
    GoalsFor = 0x0A,
    GoalsAgainst = 0x0B,
    PPGoals = 0x0C,
    PPOpportunities = 0x0D,
    SHGoalsFor = 0x0E,
    SHGoalsAgainst = 0x0F,
    PKGoalsAgainst = 0x10,
    PKOpportunities = 0x11,
    PPRank = 0x15,
    PKRank = 0x16
}

-- Preserve the existing PP/PK selector table as a separate public table.
-- Its values are derived from the single authoritative mapping above.
SeasonStats.SpecialTeamsSelectors = {}
for _, key in ipairs({
    'PPGoals', 'PPOpportunities', 'PKGoalsAgainst',
    'PKOpportunities', 'PPRank', 'PKRank'
}) do
    SeasonStats.SpecialTeamsSelectors[key] = SeasonStats.TeamStatSelectors[key]
end

-- Native team-season getter (0x0049E770): resolve the season interface
-- through the manager (+0x2C), then call its virtual method (+0x10).
-- Arguments are pushed as selector, 0, presentation slot (0 or 1).
local TeamGetterASM = 0
local TeamIDBuffer, TeamSelectorBuffer, TeamResultBuffer = 0, 0, 0

local function BuildTeamGetter()
    if TeamGetterASM ~= 0 then return true end
    TeamIDBuffer = Launcher.Mem.Alloc(4)
    TeamSelectorBuffer = Launcher.Mem.Alloc(4)
    TeamResultBuffer = Launcher.Mem.Alloc(4)
    if not TeamIDBuffer or TeamIDBuffer == 0
    or not TeamSelectorBuffer or TeamSelectorBuffer == 0
    or not TeamResultBuffer or TeamResultBuffer == 0 then return false end

    local asm = string.format([[
pushad
mov ecx,[0x007971C0]
test ecx,ecx
jz failed
mov eax,0x0046E930
call eax
test eax,eax
jz failed
mov edx,[eax]
mov ecx,eax
call dword [edx+0x2C]
test eax,eax
jz failed
mov ecx,eax
mov edx,[ecx]
push dword [0x%X]
push 0
push dword [0x%X]
call dword [edx+0x10]
mov [0x%X],eax
popad
ret
failed:
mov dword [0x%X],-999
popad
ret
]], TeamSelectorBuffer, TeamIDBuffer, TeamResultBuffer, TeamResultBuffer)
    TeamGetterASM = Launcher.Mem.AssembleString(asm)
    return TeamGetterASM ~= nil and TeamGetterASM ~= 0
end

local function NativeTeamStat(TeamID, Selector)
    if TeamID ~= 0 and TeamID ~= 1 then return -999 end
    if not BuildTeamGetter() then return -999 end
    Launcher.Mem.WriteLong(TeamIDBuffer, TeamID)
    Launcher.Mem.WriteLong(TeamSelectorBuffer, Selector)
    Launcher.Mem.WriteLong(TeamResultBuffer, -999)
    Launcher.Mem.Call(TeamGetterASM)
    return Launcher.Mem.Long(TeamResultBuffer)
end

-- Optional getter override retained for compatibility.
local SpecialTeamsGetter = NativeTeamStat
SeasonStats.SetSpecialTeamsGetter = function(Getter)
    if Getter ~= nil and type(Getter) ~= "function" then return false end
    SpecialTeamsGetter = Getter or NativeTeamStat
    return true
end

local function TeamStat(TeamID, Selector)
    if type(TeamID) ~= "number" or TeamID ~= math.floor(TeamID)
    or SpecialTeamsGetter == nil then
        return -999
    end
    local value = SpecialTeamsGetter(TeamID, Selector)
    if type(value) ~= "number" then
        return -999
    end
    return value
end

Launcher.Team.PPGoals = function(TeamID)
    return TeamStat(TeamID, SeasonStats.SpecialTeamsSelectors.PPGoals)
end

Launcher.Team.PPOpportunities = function(TeamID)
    return TeamStat(TeamID, SeasonStats.SpecialTeamsSelectors.PPOpportunities)
end

Launcher.Team.PKGoalsAgainst = function(TeamID)
    return TeamStat(TeamID, SeasonStats.SpecialTeamsSelectors.PKGoalsAgainst)
end

Launcher.Team.PKOpportunities = function(TeamID)
    return TeamStat(TeamID, SeasonStats.SpecialTeamsSelectors.PKOpportunities)
end

Launcher.Team.PPRank = function(TeamID)
    return TeamStat(TeamID, SeasonStats.SpecialTeamsSelectors.PPRank)
end

Launcher.Team.PKRank = function(TeamID)
    return TeamStat(TeamID, SeasonStats.SpecialTeamsSelectors.PKRank)
end

Launcher.Team.PPPercent = function(TeamID)
    local goals = Launcher.Team.PPGoals(TeamID)
    local opportunities = Launcher.Team.PPOpportunities(TeamID)
    if goals < 0 or opportunities < 0 then return -999 end
    if opportunities == 0 then return 0 end
    return 100 * goals / opportunities
end

Launcher.Team.PKPercent = function(TeamID)
    local against = Launcher.Team.PKGoalsAgainst(TeamID)
    local opportunities = Launcher.Team.PKOpportunities(TeamID)
    if against < 0 or opportunities < 0 then return -999 end
    if opportunities == 0 then return 0 end
    return 100 * (opportunities - against) / opportunities
end

-- General team season-stat API
-- Reuses the native TeamStat interface above. Indices 0 and 1 are
-- presentation slots, not roster IDs or guaranteed home/away IDs.
-- The source is contextual: Season mode returns active season data;
-- NHL exhibition matches may return historical 2002-03 values.
-- These are team-season totals, not current-match counters.

-- Restrict the raw accessor to documented team selectors.
local PublicTeamSelectors = {}
for _, id in pairs(SeasonStats.TeamStatSelectors) do
    PublicTeamSelectors[id] = true
end

local function ValidPresentationSlot(slot)
    return type(slot) == 'number' and (slot == 0 or slot == 1)
end

-- Returns number or nil,error. Never converts a native zero to 'missing':
-- some records (e.g. DEL exhibition) genuinely return zero for all fields.
-- NativeTeamStat uses -999 as an unavailable-context sentinel.
function SeasonStats.GetTeamStatBySlot(slot, selector)
    if not ValidPresentationSlot(slot) then
        return nil, 'slot must be native presentation slot 0 or 1'
    end
    if not PublicTeamSelectors[selector] then
        return nil, 'unmapped or unsupported selector'
    end
    local ok, value = pcall(TeamStat, slot, selector)
    if not ok then return nil, tostring(value) end
    if type(value) ~= 'number' or value == -999 then
        return nil, 'native team provider unavailable'
    end
    return value
end

-- Returns a snapshot containing raw known fields plus derived statistics.
-- This performs multiple native reads; call on demand, not every frame.
-- nil,error indicates that at least one native read failed. It does NOT
-- claim to detect a missing team when the provider returns all zeroes.
function SeasonStats.GetTeamStatsBySlot(slot)
    if not ValidPresentationSlot(slot) then
        return nil, 'slot must be native presentation slot 0 or 1'
    end

    local record = { slot = slot, source = 'native team presentation context' }
    local fields = {
        {'wins', 'Wins'},
        {'losses', 'Losses'},
        {'ties', 'Ties'},
        {'otLosses', 'OTLosses'},
        {'homeWins', 'HomeWins'},
        {'homeLossesIncludingOT', 'HomeLossesIncludingOT'},
        {'homeTies', 'HomeTies'},
        {'awayWins', 'AwayWins'},
        {'awayLossesIncludingOT', 'AwayLossesIncludingOT'},
        {'awayTies', 'AwayTies'},
        {'goalsFor', 'GoalsFor'},
        {'goalsAgainst', 'GoalsAgainst'},
        {'ppGoals', 'PPGoals'},
        {'ppOpportunities', 'PPOpportunities'},
        {'shGoalsFor', 'SHGoalsFor'},
        {'shGoalsAgainst', 'SHGoalsAgainst'},
        {'pkGoalsAgainst', 'PKGoalsAgainst'},
        {'pkOpportunities', 'PKOpportunities'},
        {'ppRank', 'PPRank'},
        {'pkRank', 'PKRank'}
    }

    for _, field in ipairs(fields) do
        local value, err = SeasonStats.GetTeamStatBySlot(slot,
            SeasonStats.TeamStatSelectors[field[2]])
        if value == nil then
            return nil, string.format('failed reading %s: %s',
                field[1], tostring(err))
        end
        record[field[1]] = value
    end

    record.gamesPlayed = record.wins + record.losses + record.ties
        + record.otLosses
    record.points = 2 * record.wins + record.ties + record.otLosses
    record.goalDifferential = record.goalsFor - record.goalsAgainst
    record.homeGamesPlayed = record.homeWins
        + record.homeLossesIncludingOT + record.homeTies
    record.awayGamesPlayed = record.awayWins
        + record.awayLossesIncludingOT + record.awayTies

    -- Percentages are percentages, NOT fractions (20.3 = 20.3%).
    record.ppPercent = record.ppOpportunities > 0
        and (100 * record.ppGoals / record.ppOpportunities) or 0
    record.pkPercent = record.pkOpportunities > 0
        and (100 * (record.pkOpportunities - record.pkGoalsAgainst)
            / record.pkOpportunities) or 0
    return record
end

-- Launcher-facing aliases for the complete team-season API.
Launcher.Team.SeasonStatBySlot = SeasonStats.GetTeamStatBySlot
Launcher.Team.SeasonStatsBySlot = SeasonStats.GetTeamStatsBySlot

-- Return the library table for scripts that use dofile/loadfile.
return SeasonStats
