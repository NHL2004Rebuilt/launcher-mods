-- drgullen's StatClock - v3.0.1 - released June 9, 2026
-- Starting Values
assists = {}
for loopcount=0, 39 do
	assists[loopcount] = 0
end
AwayGoalsX = 423
AwayHardestShots = 0
AwayIcings = 0
AwayOffsides = 0
AwayOffZone = 0
AwayPenalty1 = 0
AwayPenalty1Time = 0
AwayPenalty1DoubleMinor = 0
AwayPenalty1Major = 0
AwayPenalty2 = 0
AwayPenalty2Time = 0
AwayPenalty2DoubleMinor = 0
AwayPenalty2Major = 0
AwayPenalty3 = 0
AwayPenalty3Time = 0
AwayPenalty3DoubleMinor = 0
AwayPenalty3Major = 0
AwayPeriodAttempts = 0
AwayPeriodShots = 0
AwayPoss = 0
AwayPPShots = 0
AwayScoringChances = 0
ClockMessage = " "
CountSinceSOG = 0
CountSincePeriodSOG = 0
CountSincePlayerStat = 0
CurrentPenalty = 0
CurrentTime = 0
EmptyNetFlag = 0
FontColor1 = 0xee000000
FontColor2 = 0xeee0e0e0
FontColor3 = 0xeee0e0e0
FontFamily = "Galafera Med"
FontSize = 50
FontSize2 = 60
FontSize3 = 25
FontSize4 = 30
FontSize5 = 50
FontSize6 = 24
FontWeight = 760
FontWeight2 = 730
FouronFourActive = 0
FouronFourTime = 0
FullStrengthFlag = 0
FullStrengthTimer = 0
GameOver = 0
GoalCheck = 0
GoalChecked = 0
goals = {}
for loopcount=0, 39 do
	goals[loopcount] = 0
end
GoalJustScored = 0
HomeGoalsX = 687
HomeHardestShots = 0
HomeIcings = 0
HomeOffsides = 0
HomeOffZone = 0
HomePenalty1 = 0
HomePenalty1Time = 0
HomePenalty1DoubleMinor = 0
HomePenalty1Major = 0
HomePenalty2 = 0
HomePenalty2Time = 0
HomePenalty2DoubleMinor = 0
HomePenalty2Major = 0
HomePenalty3 = 0
HomePenalty3Time = 0
HomePenalty3DoubleMinor = 0
HomePenalty3Major = 0
HomePeriodAttempts = 0
HomePeriodShots = 0
HomePoss = 0
HomePPShots = 0
HomeScoringChances = 0
HybridOT = Launcher.Config.Bool("hybridot",false)
LastStat = 0
Launcher.Override.DisableOverlay()
MessageTimerOn = 9999
NativeResolutionX = 1920 
NativeResolutionY = 1080
NativeResolutionAspect = NativeResolutionY/NativeResolutionX
PauseRandomizer = 0
PauseSprite = 0
PenaltyPending = 0
PlayStoppedPeriod = 0
PowerPlayTime = 0
PowerPlayTeam = -1
PowerUpFlag = 0
PowerUpGoals = 0
PowerUpSound = Launcher.Config.Bool("powerupsound",true)
PPSpriteActive = 0
PreviousPenalty = 0
RandomStat = 0
ScoreDiff = 0
SetStat = 1
SetupOT = 0
ShowClock = 2
ShotSpeed = 0
ShotSpeedNumber = 0
ShowDelayed = 0
ShowPPStat = 0
ShowSprites = 2
SpriteinEffect = 0
SurfaceSprite = 0
ThreeonThreeActive = 0
ThreeonThreeTime = 0
TimeX = 745
TotalAwayPenalties = 0
TotalAwayShots = 0
TotalHomePenalties = 0
TotalHomeShots = 0
TrackShots = 0
UseSmallDisplay = 0
-- Functions
function CutsceneStartedCallback()
-- This resets certain values prior to each face-off
	ClockMessage = "STATCLOCK v3.0.0"
	EmptyNetFlag = 0
	UseSmallDisplay = 0
	AltClockTime = Launcher.Game.Time()
	if ShowPPStat == 3 then
		ShowPPStat = 0
	elseif ShowPPStat == 1 then
		ShowPPStat = 2
	end
	if ShowClock == 2 or AltClockTime < 10 then
		SetStat = 1
	elseif PenaltyPending == 1 then
		SetStat = 0
 	elseif PowerPlayTime > 0 then
 		SetStat = 1
	else
		SetStat = 0
	end
-- This forces the appropriate "FINAL" message to appear on the clock
	if Launcher.Game.Period() == 3 and Launcher.Game.Time() == 0 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
		GameOver = 1
	elseif Launcher.Game.Period() == 4 and Launcher.Game.Time() == 0 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
		GameOver = 1
	elseif Launcher.Game.Period() == 4 and Launcher.Game.Time() == 0 and Launcher.GameOption.OTMode() > 2 then
		GameOver = 2
	elseif Launcher.Game.Period() > 3 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
		GameOver = 2
	end
	if PlayStoppedPeriod == 1 or GameOver > 0 then
		SpriteinEffect = 0
	end
end
function CutsceneStoppedCallback()
-- This prepares for any unusual clock display situations (i.e. 5-on-3, 4-on-4, etc)
	ShowDelayed = 0
	if Launcher.Game.PenaltyPending() and GoalCheck == Launcher.Stats.HomeGoals() + Launcher.Stats.AwayGoals() then
		if Launcher.Mem.Byte(0x79b41e) ~= 33 and Launcher.Mem.Byte(0x79b41e) ~= 38 and Launcher.Mem.Byte(0x79b41f) ~= 16 then
			CurrentTime = Launcher.Game.Time()
			if Launcher.Mem.Byte(0x79b41c) == 0 then
				if HomePenalty1 == 0 then
					HomePenalty1 = 1
					if Launcher.Mem.Byte(0x79b41f) == 8 then
						HomePenalty1Time = CurrentTime - 300
						HomePenalty1Major = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 4 then
						HomePenalty1Time = CurrentTime - 240
						HomePenalty1DoubleMinor = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 2 then
						HomePenalty1Time = CurrentTime - 120
					end
				elseif HomePenalty2 == 0 then
					HomePenalty2 = 1
					if Launcher.Mem.Byte(0x79b41f) == 8 then
						HomePenalty2Time = CurrentTime - 300
						HomePenalty2Major = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 4 then
						HomePenalty2Time = CurrentTime - 240
						HomePenalty2DoubleMinor = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 2 then
						HomePenalty2Time = CurrentTime - 120
					end
				else
					HomePenalty3 = 1
					if Launcher.Mem.Byte(0x79b41f) == 8 then
						HomePenalty3Time = CurrentTime - 300
						HomePenalty3Major = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 4 then
						HomePenalty3Time = CurrentTime - 240
						HomePenalty3DoubleMinor = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 2 then
						HomePenalty3Time = CurrentTime - 120
					end
				end
			else
				if AwayPenalty1 == 0 then
					AwayPenalty1 = 1
					if Launcher.Mem.Byte(0x79b41f) == 8 then
						AwayPenalty1Time = CurrentTime - 300
						AwayPenalty1Major = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 4 then
						AwayPenalty1Time = CurrentTime - 240
						AwayPenalty1DoubleMinor = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 2 then
						AwayPenalty1Time = CurrentTime - 120
					end
				elseif AwayPenalty2 == 0 then
					AwayPenalty2 = 1
					if Launcher.Mem.Byte(0x79b41f) == 8 then
						AwayPenalty2Time = CurrentTime - 300
						AwayPenalty2Major = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 4 then
						AwayPenalty2Time = CurrentTime - 240
						AwayPenalty2DoubleMinor = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 2 then
						AwayPenalty2Time = CurrentTime - 120
					end
				else
					AwayPenalty3 = 1
					if Launcher.Mem.Byte(0x79b41f) == 8 then
						AwayPenalty3Time = CurrentTime - 300
						AwayPenalty3Major = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 4 then
						AwayPenalty3Time = CurrentTime - 240
						AwayPenalty3DoubleMinor = 1
					elseif Launcher.Mem.Byte(0x79b41f) == 2 then
						AwayPenalty3Time = CurrentTime - 120
					end
				end
			end
		end
		TotalAwayPenalties = AwayPenalty1 + AwayPenalty2 + AwayPenalty3
		TotalHomePenalties = HomePenalty1 + HomePenalty2 + HomePenalty3
		if (TotalHomePenalties == 3 and TotalAwayPenalties == 3) or (TotalHomePenalties >= 2 and TotalAwayPenalties >= 2) then
			PPSpriteActive = 0
			ThreeonThreeTime = 0
			if AwayPenalty1Time > ThreeonThreeTime then
				ThreeonThreeTime = AwayPenalty1Time
			end
			if AwayPenalty2Time > ThreeonThreeTime then
				ThreeonThreeTime = AwayPenalty2Time
			end
			if AwayPenalty3Time > ThreeonThreeTime then
				ThreeonThreeTime = AwayPenalty3Time
			end
			if HomePenalty1Time > ThreeonThreeTime then
				ThreeonThreeTime = HomePenalty1Time
			end
			if HomePenalty2Time > ThreeonThreeTime then
				ThreeonThreeTime = HomePenalty2Time
			end
			if HomePenalty3Time > ThreeonThreeTime then
				ThreeonThreeTime = HomePenalty3Time
			end
			ThreeonThreeTime = CurrentTime - ThreeonThreeTime
		end
		if TotalHomePenalties == 1 and TotalAwayPenalties == 1 then
			PPSpriteActive = 0
			FouronFourTime = 0
			if AwayPenalty1Time > FouronFourTime then
				FouronFourTime = AwayPenalty1Time
			end
			if AwayPenalty2Time > FouronFourTime then
				FouronFourTime = AwayPenalty2Time
			end
			if AwayPenalty3Time > FouronFourTime then
				FouronFourTime = AwayPenalty3Time
			end
			if HomePenalty1Time > FouronFourTime then
				FouronFourTime = HomePenalty1Time
			end
			if HomePenalty2Time > FouronFourTime then
				FouronFourTime = HomePenalty2Time
			end
			if HomePenalty3Time > FouronFourTime then
				FouronFourTime = HomePenalty3Time
			end
			FouronFourTime = CurrentTime - FouronFourTime
		end
		if PowerUpSound == true and TotalHomePenalties == 1 and PowerUpFlag == 0 then
			PowerUpFlag = 1
			PowerUpGoals = Launcher.Stats.AwayGoals()
		end
	else
		GoalChecked = 0
		PenaltyPending = 0
	end
end
function DeviceCreatedCallback()
	LoadAssets()
end
function FaceOffStartedCallback()
-- This resets the "Full Strength" sprite if it was already showing when the whistle blew
	if (TotalAwayPenalties + TotalHomePenalties == 0) and FullStrengthFlag > 0 then
		FullStrengthFlag = 0
		FullStrengthTimer = 0
	end
end
function LoadAssets()
-- Audio
	PowerUp = Launcher.Sound.Load("launcher/media/audio/powerup.mp3",true)
-- Font
	FontStatClock = Launcher.Font.AddFile("launcher/media/fonts/GalaferaMedium-V4xze.ttf")
-- Sprites
    IcingSprite = Launcher.Sprite.Load("launcher/media/textures/icing.png")
    OffsideSprite = Launcher.Sprite.Load("launcher/media/textures/offside.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/pause.jpg")
	DelayedSprite = Launcher.Sprite.Load("launcher/media/textures/delayed.png")
	PenaltySprite = Launcher.Sprite.Load("launcher/media/textures/penalty.png")
	PowerPlaySprite = Launcher.Sprite.Load("launcher/media/textures/pp.png")
	FiveonThreeSprite = Launcher.Sprite.Load("launcher/media/textures/fiveonthree.png")
	FouronThreeSprite = Launcher.Sprite.Load("launcher/media/textures/fouronthree.png")
	FouronFourSprite = Launcher.Sprite.Load("launcher/media/textures/fouronfour.png")
	ThreeonThreeSprite = Launcher.Sprite.Load("launcher/media/textures/threeonthree.png")
	EmptyNetSprite = Launcher.Sprite.Load("launcher/media/textures/emptynet.png")
	FullStrengthSprite = Launcher.Sprite.Load("launcher/media/textures/full.png")
	SurfaceSprite = Launcher.Sprite.Create(NativeResolutionX, NativeResolutionY,1)
-- Other Assets
    local Width, Height
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    AwayPog = Launcher.Sprite.Load("launcher/media/textures/logos/"..AwayAbbreviation..".png")
	if AwayPog == nil then
		AwayPog = Launcher.Sprite.Load("launcher/media/textures/logos/error.png")
	end
    ClockFont = Launcher.Font.Load(FontFamily,FontSize,FontWeight)
	ClockFontMessage = Launcher.Font.Load(FontFamily,FontSize4,FontWeight)
	ClockFontMessageSmall = Launcher.Font.Load(FontFamily,FontSize6,FontWeight)
	ClockFontPP = Launcher.Font.Load(FontFamily,FontSize3,FontWeight)
	ClockFontPPDisplay = Launcher.Font.Load(FontFamily,FontSize5,FontWeight)
	ClockFontS = Launcher.Font.Load(FontFamily,FontSize2,FontWeight2)
    ClockSprite = Launcher.Sprite.Load("launcher/media/textures/clock.png")
    ClockX = 448
    ClockY = 0
    Height = Launcher.Sprite.Height(PauseSprite)
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    HomePog = Launcher.Sprite.Load("launcher/media/textures/logos/"..HomeAbbreviation..".png")
	if HomePog == nil then
		HomePog = Launcher.Sprite.Load("launcher/media/textures/logos/error.png")
	end
    Width = Launcher.Sprite.Width(PauseSprite)
-- Setting Screen Scale
    Launcher.Sprite.Scale(PauseSprite,(Launcher.Screen.Height()*(Width/Height))/Width,Launcher.Screen.Height()/Height)
	Launcher.Sprite.Scale(SurfaceSprite,Launcher.Screen.Width()/NativeResolutionX, (Launcher.Screen.Width()*NativeResolutionAspect)/NativeResolutionY)
end
function PausedCallback()
-- This resets to a default clock while the game is paused
	MessageTimerOn = 9999
end
function PenaltyCallback()
-- This keeps track of shots taken during Power Plays
	TrackHomeShots = Launcher.Stats.HomeShots()
	TrackAwayShots = Launcher.Stats.AwayShots()
end
function PeriodStartedCallback()
-- These values are reset to start each new period
	math.randomseed(os.time())
	CountSincePeriodSOG = 0
	IcinginEffect = 0
	OffsidesinEffect = 0
	PlayStoppedPeriod = 0
	ShowClock = 2
	AwayPeriodShots = Launcher.Stats.AwayShots()
	HomePeriodShots = Launcher.Stats.HomeShots()
	AwayPeriodAttempts = TotalAwayShots
	HomePeriodAttempts = TotalHomeShots
	CurrentTime = Launcher.Game.Time()
end
function PlayStoppedCallback(Reason)
-- This resets penalty tracker timers for penalties overlapping into the next period
	if PenaltyPending == 1 then
		ShowSprites = 2
	end
	if Reason == LauncherPlayStoppedPeriod and Launcher.Game.Period() == 3 and (Launcher.GameOption.OTMode() == 3 or Launcher.GameOption.OTMode() == 4) then
		PlayStoppedPeriod = 1
		if AwayPenalty1Time < 0 then
			AwayPenalty1 = 1
			AwayPenalty1Time = AwayPenalty1Time + 300
		end
		if AwayPenalty2Time < 0 then
			AwayPenalty2 = 1
			AwayPenalty2Time = AwayPenalty2Time + 300
		end
		if AwayPenalty3Time < 0 then
			AwayPenalty3 = 1
			AwayPenalty3Time = AwayPenalty3Time + 300
		end
		if HomePenalty1Time < 0 then
			HomePenalty1 = 1
			HomePenalty1Time = HomePenalty1Time + 300
		end
		if HomePenalty2Time < 0 then
			HomePenalty2 = 1
			HomePenalty2Time = HomePenalty2Time + 300
		end
		if HomePenalty3Time < 0 then
			HomePenalty3 = 1
			HomePenalty3Time = HomePenalty3Time + 300
		end
	elseif Reason == LauncherPlayStoppedPeriod then
		PlayStoppedPeriod = 1
		if AwayPenalty1Time < 0 then
			AwayPenalty1 = 1
			AwayPenalty1Time = AwayPenalty1Time + 1200
		end
		if AwayPenalty2Time < 0 then
			AwayPenalty2 = 1
			AwayPenalty2Time = AwayPenalty2Time + 1200
		end
		if AwayPenalty3Time < 0 then
			AwayPenalty3 = 1
			AwayPenalty3Time = AwayPenalty3Time + 1200
		end
		if HomePenalty1Time < 0 then
			HomePenalty1 = 1
			HomePenalty1Time = HomePenalty1Time + 1200
		end
		if HomePenalty2Time < 0 then
			HomePenalty2 = 1
			HomePenalty2Time = HomePenalty2Time + 1200
		end
		if HomePenalty3Time < 0 then
			HomePenalty3 = 1
			HomePenalty3Time = HomePenalty3Time + 1200
		end
	end
-- This decides what the random background will be when the game is paused
	SpriteinEffect = 1
	PausePic = math.random (1,20)
	if PausePic == 1 then
		PauseSprite = Launcher.Sprite.Load("launcher/media/textures/pause.jpg")
	else
		PauseSprite = Launcher.Sprite.Load("launcher/media/textures/pause" .. PausePic .. ".jpg")
	end
-- This resets certain display situations
	GoalJustScored = 0
	MessageTimerOn = 9999
	CountSinceSOG = CountSinceSOG + 1
	CountSincePeriodSOG = CountSincePeriodSOG + 1
	CountSincePlayerStat = CountSincePlayerStat + 1
	if PenaltyPending == 5 and PowerPlayTime == 0 then
		PenaltyPending = 0
	end
-- This keeps track of icings
	if Reason == LauncherPlayStoppedIcing then
		if Launcher.Game.TeamWithPuck() == 0 then
			HomeIcings = HomeIcings + 1
		else
			AwayIcings = AwayIcings + 1
		end
	end
-- This keeps track of offsides
	if Reason == LauncherPlayStoppedOffside then
		if Launcher.Game.TeamWithPuck() == 0 then
			HomeOffsides = HomeOffsides + 1
		else
			AwayOffsides = AwayOffsides + 1
		end
	end
-- This logs all goals and assists to use for displays later
	if Reason == LauncherPlayStoppedGoalHome or Reason == LauncherPlayStoppedGoalAway then
		GoalJustScored = 1
		TOG = 1200 - Launcher.Game.Time()
		TOGMinutes = math.floor(TOG/60)
		if TOGMinutes == 0 then
			TOGMinutes = ""
		end
		TOGSeconds = TOG % 60
		if TOGSeconds < 10 then
			TOGSeconds = "0"..TOGSeconds
		end
		TimeofGoal = TOGMinutes .. ":" .. TOGSeconds
		for loopcount=0, 39 do
			if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
				if Launcher.Player.Goals(loopcount) ~= goals [loopcount] then
					GoalScorerID = loopcount
					goals [loopcount] =	goals [loopcount] + 1
				end
			end
		end
		Assist1ID = -1
		for loopcount=0, 39 do
			if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
				if Launcher.Player.Assists(loopcount) ~= assists [loopcount] then		
					Assist1ID = loopcount
					assists [loopcount] = assists [loopcount] + 1
					break
				end
			end
		end
		Assist2ID = -1
		if Assist1ID ~= -1 then
			for loopcount=0, 39 do
				if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
					if Launcher.Player.Assists(loopcount) ~= assists [loopcount] then		
						Assist2ID = loopcount
						assists [loopcount] = assists [loopcount] + 1
						break
					end
				end
			end
		end
	end
-- This updates the penalty trackers based on goals being scored
	if Reason == LauncherPlayStoppedGoalHome and ThreeonThreeActive == 0 and FouronFourActive == 0 then
		if AwayPenalty1 == 1 and AwayPenalty1DoubleMinor == 1 and CurrentTime > (AwayPenalty1Time + 120) then
			AwayPenalty1Time = CurrentTime - 120
			AwayPenalty1DoubleMinor = 0
		elseif AwayPenalty1 == 1 and AwayPenalty1Major == 0 then
			AwayPenalty1 = 0
			AwayPenalty1Time = 0
			AwayPenalty1DoubleMinor = 0
			AwayPenalty1Major = 0
		elseif AwayPenalty2 == 1 and AwayPenalty2DoubleMinor == 1 and CurrentTime > (AwayPenalty2Time + 120) then
			AwayPenalty2Time = CurrentTime - 120
		elseif AwayPenalty2Time < 0 and AwayPenalty2DoubleMinor == 1 and Launcher.Game.Time() < 120 then
			AwayPenalty2Time = 120
			AwayPenalty2DoubleMinor = 0
		elseif AwayPenalty2 == 1 and AwayPenalty2Major == 0 then
			AwayPenalty2 = 0
			AwayPenalty2Time = 0
			AwayPenalty2DoubleMinor = 0
			AwayPenalty2Major = 0
		elseif AwayPenalty3 == 1 and AwayPenalty3DoubleMinor == 1 and CurrentTime > (AwayPenalty3Time + 120) then
			AwayPenalty3Time = CurrentTime - 120
		elseif AwayPenalty3Time < 0 and AwayPenalty3DoubleMinor == 1 and Launcher.Game.Time() < 120 then
			AwayPenalty3Time = 120
			AwayPenalty3DoubleMinor = 0
		elseif AwayPenalty3 == 1 and AwayPenalty3Major == 0 then
			AwayPenalty3 = 0
			AwayPenalty3Time = 0
			AwayPenalty3DoubleMinor = 0
			AwayPenalty3Major = 0
		end
	elseif Reason == LauncherPlayStoppedGoalAway and ThreeonThreeActive == 0 and FouronFourActive == 0 then
		if HomePenalty1 == 1 and HomePenalty1DoubleMinor == 1 and CurrentTime > (HomePenalty1Time + 120) then
			HomePenalty1Time = CurrentTime - 120
			HomePenalty1DoubleMinor = 0
		elseif HomePenalty1 == 1 and HomePenalty1Major == 0 then
			HomePenalty1 = 0
			HomePenalty1Time = 0
			HomePenalty1DoubleMinor = 0
			HomePenalty1Major = 0
		elseif HomePenalty2 == 1 and HomePenalty2DoubleMinor == 1 and CurrentTime > (HomePenalty2Time + 120) then
			HomePenalty2Time = CurrentTime - 120
		elseif HomePenalty2Time < 0 and HomePenalty2DoubleMinor == 1 and Launcher.Game.Time() < 120 then
			HomePenalty2Time = 120
			HomePenalty2DoubleMinor = 0
		elseif HomePenalty2 == 1 and HomePenalty2Major == 0 then
			HomePenalty2 = 0
			HomePenalty2Time = 0
			HomePenalty2DoubleMinor = 0
			HomePenalty2Major = 0
		elseif HomePenalty3 == 1 and HomePenalty3DoubleMinor == 1 and CurrentTime > (HomePenalty3Time + 120) then
			HomePenalty3Time = CurrentTime - 120
		elseif HomePenalty3Time < 0 and HomePenalty3DoubleMinor == 1 and Launcher.Game.Time() < 120 then
			HomePenalty3Time = 120
			HomePenalty3DoubleMinor = 0
		elseif HomePenalty3 == 1 and HomePenalty3Major == 0 then
			HomePenalty3 = 0
			HomePenalty3Time = 0
			HomePenalty3DoubleMinor = 0
			HomePenalty3Major = 0
		end
	end
	if Reason == LauncherPlayStoppedGoalAway or Reason == LauncherPlayStoppedGoalHome or Reason == LauncherPlayStoppedPeriod then
		CurrentTime = Launcher.Game.Time()
		TotalAwayPenalties = AwayPenalty1 + AwayPenalty2 + AwayPenalty3
		TotalHomePenalties = HomePenalty1 + HomePenalty2 + HomePenalty3

		if (TotalHomePenalties == 3 and TotalAwayPenalties == 3) or (TotalHomePenalties >= 2 and TotalAwayPenalties >= 2) then
			PPSpriteActive = 0
			ThreeonThreeTime = 0
			if AwayPenalty1Time > ThreeonThreeTime then
				ThreeonThreeTime = AwayPenalty1Time
			end
			if AwayPenalty2Time > ThreeonThreeTime then
				ThreeonThreeTime = AwayPenalty2Time
			end
			if AwayPenalty3Time > ThreeonThreeTime then
				ThreeonThreeTime = AwayPenalty3Time
			end
			if HomePenalty1Time > ThreeonThreeTime then
				ThreeonThreeTime = HomePenalty1Time
			end
			if HomePenalty2Time > ThreeonThreeTime then
				ThreeonThreeTime = HomePenalty2Time
			end
			if HomePenalty3Time > ThreeonThreeTime then
				ThreeonThreeTime = HomePenalty3Time
			end
			ThreeonThreeTime = CurrentTime - ThreeonThreeTime
		end
		if TotalHomePenalties == 1 and TotalAwayPenalties == 1 then
			PPSpriteActive = 0
			FouronFourTime = 0
			if AwayPenalty1Time > FouronFourTime then
				FouronFourTime = AwayPenalty1Time
			end
			if AwayPenalty2Time > FouronFourTime then
				FouronFourTime = AwayPenalty2Time
			end
			if AwayPenalty3Time > FouronFourTime then
				FouronFourTime = AwayPenalty3Time
			end
			if HomePenalty1Time > FouronFourTime then
				FouronFourTime = HomePenalty1Time
			end
			if HomePenalty2Time > FouronFourTime then
				FouronFourTime = HomePenalty2Time
			end
			if HomePenalty3Time > FouronFourTime then
				FouronFourTime = HomePenalty3Time
			end
			FouronFourTime = CurrentTime - FouronFourTime
		end
	end
-- This resets any penalty tracker that expired at the same time as the period expired
	if Reason == LauncherPlayStoppedPeriod then
		if AwayPenalty1Time == 0 then
			AwayPenalty1 = 0
			AwayPenalty1DoubleMinor = 0
			AwayPenalty1Major = 0
		end
		if AwayPenalty2Time == 0 then
			AwayPenalty2 = 0
			AwayPenalty2DoubleMinor = 0
			AwayPenalty2Major = 0
		end
		if AwayPenalty3Time == 0 then
			AwayPenalty3 = 0
			AwayPenalty3DoubleMinor = 0
			AwayPenalty3Major = 0
		end
		if HomePenalty1Time == 0 then
			HomePenalty1 = 0
			HomePenalty1DoubleMinor = 0
			HomePenalty1Major = 0
		end
		if HomePenalty2Time == 0 then
			HomePenalty2 = 0
			HomePenalty2DoubleMinor = 0
			HomePenalty2Major = 0
		end
		if HomePenalty3Time == 0 then
			HomePenalty3 = 0
			HomePenalty3DoubleMinor = 0
			HomePenalty3Major = 0
		end
	end
	TotalAwayPenalties = AwayPenalty1 + AwayPenalty2 + AwayPenalty3
	TotalHomePenalties = HomePenalty1 + HomePenalty2 + HomePenalty3
end
function ReloadedCallback()
	LoadAssets()
end
function RenderCallback()
	local X, Y
-- This triggers when and when not to show the clock
	if Launcher.Game.IsShootout() or Launcher.Game.InReplay() then
		return
	elseif Launcher.Game.Paused() then
		if SpriteinEffect == 1 then
			X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(PauseSprite)*0.5
			Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(PauseSprite)*0.5
			Launcher.Sprite.Draw(PauseSprite,X,Y)
			if GameOver == 0 and PlayStoppedPeriod == 0 then
				Launcher.Sprite.Clip(ClockSprite,0,0,1024,128)
				Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)
				Launcher.Sprite.Draw(HomePog, ClockX+414, ClockY)
				Launcher.Sprite.Draw(AwayPog, ClockX+150, ClockY)
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,Period.."   "..Minutes..":"..Seconds,ClockX + TimeX - 48,ClockY + 23,FontColor2)
			end
			return
		end
	end
	if (not Launcher.Game.InCutscene()) and Launcher.Game.IsFighting() == false then
		Launcher.Sprite.Draw(SurfaceSprite,0,0) 
	end
end
function ShotAwayCallback()
	GoalJustScored = 0
-- This keeps track of all total shot attempts made by the visiting team (on goal, blocked and missed)
	TotalAwayShots = TotalAwayShots + 1
	x, y, z = Launcher.Game.PuckPosition()
	if (x > -256 and x < 256) and (z < -3450 or z > 3450) then
		AwayScoringChances = AwayScoringChances + 1
	end
	if Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3 or Launcher.Game.Period() == 4 then
		if z < 0 and Launcher.Game.TeamWithPuck() == 1 then
			TotalAwayShots = TotalAwayShots - 1
		elseif Launcher.Game.PuckZone() == 1 then
			ShotSpeedNumber = tonumber(string.sub(Launcher.Game.ShotSpeed(),1,2))
			if ShotSpeedNumber > AwayHardestShots then
				AwayHardestShots = ShotSpeedNumber
			end
			if ShotSpeedNumber > 90 and PowerPlayTime == 0 then
				ShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
			end
		end
	elseif Launcher.Game.Period() == 2 then
		if z > 0 and Launcher.Game.TeamWithPuck() == 1 then
			TotalAwayShots = TotalAwayShots - 1
		elseif Launcher.Game.PuckZone() == -1 then
			ShotSpeedNumber = tonumber(string.sub(Launcher.Game.ShotSpeed(),1,2))
			if ShotSpeedNumber > AwayHardestShots then
				AwayHardestShots = ShotSpeedNumber
			end
			if ShotSpeedNumber > 90 and PowerPlayTime == 0 then
				ShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
			end

		end
	end
end
function ShotHomeCallback()
	GoalJustScored = 0
-- This keeps track of all total shot attempts made by the home team (on goal, blocked and missed)
	TotalHomeShots = TotalHomeShots + 1
	x, y, z = Launcher.Game.PuckPosition()
	if (x > -500 and x < 500) and (z < -3450 or z > 3450) then
		HomeScoringChances = HomeScoringChances + 1
	end
	if Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3 or Launcher.Game.Period() == 4 then
		if z > 0 and Launcher.Game.TeamWithPuck() == 0 then
			TotalHomeShots = TotalHomeShots - 1
		elseif Launcher.Game.PuckZone() == -1 then
			ShotSpeedNumber = tonumber(string.sub(Launcher.Game.ShotSpeed(),1,2))
			if ShotSpeedNumber > HomeHardestShots then
				HomeHardestShots = ShotSpeedNumber
			end
			if ShotSpeedNumber > 90 and PowerPlayTime == 0 then
				ShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
			end
		end
	elseif Launcher.Game.Period() == 2 then
		if z < 0 and Launcher.Game.TeamWithPuck() == 0 then
			TotalHomeShots = TotalHomeShots - 1
		elseif Launcher.Game.PuckZone() == 1 then
			ShotSpeedNumber = tonumber(string.sub(Launcher.Game.ShotSpeed(),1,2))
			if ShotSpeedNumber > HomeHardestShots then
				HomeHardestShots = ShotSpeedNumber
			end
			if ShotSpeedNumber > 90 and PowerPlayTime == 0 then
				ShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
			end
		end
	end
end
function TickCallback()
-- This keeps track of the penalty timers
	Time = Launcher.Game.Time()
	if Time > 0.0 then
		if Time < HomePenalty3Time then
			HomePenalty3 = 0
			HomePenalty3DoubleMinor = 0
			HomePenalty3Major = 0
			HomePenalty3Time = 0
		end
		if Time < HomePenalty2Time then
			HomePenalty2 = 0
			HomePenalty2DoubleMinor = 0
			HomePenalty2Major = 0
			HomePenalty2Time = 0
		end
		if Time < HomePenalty1Time then
			HomePenalty1 = 0
			HomePenalty1DoubleMinor = 0
			HomePenalty1Major = 0
			HomePenalty1Time = 0
		end
		if Time < AwayPenalty3Time then
			AwayPenalty3 = 0
			AwayPenalty3DoubleMinor = 0
			AwayPenalty3Major = 0
			AwayPenalty3Time = 0
		end
		if Time < AwayPenalty2Time then
			AwayPenalty2 = 0
			AwayPenalty2DoubleMinor = 0
			AwayPenalty2Major = 0
			AwayPenalty2Time = 0
		end
		if Time < AwayPenalty1Time then
			AwayPenalty1 = 0
			AwayPenalty1DoubleMinor = 0
			AwayPenalty1Major = 0
			AwayPenalty1Time = 0
		end
		if Time < CurrentTime then
			CurrentTime = Time
			if ThreeonThreeTime > 0 and PowerPlayTime == 0 then
				ThreeonThreeActive = 1
				ThreeonThreeTime = ThreeonThreeTime - 1
			elseif ThreeonThreeTime > 0 and PowerPlayTime > 0 then
				ThreeonThreeActive = 0
				ThreeonThreeTime = ThreeonThreeTime - 1
			else
				ThreeonThreeActive = 0
			end
			if FouronFourTime > 0 and PowerPlayTime == 0 then
				FouronFourActive = 1
				FouronFourTime = FouronFourTime - 1
			elseif FouronFourTime > 0 and PowerPlayTime > 0 then
				FouronFourActive = 0
				FouronFourTime = FouronFourTime - 1
			else
				FouronFourActive = 0
			end
			if FullStrengthTimer > 0 then
				FullStrengthTimer = FullStrengthTimer - 1
			elseif FullStrengthFlag == 2 and FullStrengthTimer == 0 then
				FullStrengthFlag = 0
			end
			if ShowSprites == 2 then
				ShowSprites = 1
			end
		end
	end
	TotalAwayPenalties = AwayPenalty1 + AwayPenalty2 + AwayPenalty3
	TotalHomePenalties = HomePenalty1 + HomePenalty2 + HomePenalty3
-- This plays the Super Mario power up sound when the Home team kills off a penalty
	if TotalHomePenalties == 0 and PowerUpFlag == 1 and PowerUp ~= nil then
		if PowerUpGoals == Launcher.Stats.AwayGoals() then
			Launcher.Sound.SetVolume(PowerUp,100)	
			Launcher.Sound.Play(PowerUp,true)
		end
		PowerUpGoals = Launcher.Stats.AwayGoals()
		PowerUpFlag = 0
	end
-- This sets things up to display the clock properly in OT
	if Launcher.Game.Period() == 4 and SetupOT == 0 and HybridOT == true then
		AwayPenalty1 = 1
		AwayPenalty1Time = 0
		HomePenalty1 = 1
		HomePenalty1Time = 0
		AwayPenalty2 = 1
		AwayPenalty2Time = 0
		HomePenalty2 = 1
		HomePenalty2Time = 0
		AwayPenalty3 = 0
		AwayPenalty3Time = 0
		HomePenalty3 = 0
		HomePenalty3Time = 0
		TotalAwayPenalties = 2
		TotalHomePenalties = 2
		ThreeonThreeTime = 300
		ThreeonThreeActive = 1
		SetupOT = 1
	elseif Launcher.Game.Period() == 4 and SetupOT == 0 and HybridOT == false and (Launcher.GameOption.OTMode() == 3 or Launcher.GameOption.OTMode() == 4) then
		AwayPenalty3 = 1
		AwayPenalty3Time = 0
		HomePenalty3 = 1
		HomePenalty3Time = 0
		TotalAwayPenalties = 1
		TotalHomePenalties = 1
		FouronFourTime = 300
		FouronFourActive = 1
		SetupOT = 1
	end
-- This tracks when to show the "Full Strength" sprite once all penalties are over
	if (TotalAwayPenalties + TotalHomePenalties) > 0 and FullStrengthFlag == 0 then
		FullStrengthFlag = 1
	elseif TotalAwayPenalties == 0 and TotalHomePenalties == 0 and FullStrengthFlag == 1 then
		FullStrengthFlag = 2
		FullStrengthTimer = 3
		PPSpriteActive = 0
	end
-- This sets everything up to draw the clock in various states
	Launcher.Screen.SetRenderTarget(1,SurfaceSprite)
	if (Launcher.Game.InCutscene() or Launcher.Game.IsShootout() or Launcher.Game.InReplay()) then
		return
	end
	if Launcher.Screen.BeginScene() or GameOver > 0 then
		Launcher.Screen.Clear(0)
		Launcher.Sprite.Clip(ClockSprite,0,0,1024,128)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)
		Launcher.Sprite.Draw(HomePog, ClockX+414, ClockY)
		Launcher.Sprite.Draw(AwayPog, ClockX+150, ClockY)
		Period = Launcher.Game.Period()
		if Period == 0 then
			Period = "SHOOTOUT"
		elseif Period == 1 then
			Period = "1st"
		elseif Period == 2 then
			Period = "2nd"
		elseif Period == 3 then
			Period = "3rd"
		elseif Period == 4 then
			Period = "OT"
		elseif Period == 5 then
			Period = "OT2"
		elseif Period == 6 then
			Period = "OT3"
		elseif Period == 7 then
			Period = "OT4"
		elseif Period == 8 then
			Period = "OT5"
		elseif Period == 9 then
			Period = "OT6"
		elseif Period > 9 then
			Period = "OT"
		end
-- This sets up the offside and icing warnings
		if Launcher.Game.Warning() == 1 and GameOver == 0 then
			if (TotalHomePenalties == 1 and TotalAwayPenalties == 1) or (TotalHomePenalties >= 2 and TotalAwayPenalties >= 2) then
				Launcher.Sprite.Clip(IcingSprite,0,0,309,32)
				Launcher.Sprite.Draw(IcingSprite, ClockX + 715, ClockY + 129)
			else
				Launcher.Sprite.Clip(IcingSprite,0,0,309,32)
				Launcher.Sprite.Draw(IcingSprite, ClockX + 715, ClockY + 97)
			end
  		elseif Launcher.Game.Warning() == 2 and GameOver == 0 then
			if (TotalHomePenalties == 1 and TotalAwayPenalties == 1) or (TotalHomePenalties >= 2 and TotalAwayPenalties >= 2) then
				Launcher.Sprite.Clip(OffsideSprite,0,0,309,32)
				Launcher.Sprite.Draw(OffsideSprite, ClockX + 715, ClockY + 129)
			else
				Launcher.Sprite.Clip(OffsideSprite,0,0,309,32)
				Launcher.Sprite.Draw(OffsideSprite, ClockX + 715, ClockY + 97)
			end
		end
-- This displays "Full Strength" once all active penalties expire
		if FullStrengthFlag == 2 and GameOver == 0 and Launcher.Game.Time() > 0 then
			Launcher.Sprite.Clip(FullStrengthSprite,0,0,309,32)
			Launcher.Sprite.Draw(FullStrengthSprite, ClockX + 715, ClockY + 97)
		end
-- This sets up clock displays related to Penalties and Power Plays
		if Launcher.Game.PenaltyPending() and GameOver == 0 then
			if GoalChecked == 0 then
				GoalCheck = Launcher.Stats.HomeGoals() + Launcher.Stats.AwayGoals()
				GoalChecked = 1
			end
			FullStrengthFlag = 0
			PenaltyPending = 1
			ShowDelayed = 1
			Launcher.Sprite.Clip(PenaltySprite,0,0,309,32)
			Launcher.Sprite.Draw(PenaltySprite, ClockX + 715, ClockY + 97)
		end
		if PenaltyPending == 1 then
			PenaltyTeam = Launcher.Game.PenaltyPendingTeam()
			PenaltyPlayer = Launcher.Game.PenaltyPendingPlayer()
			PenaltyPlayerName = Launcher.Player.FirstName(PenaltyPlayer) .. " " .. Launcher.Player.LastName(PenaltyPlayer)
			PenaltyTime = Launcher.Mem.Byte(0x79b3f7)
			if PenaltyTime == 8 then
				PenaltyTime = 5
			end
			if PenaltyTime <= 5 then
				Suffix = "(" .. PenaltyTime .. ":00)"
			else
				Suffix = "(GAME MISCONDUCT)"
			end
			if Launcher.Game.PenaltyPendingID() == 21 then
				PenaltyInfo = "CHARGING"
			elseif Launcher.Game.PenaltyPendingID() == 22 then
				PenaltyInfo = "SLASHING"
			elseif Launcher.Game.PenaltyPendingID() == 23 then
				PenaltyInfo = "ROUGHING"
			elseif Launcher.Game.PenaltyPendingID() == 24 then
				PenaltyInfo = "CROSS-CHECKING"
			elseif Launcher.Game.PenaltyPendingID() == 25 then
				PenaltyInfo = "HOOKING"
			elseif Launcher.Game.PenaltyPendingID() == 26 then
				PenaltyInfo = "TRIPPING"
			elseif Launcher.Game.PenaltyPendingID() == 27 then
				PenaltyInfo = "INTERFERENCE"
			elseif Launcher.Game.PenaltyPendingID() == 28 then
				PenaltyInfo = "HIGH STICKING"
			elseif Launcher.Game.PenaltyPendingID() == 29 then
				PenaltyInfo = "ELBOWING"
			elseif Launcher.Game.PenaltyPendingID() == 30 then
				PenaltyInfo = "CHECKING FROM BEHIND"
			elseif Launcher.Game.PenaltyPendingID() == 31 then
				PenaltyInfo = "BOARDING"
			elseif Launcher.Game.PenaltyPendingID() == 32 then
				PenaltyInfo = "HOLDING"
			elseif Launcher.Game.PenaltyPendingID() == 34 then
				PenaltyInfo = "HOOKING"
			elseif Launcher.Game.PenaltyPendingID() == 35 then
				PenaltyInfo = "HOLDING"
			elseif Launcher.Game.PenaltyPendingID() == 36 then
				PenaltyInfo = "TRIPPING"
			elseif Launcher.Game.PenaltyPendingID() == 37 then
				PenaltyInfo = "ROUGHING"
			elseif Launcher.Game.PenaltyPendingID() == 38 then
				PenaltyInfo = "FIGHTING"
			elseif Launcher.Game.PenaltyPendingID() == 39 then
				PenaltyInfo = "FIGHT INSTIGATOR"
			elseif Launcher.Game.PenaltyPendingID() == 40 then
				PenaltyInfo = "ABUSE OF OFFICIAL"
			elseif Launcher.Game.PenaltyPendingID() == 41 then
				PenaltyInfo = "ATTEMPT TO INJURE"
			elseif Launcher.Game.PenaltyPendingID() == 42 then
				PenaltyInfo = "DELAY OF GAME"
			elseif Launcher.Game.PenaltyPendingID() == 43 then
				PenaltyInfo = "HOLDING THE STICK"
			elseif Launcher.Game.PenaltyPendingID() == 44 then
				PenaltyInfo = "DIVING"
			elseif Launcher.Game.PenaltyPendingID() == 45 then
				PenaltyInfo = "SPEARING"
			end
		end
		PowerPlayTime = Launcher.Game.PowerplayTime()
		if PowerPlayTime > 0 and ThreeonThreeActive == 0 and FouronFourActive == 0 then
			PPSpriteActive = 1
			TrackShots = 1
			Minutes = math.floor(PowerPlayTime/60)
			if Minutes == 0 then
				Minutes = ""
			end
			Seconds = PowerPlayTime % 60
			if Seconds < 10 then
				Seconds = "0"..Seconds
			end
			if TotalAwayPenalties >= 2 and TotalHomePenalties == 0 and GameOver == 0 then
				Launcher.Sprite.Clip(FiveonThreeSprite,0,0,261,32)
				Launcher.Sprite.Draw(FiveonThreeSprite, ClockX + 414, ClockY + 97)
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 608,ClockY + 103,FontColor3)
			elseif TotalAwayPenalties >= 2 and TotalHomePenalties == 1 and GameOver == 0 then
				Launcher.Sprite.Clip(FouronThreeSprite,0,0,261,32)
				Launcher.Sprite.Draw(FouronThreeSprite, ClockX + 414, ClockY + 97)
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 608,ClockY + 103,FontColor3)
			elseif TotalAwayPenalties == 1 and TotalHomePenalties == 0 and GameOver == 0 then
				Launcher.Sprite.Clip(PowerPlaySprite,0,0,261,32)
				Launcher.Sprite.Draw(PowerPlaySprite, ClockX + 414, ClockY + 97)
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 608,ClockY + 103,FontColor3)
			elseif TotalHomePenalties >= 2 and TotalAwayPenalties == 0 and GameOver == 0 then
				Launcher.Sprite.Clip(FiveonThreeSprite,0,0,261,32)
				Launcher.Sprite.Draw(FiveonThreeSprite, ClockX + 151, ClockY + 97)
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 346,ClockY + 103,FontColor3)
			elseif TotalHomePenalties >= 2 and TotalAwayPenalties == 1 and GameOver == 0 then
				Launcher.Sprite.Clip(FouronThreeSprite,0,0,261,32)
				Launcher.Sprite.Draw(FouronThreeSprite, ClockX + 151, ClockY + 97)
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 346,ClockY + 103,FontColor3)
			elseif TotalHomePenalties == 1 and TotalAwayPenalties == 0 and GameOver == 0 then
				Launcher.Sprite.Clip(PowerPlaySprite,0,0,261,32)
				Launcher.Sprite.Draw(PowerPlaySprite, ClockX + 151, ClockY + 97)
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 346,ClockY + 103,FontColor3)
			end
		else
			PPSpriteActive = 0
		end
		if TotalHomePenalties >= 2 and TotalAwayPenalties >= 2 and Launcher.Game.Time() > 0 and PPSpriteActive == 0 and GameOver == 0 and ShowSprites == 1 then
			if ShowDelayed == 1 then
				Launcher.Sprite.Clip(ThreeonThreeSprite,0,0,309,32)
				Launcher.Sprite.Draw(ThreeonThreeSprite, ClockX + 715, ClockY + 129)
			else
				Launcher.Sprite.Clip(ThreeonThreeSprite,0,0,309,32)
				Launcher.Sprite.Draw(ThreeonThreeSprite, ClockX + 715, ClockY + 97)
			end
			if ThreeonThreeTime == 0 then
				if AwayPenalty1Time > ThreeonThreeTime then
					ThreeonThreeTime = AwayPenalty1Time
				end
				if AwayPenalty2Time > ThreeonThreeTime then
					ThreeonThreeTime = AwayPenalty2Time
				end
				if AwayPenalty3Time > ThreeonThreeTime then
					ThreeonThreeTime = AwayPenalty3Time
				end
				if HomePenalty1Time > ThreeonThreeTime then
					ThreeonThreeTime = HomePenalty1Time
				end
				if HomePenalty2Time > ThreeonThreeTime then
					ThreeonThreeTime = HomePenalty2Time
				end
				if HomePenalty3Time > ThreeonThreeTime then
					ThreeonThreeTime = HomePenalty3Time
				end
				ThreeonThreeTime = CurrentTime - ThreeonThreeTime
			end
			Minutes = math.floor(ThreeonThreeTime/60)
			if Minutes == 0 then
				Minutes = ""
			end
			Seconds = ThreeonThreeTime % 60
			if Seconds < 10 then
				Seconds = "0"..Seconds
			end
			if ShowDelayed == 1 then
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 950,ClockY + 132,FontColor2)
			else
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 950,ClockY + 103,FontColor2)
			end
		elseif TotalHomePenalties >= 1 and TotalAwayPenalties >= 1 and Launcher.Game.Time() > 0 and PPSpriteActive == 0 and GameOver == 0 and ShowSprites == 1 then
			if ShowDelayed == 1 then
				Launcher.Sprite.Clip(FouronFourSprite,0,0,309,32)
				Launcher.Sprite.Draw(FouronFourSprite, ClockX + 715, ClockY + 129)
			else
				Launcher.Sprite.Clip(FouronFourSprite,0,0,309,32)
				Launcher.Sprite.Draw(FouronFourSprite, ClockX + 715, ClockY + 97)
			end
			if FouronFourTime == 0 then
				if AwayPenalty1Time > FouronFourTime then
					FouronFourTime = AwayPenalty1Time
				end
				if AwayPenalty2Time > FouronFourTime then
					FouronFourTime = AwayPenalty2Time
				end
				if AwayPenalty3Time > FouronFourTime then
					FouronFourTime = AwayPenalty3Time
				end
				if HomePenalty1Time > FouronFourTime then
					FouronFourTime = HomePenalty1Time
				end
				if HomePenalty2Time > FouronFourTime then
					FouronFourTime = HomePenalty2Time
				end
				if HomePenalty3Time > FouronFourTime then
					FouronFourTime = HomePenalty3Time
				end
				FouronFourTime = CurrentTime - FouronFourTime
			end
			Minutes = math.floor(FouronFourTime/60)
			if Minutes == 0 then
				Minutes = ""
			end
			Seconds = FouronFourTime % 60
			if Seconds < 10 then
				Seconds = "0"..Seconds
			end
			if ShowDelayed == 1 then
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 950,ClockY + 132,FontColor2)
			else
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 950,ClockY + 103,FontColor2)
			end
		end
-- This displays "Empty Net" on the clock if the CPU pulls its goalie
		ScoreDiff = math.abs (Launcher.Stats.HomeGoals() - Launcher.Stats.AwayGoals())
		GoaliePullTime = Launcher.Mem.Byte(0x4c9f50) + Launcher.Mem.Byte(0x4c9f5b)
		if Launcher.Game.Period() == 3 and Time <= GoaliePullTime and ScoreDiff <= Launcher.Mem.Byte(0x4c9f42) then
			x, y, z = Launcher.Game.PuckPosition()
			if Launcher.Stats.HomeGoals() < Launcher.Stats.AwayGoals() and z < -2000 and Launcher.Game.TeamWithPuck() == 0 then
				EmptyNetFlag = 1
			elseif Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals() and z > 2000 and Launcher.Game.TeamWithPuck() == 1 then
				EmptyNetFlag = 1
			end
		end
		if EmptyNetFlag == 1 and GameOver == 0 then
			if Launcher.Stats.HomeGoals() < Launcher.Stats.AwayGoals() then
				if (TotalAwayPenalties >= 2 and TotalHomePenalties == 0) or (TotalAwayPenalties >= 2 and TotalHomePenalties == 1) or (TotalAwayPenalties == 1 and TotalHomePenalties == 0) then
					Launcher.Sprite.Clip(EmptyNetSprite,0,0,261,32)
					Launcher.Sprite.Draw(EmptyNetSprite, ClockX + 414, ClockY + 129)
				else
					Launcher.Sprite.Clip(EmptyNetSprite,0,0,261,32)
					Launcher.Sprite.Draw(EmptyNetSprite, ClockX + 414, ClockY + 97)
				end
			elseif Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals() then
				if (TotalHomePenalties >= 2 and TotalAwayPenalties == 0) or (TotalHomePenalties >= 2 and TotalAwayPenalties == 1) or (TotalHomePenalties == 1 and TotalAwayPenalties == 0) then
					Launcher.Sprite.Clip(EmptyNetSprite,0,0,261,32)
					Launcher.Sprite.Draw(EmptyNetSprite, ClockX + 151, ClockY + 129)
				else
					Launcher.Sprite.Clip(EmptyNetSprite,0,0,261,32)
					Launcher.Sprite.Draw(EmptyNetSprite, ClockX + 151, ClockY + 97)
				end
			end
		end
-- This sets up the main time on the clock
		Minutes = math.floor(Time/60)
		if Minutes == 0 then
			Minutes = ""
		end
		Seconds = Time % 60
		if Seconds < 10 then
			Seconds = "0".. Seconds
		end
		if Minutes == "" then
			Tenths = math.ceil(Launcher.Game.TimeMS(28) / 100)
			TenthsDisplay = string.sub(Tenths, 1, 1)
			Seconds = Seconds .. "." .. TenthsDisplay
		end
-- This decides when to display the tracked Power Play shots
		if TrackShots == 2 then
			TrackShots = 3
			SetStat = 1
		end
		if TrackShots == 1 and PowerPlayTime == 0 then
			TrackShots = 2
			HomeShotsAfterPP = Launcher.Stats.HomeShots()
			AwayShotsAfterPP = Launcher.Stats.AwayShots()
		end
-- This is used to show the "Saves" statistic
		AwaySaves = Launcher.Stats.HomeShots() - Launcher.Stats.HomeGoals()
		HomeSaves = Launcher.Stats.AwayShots() - Launcher.Stats.AwayGoals()
-- These are all the options for statistics that can be displayed on the clock
		if SetStat == 0 then
			SetStat = 1
			MessageTimerOn = Launcher.Game.Time()
			RandomStat = math.random (7, 32)
			if RandomStat == LastStat then
				RandomStat = math.random (7, 32)
			end
			LastStat = RandomStat
			if GoalJustScored == 1 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				GoalScorerName = Launcher.Player.FirstName(GoalScorerID) .. " " .. Launcher.Player.LastName(GoalScorerID)
				ClockMessage1 = "G: " .. GoalScorerName
				if Assist1ID ~= -1 then
					Assist1Name = Launcher.Player.FirstName(Assist1ID) .. " " .. Launcher.Player.LastName(Assist1ID)
					ClockMessage2 = "A: " .. Assist1Name
				else
					ClockMessage2 = "UNASSISTED"
				end
				if Assist2ID ~= -1 then
					Assist2Name = Launcher.Player.FirstName(Assist2ID) .. " " .. Launcher.Player.LastName(Assist2ID)
					ClockMessage3 = "A: " .. Assist2Name
				else
					ClockMessage3 = " "
				end
				ClockMessage4 = TimeofGoal
			elseif ShotSpeedNumber > 85 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage = "LAST SHOT: " .. ShotSpeed
			elseif PenaltyPending == 1 then
				PenaltyPending = 2
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage1 = PenaltyPlayerName
				ClockMessage2 = PenaltyInfo
				ClockMessage3 = Suffix
			elseif PowerPlayTime == 0 and TrackShots == 3 then	
				TrackShots = 0
				ShowPPStat = 1
				HomeGoals = HomeShotsAfterPP - TrackHomeShots
				HomePPShots = HomePPShots + HomeGoals
				AwayGoals = AwayShotsAfterPP - TrackAwayShots
				AwayPPShots = AwayPPShots + AwayGoals
				ClockMessage = "     SHOTS LAST PP "
			elseif ShowPPStat == 2 then
				ShowPPStat = 3
				HomeGoals = Launcher.Stats.HomePowerPlayGoals() .. "/" .. Launcher.Stats.HomePowerPlays()
				AwayGoals = Launcher.Stats.AwayPowerPlayGoals() .. "/" .. Launcher.Stats.AwayPowerPlays()
				ClockMessage = "      POWER PLAYS  "
			elseif (Launcher.Stats.HomeGoals() > 0 or Launcher.Stats.AwayGoals() > 0 or Launcher.Stats.HomeShots() > 0 or Launcher.Stats.AwayShots() > 0) and CountSincePlayerStat > 3 and PenaltyPending == 0 and ShowShots == 0 then
				CountSincePlayerStat = 0
				LastStat = 1
				IceTimePlayerSet = 0
				repeat
					IceTimePlayerID = math.random (0, 39)
					if IceTimePlayerID ~= 18 and IceTimePlayerID ~= 19 and IceTimePlayerID ~= 38 and IceTimePlayerID ~= 39 then
						IceTimePlayerSet = 1
					end
				until IceTimePlayerSet == 1
				if IceTimePlayerID < 20 then
					IceTimePlayerName = Launcher.Player.FirstName(IceTimePlayerID) .. " " .. Launcher.Player.LastName(IceTimePlayerID) .. " (" .. HomeAbbreviation .. ")"
				else
					IceTimePlayerName = Launcher.Player.FirstName(IceTimePlayerID) .. " " .. Launcher.Player.LastName(IceTimePlayerID) .. " (" .. AwayAbbreviation .. ")"
				end
				IceTimePlayerMins = math.floor(Launcher.Player.Time(IceTimePlayerID) / 60)
				IceTimePlayerSecs = Launcher.Player.Time(IceTimePlayerID) % 60
				if IceTimePlayerSecs < 10 then
					IceTimePlayerSecs = "0" .. IceTimePlayerSecs
				end
				IceTimePlayerTOI = IceTimePlayerMins .. ":" .. IceTimePlayerSecs
				IceTimePlayerG = Launcher.Player.Goals(IceTimePlayerID)
				IceTimePlayerA = Launcher.Player.Assists(IceTimePlayerID)
				IceTimePlayerPlusMinus = Launcher.Player.PlusMinus(IceTimePlayerID)
				IceTimePlayerShots = Launcher.Player.Shots(IceTimePlayerID)
				ShowShotsStat = math.random(1, 100)
				if ShowShotsStat > 50 then
					IceTimePlayerPlusMinus = " SHOTS: " .. IceTimePlayerShots
				else
					if IceTimePlayerPlusMinus >= 0 then
						IceTimePlayerPlusMinus = "+" .. IceTimePlayerPlusMinus
					end
				end
				UseSmallDisplay = 1
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage1 = IceTimePlayerName
				ClockMessage2 = IceTimePlayerG .. "G, " .. IceTimePlayerA .. "A, " .. IceTimePlayerPlusMinus .. ", " .. IceTimePlayerTOI .. " TOI"
			elseif CountSincePeriodSOG > 5 and Launcher.Game.Period() > 1 then
				CountSincePeriodSOG = 0
				HomeGoals = Launcher.Stats.HomeShots() - HomePeriodShots
				AwayGoals = Launcher.Stats.AwayShots() - AwayPeriodShots
				ClockMessage = " SHOTS THIS PERIOD "
			elseif CountSinceSOG > 2 then
				CountSinceSOG = 0
				HomeGoals = Launcher.Stats.HomeShots()
				AwayGoals = Launcher.Stats.AwayShots()
				ClockMessage = "     SHOTS ON GOAL "
			elseif RandomStat == 7 then
				IcinginEffect = 0
				HomeGoals = HomeIcings
				AwayGoals = AwayIcings
				ClockMessage = "        ICINGS     "
			elseif RandomStat == 8 then
				OffsidesinEffect = 0
				HomeGoals = HomeOffsides
				AwayGoals = AwayOffsides
				ClockMessage = "       OFFSIDES    "
			elseif RandomStat == 9 then
				HomeGoals = Launcher.Stats.HomeHits()
				AwayGoals = Launcher.Stats.AwayHits()
				ClockMessage = "       BIG HITS    "
			elseif RandomStat == 10 then
				HomeGoals = math.floor((Launcher.Stats.HomePasses() / Launcher.Stats.HomePassAttempts()) * 100)
				AwayGoals = math.floor((Launcher.Stats.AwayPasses() / Launcher.Stats.AwayPassAttempts()) * 100)
				ClockMessage = "       PASSING %   "
			elseif RandomStat == 11 then
				HomeGoals = Launcher.Stats.HomeFaceoffsWon()
				AwayGoals = Launcher.Stats.AwayFaceoffsWon()
				ClockMessage = "      FACEOFFS WON "
			elseif RandomStat == 12 and (Launcher.Stats.AwayOneTimers() > 0 or Launcher.Stats.HomeOneTimers() > 0) then
				HomeGoals = Launcher.Stats.HomeOneTimers()
				AwayGoals = Launcher.Stats.AwayOneTimers()
				ClockMessage = "       ONE TIMERS  "
			elseif RandomStat == 13 and (Launcher.Stats.AwayShortHandedGoals() > 0 or Launcher.Stats.HomeShortHandedGoals() > 0) then
				HomeGoals = Launcher.Stats.HomeShortHandedGoals()
				AwayGoals = Launcher.Stats.AwayShortHandedGoals()
				ClockMessage = "        SHORTIES   "
			elseif RandomStat == 14 then
				HomeGoals = Launcher.Stats.HomePenalties()
				AwayGoals = Launcher.Stats.AwayPenalties()
				ClockMessage = "        PENALTIES  "
			elseif RandomStat == 15 and (Launcher.Stats.AwayPIM() > 0 or Launcher.Stats.HomePIM() > 0) then
				HomeGoals = math.floor(Launcher.Stats.HomePIM() / 60)
				AwayGoals = math.floor(Launcher.Stats.AwayPIM() / 60)
				ClockMessage = "  PENALTY MINUTES  "
			elseif RandomStat == 16 then
				HomeGoals = HomeSaves
				AwayGoals = AwaySaves
				ClockMessage = "          SAVES    "
			elseif RandomStat == 17 and (AwayPPShots > 0 or HomePPShots > 0) then
				HomeGoals = HomePPShots
				AwayGoals = AwayPPShots
				ClockMessage = "      ALL PP SHOTS "
			elseif Launcher.Stats.AwayFaceoffsWon() > 0 and Launcher.Stats.HomeFaceoffsWon() > 0 and RandomStat == 18 then
				HomeGoals = math.ceil(Launcher.Stats.HomeFaceoffsWon() / (Launcher.Stats.HomeFaceoffsWon() + Launcher.Stats.AwayFaceoffsWon()) * 100)
				AwayGoals = math.floor(Launcher.Stats.AwayFaceoffsWon() / (Launcher.Stats.HomeFaceoffsWon() + Launcher.Stats.AwayFaceoffsWon()) * 100)
				ClockMessage = "    FACEOFF WIN %  "
			elseif RandomStat == 19 then
				HomeGoals = Launcher.Stats.HomePasses()
				AwayGoals = Launcher.Stats.AwayPasses()
				ClockMessage = "  COMPLETED PASSES "
			elseif (RandomStat == 20 or RandomStat == 21) and Launcher.Game.Period() < 4 then
				HomeGoals = TotalHomeShots
				AwayGoals = TotalAwayShots
				ClockMessage = "    SHOT ATTEMPTS  "
			elseif AwayPoss > 0 and HomePoss > 0 and RandomStat == 22 then
				HomeGoals = math.ceil(HomePoss / (HomePoss + AwayPoss) * 100)
				AwayGoals = math.floor(AwayPoss / (HomePoss + AwayPoss) * 100)
				ClockMessage = "     PUCK POSS %   "
			elseif RandomStat == 23 and Launcher.Game.Period() > 1 then
				HomeGoals = math.floor(((Launcher.Stats.HomeShots() + Launcher.Stats.HomeGoals()) / TotalHomeShots) * 100)
				AwayGoals = math.floor(((Launcher.Stats.AwayShots() + Launcher.Stats.AwayGoals()) / TotalAwayShots) * 100)
				ClockMessage = "   OFF. PRESSURE % "
			elseif AwayOffZone > 0 and HomeOffZone > 0 and RandomStat == 24 then
				HomeGoals = math.ceil(HomeOffZone / (HomeOffZone + AwayOffZone) * 100)
				AwayGoals = math.floor(AwayOffZone / (HomeOffZone + AwayOffZone) * 100)
				ClockMessage = "  OFFENSIVE ZONE % "
			elseif AwayOffZone > 0 and HomeOffZone > 0 and RandomStat == 25 then
				HomeGoals = HomeOffZone
				AwayGoals = AwayOffZone
				ClockMessage = "TIMES IN OFF. ZONE "
			elseif TotalAwayShots > 0 and TotalHomeShots > 0 and RandomStat == 26 then
				HomeGoals = math.floor((Launcher.Stats.HomeShots() / TotalHomeShots) * 100)
				AwayGoals = math.floor((Launcher.Stats.AwayShots() / TotalAwayShots) * 100)
				ClockMessage = " SHOT EFFICIENCY % "
			elseif RandomStat == 27 and (Launcher.Stats.HomePowerPlays() > 0 or Launcher.Stats.AwayPowerPlays() > 0) then
				HomeGoals = Launcher.Stats.HomePowerPlayGoals() .. "/" .. Launcher.Stats.HomePowerPlays()
				AwayGoals = Launcher.Stats.AwayPowerPlayGoals() .. "/" .. Launcher.Stats.AwayPowerPlays()
				ClockMessage = "     POWER PLAYS   "
			elseif RandomStat == 28 then
				HomeGoals = Launcher.Stats.HomePassAttempts()
				AwayGoals = Launcher.Stats.AwayPassAttempts()
				ClockMessage = "  PASSES ATTEMPTED "
			elseif RandomStat == 29 then
				HomeGoals = HomeScoringChances
				AwayGoals = AwayScoringChances
				ClockMessage = "   SCORING CHANCES "
			elseif RandomStat == 30 then
				HomeGoals = HomeHardestShots
				AwayGoals = AwayHardestShots
				ClockMessage = "    HARDEST SHOTS  "
			elseif RandomStat == 31 and Launcher.Game.Period() > 1 then
				HomeGoals = TotalHomeShots - HomePeriodAttempts
				AwayGoals = TotalAwayShots - AwayPeriodAttempts
				ClockMessage = "  PERIOD SHOT ATT. "
			elseif RandomStat == 32 and Launcher.Game.Period() > 1 then
				HomeGoals = math.floor((Launcher.Stats.HomePowerPlayGoals() / Launcher.Stats.HomePowerPlays()) * 100)
				AwayGoals = math.floor((Launcher.Stats.AwayPowerPlayGoals() / Launcher.Stats.AwayPowerPlays()) * 100)
				ClockMessage = "    PP SUCCESS %   "
			else
				CountSinceSOG = 0
				HomeGoals = Launcher.Stats.HomeShots()
				AwayGoals = Launcher.Stats.AwayShots()
				ClockMessage = "     SHOTS ON GOAL "
			end
		end
-- This decides how and what to display in regards to statistics
		MessageTimerOff = Launcher.Game.Time()
		MessageTimerDiff = MessageTimerOn - MessageTimerOff
		if MessageTimerDiff < 6 or PlayStoppedPeriod == 1 or GameOver > 0 then
			if Launcher.Game.Period() == 0 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				ClockMessage = "        SHOOTOUT   "
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 65,ClockY + 38,FontColor2)
			elseif GameOver == 2 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				ClockMessage = "        FINAL/OT   "
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 65,ClockY + 38,FontColor2)
			elseif GameOver == 1 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				ClockMessage = "         FINAL     "
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 65,ClockY + 38,FontColor2)
			elseif PlayStoppedPeriod == 1 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				ClockMessage = "END OF " .. Period .. " PERIOD"
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 65,ClockY + 38,FontColor2)
			elseif UseSmallDisplay == 1 then
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage1,ClockX + TimeX - 64,ClockY + 26,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage2,ClockX + TimeX - 64,ClockY + 47,FontColor2)
			elseif PenaltyPending == 2 then
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage1,ClockX + TimeX - 64,ClockY + 19,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage2,ClockX + TimeX - 64,ClockY + 40,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage3,ClockX + TimeX - 64,ClockY + 61,FontColor2)
			elseif GoalJustScored == 1 then
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage1,ClockX + TimeX - 64,ClockY + 4,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage2,ClockX + TimeX - 64,ClockY + 25,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage3,ClockX + TimeX - 64,ClockY + 46,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage4,ClockX + TimeX - 64,ClockY + 67,FontColor2)
			else
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 65,ClockY + 38,FontColor2)
			end
		else
			if PenaltyPending == 2 then
				PenaltyPending = 3
			end
			ShotSpeedNumber = 0
			HomeGoals = Launcher.Stats.HomeGoals()
			AwayGoals = Launcher.Stats.AwayGoals()
			Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 125,ClockY + 23,FontColor2)
			Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 125,ClockY + 23,FontColor2)
			if Launcher.Game.Period() == 0 then
				Launcher.Font.DrawText(ClockFontS,Period,ClockX + TimeX - 48,ClockY + 23,FontColor2)
			else
				Launcher.Font.DrawText(ClockFontS,Period.."   "..Minutes..":"..Seconds,ClockX + TimeX - 48,ClockY + 23,FontColor2)
			end
		end
        Launcher.Screen.EndScene()		
	end
	Launcher.Screen.ResetRenderTarget()	
end
function ZoneChangedCallback()
-- This enables stats to begin showing following the start of a period
	ShowClock = 1
-- This is used to show the "Puck Possession" statistic
	if Launcher.Game.TeamWithPuck() == 0 then
		HomePoss = HomePoss + 1
	else
		AwayPoss = AwayPoss + 1
	end
-- This is used to show the Offensive Zone percentage statistic
	if Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3 or Launcher.Game.Period() == 4 then
		if Launcher.Game.TeamWithPuck() == 0 and Launcher.Game.PuckZone() == -1 then
			HomeOffZone = HomeOffZone + 1
		elseif Launcher.Game.TeamWithPuck() == 1 and Launcher.Game.PuckZone() == 1 then
			AwayOffZone = AwayOffZone + 1
		end
	elseif Launcher.Game.Period() == 2 then
		if Launcher.Game.TeamWithPuck() == 0 and Launcher.Game.PuckZone() == 1 then
			HomeOffZone = HomeOffZone + 1
		elseif Launcher.Game.TeamWithPuck() == 1 and Launcher.Game.PuckZone() == -1 then
			AwayOffZone = AwayOffZone + 1
		end
	end
end
-- Callback Definitions
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
Launcher.Callback.Register("CutsceneStopped",CutsceneStoppedCallback)
Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("FaceoffStarted",FaceOffStartedCallback)
Launcher.Callback.Register("Paused",PausedCallback)
Launcher.Callback.Register("Penalty",PenaltyCallback)
Launcher.Callback.Register("PeriodStarted",PeriodStartedCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("RenderBackground",RenderCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)
Launcher.Callback.Register("ShotAway",ShotAwayCallback)
Launcher.Callback.Register("ShotHome",ShotHomeCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("ZoneChanged",ZoneChangedCallback)