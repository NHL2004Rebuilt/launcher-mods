-- drgullen's In Game Tweaks - v3.3.2 - August 30, 2024
-- Requirements to run this mod:
	--	Vod's "NHL 2004 Launcher" (V2.41 or newer) and these libraries that go with the Launcher:
		-- Default Libraries (V2.52 or newer)
		-- Default System Scripts (V2.16 or newer)
		-- Tweaks (V1.1 or newer)
	
-- ==================================== START OF SETTINGS SECTION - USE THE LAUNCHER GUI TO CHANGE THINGS - DO NOT CHANGE THEM HERE ===========================================

-- =========================================================================== OFFLINE ========================================================================================

-- IMPORTANT: CHANGE THINGS USING THE LAUNCHER GUI, NOT HERE!!!

-- Injury Settings (APPLIES TO OFFLINE MODE ONLY)
ControllerOnlyInjuries = Launcher.Config.Bool("continjuries",false)
GoalieDiagnosis = Launcher.Config.Bool("goaliediagnosis",true)
GoalieInjuries = Launcher.Config.Bool("goalieinjuries",true)
GoalieInjuryChance = Launcher.Config.Int("goaliechance",7)
GoalieInjuryLikely = Launcher.Config.Bool("goalieinjurylikely",false)
GoofyGoalie = Launcher.Config.Int("goaliegoofy",0)
SkaterDiagnosis = Launcher.Config.Bool("skaterdiagnosis",true)
SkaterInjuries = Launcher.Config.Bool("skaterinjuries",true)
SkaterInjuryChance = Launcher.Config.Int("skaterchance",3)

-- Hybrid 3-on-3 OT (setup by assessing Major penalties for "Delay of Game" to keep a player from each team in the box for the entire 5-minute OT)
	-- IMPORTANT: Do not use if you are in the Playoffs/Medal Round (i.e. 20-minute OT periods) of your season or dynasty or tournament.
TenMinuteOT = Launcher.Config.Bool("tenminot",false)
ThreeonThreeOT = Launcher.Config.Bool("threeonthreeot",false)
SOAfterOT = Launcher.Config.Bool("soafterot",false)

-- Shootout Tweaks (APPLIES TO OFFLINE MODE ONLY)
ShootOutTweaks = Launcher.Config.Bool("shootouttweaks",true)

-- On/Off switches for Scripted Penalties
AdditionalPenalties = Launcher.Config.Bool("additionalpenalties",true)
APFrequency = Launcher.Config.Int("apfreq",2)
APMaximum = Launcher.Config.Int("apmax",5)
DoubleMinorPenalties = Launcher.Config.Bool("doubleminorpenalties",true)
MaxDoubleMinors = Launcher.Config.Int("maxdmp",1)
MajorPenalties = Launcher.Config.Bool("majorpenalties",true)
MaxMajors = Launcher.Config.Int("maxmajorp",1)
Misconducts = Launcher.Config.Bool("misconductpenalties",true)
XHLPenalties = Launcher.Config.Bool("xhlpen",false)

-- Scripted Penalties (AdditionalPenalties must be set to true otherwise none of these will be active)
CoincidentalMinors = Launcher.Config.Bool("coincidentalminors",true)
DelayPenalty = Launcher.Config.Bool("delaypenalty",true)
IcingPenalty = Launcher.Config.Bool("icingpenalty",false)
InstigatorPenalty = Launcher.Config.Bool("instigatorpenalty",true)
Long5on3 = Launcher.Config.Bool("long5on3",true)
OfficialAbusePenalty = Launcher.Config.Bool("officialabusepenalty",true)
OffsidePenalty = Launcher.Config.Bool("offsidepenalty",true)
RoughingPenalty = Launcher.Config.Bool("roughingpenalty",true)

-- Other Options
AwayCoachInfluence = Launcher.Config.Int("awaycoach",0)
BalancedFaceoffs = Launcher.Config.Bool("balancedfaceoffs",true)
BigHits = Launcher.Config.Bool("bighits",true)
BumpyIce = Launcher.Config.Bool("bumpyice",true)
BumpyIceChance = Launcher.Config.Int("bumpychance",40)
BumpyIceChanceHigher = Launcher.Config.Bool("morebumpy",true)
BumpyHeightLimit = Launcher.Config.Int("bumpyheight",100)
DeterioratingIce = Launcher.Config.Bool("deterioratingice",true)
EmptyNetGoals = Launcher.Config.Bool("emptygoal",false)
FalseStarts = Launcher.Config.Bool("falsestarts",true)
FalseStartsMax = Launcher.Config.Int("maxfalsies",3)
FannedCentering = Launcher.Config.Bool("fannedcenter",false)
FannedPasses = Launcher.Config.Bool("fannedpasses",false)
FannedPercentage = Launcher.Config.Int("fannedpct",3)
FirstShotsMiss = Launcher.Config.Bool("firstshot",true)
FirstShotsMissAllGame = Launcher.Config.Bool("firstshotallgame",true)
FirstShotsMaxTime = Launcher.Config.Int("firstshotmaxtime",120)
FreshAttributes = Launcher.Config.Bool("freshatts",true)
GameFlow = Launcher.Config.Bool("gameflow",true)
HomeCoachInfluence = Launcher.Config.Int("homecoach",0)
IcingLineManagement = Launcher.Config.Bool("icinglinemanagement",true)
JailBreakGoals = Launcher.Config.Bool("jailbreak",true)
JailBreakDoubleMinors = Launcher.Config.Bool("jailbreakdminors",true)
JailBreakMajors = Launcher.Config.Bool("jailbreakmajors",true)
MercyRule = Launcher.Config.Bool("mercy",false)
MercyRuleLimit = Launcher.Config.Int("mercylimit",6)
MissedPP = Launcher.Config.Int("missedpp",50)
MissedShotsHigh = Launcher.Config.Int("missedhigh",33)
RandomPuckDrops = Launcher.Config.Bool("randompuckdrops",true)
RefErrors = Launcher.Config.Bool("referrors",true)
ShotFlow = Launcher.Config.Bool("shotflow",true)
ShotFlowPP = Launcher.Config.Bool("shotflowpp",true)
SlowingPassSpeed = Launcher.Config.Bool("slowingpassspeed",true)
SnowyIce = Launcher.Config.Bool("snowyice",true)
SnowyIceFriction = Launcher.Config.Number("snowyfriction",0.00625)
StrangeBounceTweak = Launcher.Config.Bool("strangebounces",true)
StrangeBounceReduction = Launcher.Config.Int("sbreduction",2)
TwoMinuteWarning = Launcher.Config.Bool("twominutes",false)
TwoMinuteWarningClockStop = Launcher.Config.Bool("tmwclock",false)
WildShot = Launcher.Config.Bool("wildshot",true)
WildShotFrequency = Launcher.Config.Int("wildshotfrequency",17)
WildShotRange = Launcher.Config.Int("wildshotrange",3)
WildShotRangeHigh = Launcher.Config.Int("wildshotrangehigh",7)

-- ====================================================================== OFFLINE OR ONLINE ===================================================================================

-- IMPORTANT: CHANGE THINGS USING THE LAUNCHER GUI, NOT HERE!!!

-- Player Attribute Tweaks (APPLIES TO BOTH ONLINE AND OFFLINE MODES)
AccelTweak = Launcher.Config.Int("acceltweak",100)
AccuracyTweak = Launcher.Config.Int("accuracytweak",100)
AggressionTweak = Launcher.Config.Int("aggressiontweak",100)
AgilityTweak = Launcher.Config.Int("agilitytweak",100)
BalanceTweak = Launcher.Config.Int("balancetweak",100)
CheckingTweak = Launcher.Config.Bool("checkingtweak",true)
DekingTweak = Launcher.Config.Int("dekingtweak",100)
EnduranceTweak = Launcher.Config.Int("endurancetweak",100)
PassingTweak = Launcher.Config.Int("passingtweak",100)
PenaltyTweak = Launcher.Config.Int("penaltytweak",100)
PowerPlayTweak = Launcher.Config.Bool("powerplaytweak",true)
PowerTweak = Launcher.Config.Int("powertweak",100)
PuckControlTweak = Launcher.Config.Int("puckcontroltweak",100)
ToughnessTweak = Launcher.Config.Int("toughnesstweak",100)
Variation = Launcher.Config.Int("skaterattvariation",10)

-- Goaltender Attribute Tweaks (APPLIES TO BOTH ONLINE AND OFFLINE MODES)
AwayGloveLow = Launcher.Config.Int("aglow",100)
AwayGloveHigh = Launcher.Config.Int("aghigh",100)
AwayStickLow = Launcher.Config.Int("aslow",100)
AwayStickHigh = Launcher.Config.Int("ashigh",100)
AwayFiveHole = Launcher.Config.Int("afhole",100)
HomeGloveLow = Launcher.Config.Int("hglow",100)
HomeGloveHigh = Launcher.Config.Int("hghigh",100)
HomeStickLow = Launcher.Config.Int("hslow",100)
HomeStickHigh = Launcher.Config.Int("hshigh",100)
HomeFiveHole = Launcher.Config.Int("hfhole",100)
GoalieVariation = Launcher.Config.Int("goalieattvariation",10)

-- Alternate Game Modes (APPLIES TO BOTH ONLINE AND OFFLINE MODES)
AllMajorPenalties = Launcher.Config.Bool("allmajors",false)
RealTime = Launcher.Config.Bool("realtime",false)
RealTimeStartInThird = Launcher.Config.Bool("rtime3rd",false)
FirsttoThree = Launcher.Config.Bool("firsttothree",false)

-- Game Multi-Value Options - change the number for the desired effect
ClearingDelaysPerGame = Launcher.Config.Int("clearingdelays",2)
ClearingDelayChance = Launcher.Config.Int("clearingdelaychance",3)
FaceoffsPerMinute = Launcher.Config.Number("faceoffsperminute",0.88)
ShotsPerMinute = Launcher.Config.Number("shotsperminute",1.05)
ShotsRandomizer = Launcher.Config.Bool("shotsrandomizer",false)
ShotsRandomizerAmount = Launcher.Config.Int("sramount",25)
InjuryChance = Launcher.Config.Int("injurychance",1)
QuickCover = Launcher.Config.Int("quickcover",1)

-- ============================================================================ ONLINE ========================================================================================

-- Online Settings (THESE VALUES OVERRIDE THE PREVIOUS VALUES IF OnlinePlay IS SET TO TRUE)

-- IMPORTANT: CHANGE THINGS USING THE LAUNCHER GUI, NOT HERE!!!

OnlinePlay = Launcher.Config.Bool("onlineplay",false)

if OnlinePlay == true then

-- Online Attribute Tweaks
	CheckingTweak = false
	ShootOutTweaks = false

-- Online Additional Configuration
	BigHits = false
	BumpyIce = false
	FalseStarts = false
	FannedPasses = false
	GameFlow = false
	GoalieDiagnosis = false
	GoalieInjuries = false
	GoalieInjuryLikely = false
	RandomPuckDrops = false
	RefErrors = false
	ShotsRandomizer = false
	SkaterDiagnosis = false
	SkaterInjuries = false
	SlowingPassSpeed = false
	SnowyIce = false
	StrangeBounceTweak = false
	WildShot = false

-- Online Additional Penalties
	CoincidentalMinors = false
	DelayPenalty = false
	DoubleMinorPenalties = false
	InstigatorPenalty = false
	Long5on3 = false
	MajorPenalties = false
	Misconducts = false
	OfficialAbusePenalty = false
	RoughingPenalty = false
	XHLPenalties = false
end

-- ==================================================================== END OF SETTINGS SECTION ==============================================================================

-- =========================== START OF SCRIPT CODE SECTION - FOR THE MOD TO FUNCTION AS INTENDED, PLEASE DO NOT CHANGE ANYTHING BELOW THIS LINE =============================

-- Variable starting values
AbsoluteScore = 0
APPause = false
APTimer = 0
AwayController = 0
AwayFixPending = 0
BumpyIceActive = 0
Checking = 0
CoincidentalMinor = 0
CurrentAwayLine = -1
CurrentHomeLine = -1
CurrentTime = 1200
CurrentTimer = 28
DelayPenaltySet = 0
Diagnosis = 0
DiagnosisSkater = 0
DoubleMinor = 0
DoubleMinorChance = 0
ElapsedTime = 1
ExclPID1 = -1
ExclPID1Time = 1200
ExclPID2 = -1
ExclPID2Time = 1200
ExclPID3 = -1
ExclPID3Time = 1200
ExclPID4 = -1
ExclPID4Time = 1200
ExclPID5 = -1
ExclPID5Time = 1200
ExclPID6 = -1
ExclPID6Time = 1200
ExpectedAwayTotalPP = 0
ExpectedHomeTotalPP = 0
FaceoffRate = 0
FalseStartDelay = 0
FalseStartTime = 0
FalseStartTimeDiff = 0
FannedActive = 0
FannedSpeed = 0
FirstFaceoff = 0
FirstShotsLength = 0
FixAwayMisconduct = 0
FixHomeMisconduct = 0
ForceDoubleMinor = 0
ForceMajor = 0
ForceMissed = 0
ForceMissedTimer = 0
GoalieCount = 0
GoaliePass = 0
HomeController = 0
HomeFixPending = 0
IcingAwayLine = -1
IcingCount = 0
IcingHomeLine = -1
IcingPlayer = -1
InjuredSkaterChanceCount = 0
JailBreakActive = 0
JailBreakAwaySHG = 0
JailBreakHomeSHG = 0
JailBreakResetClock = 0
JailBreakResetPeriod = 1
L5on3 = 0
LastIcingTeam = -1
LastOffsideTeam = -1
MajorAwayPlayer = -1
MajorChance = 0
MajorHomePlayer = -1
Majors = 0
MajorTrigger = 0
MisconductPenalty = 0
MissedAmount = 0
MissedHighLeftorRight = 0
MissedLeftorRight = 0
MissedPPPause = false
MissedPPPercent = 0
OffsideCount = 0
OriginalShotsPerMinute = ShotsPerMinute
PenaltySet = 0
PenaltyTime = 0
PPPlayer = 0
PPT = 0
RandomFaceoff = 0
RandomVariation = 0
randomx = 0
randomy = 0
ScriptedPending = 0
SetIcingLine = 0
SnowyTime = 0
StartEnergyMultiplier = Launcher.Config.Number("psem",0.000244140625)
StartPassSpeed = Launcher.Config.Number("bps",92.00)
PassSpeed = StartPassSpeed
StartPuckBoardBounceFriction = Launcher.Config.Number("pbbf",0.285)
StartPuckBoardFriction = Launcher.Config.Number("pbrdf",0.98)
PuckBoardFriction = StartPuckBoardFriction
StartPuckBounceFriction = Launcher.Config.Number("pbf",0.285)
PuckBounceFrictionMax = Launcher.Config.Number("pbfmax",0.585)
StartPuckGravity = Launcher.Config.Number("pg",2.5)
startingz = 0
StopClock = 1
StopforDelay = 0
StrangeBounce = 0
StrangeBounceChance = 0
ThreeonThree = 0
TotalClearings = 0
TotalFaceoffs = 0
TotalShots = 0
UporDown = 0
UseCutSceneFunction = 0
WildShotPause = false
ZonesSinceStoppage = 0

Launcher.Physics.SetPassBaseSpeed(StartPassSpeed)
Launcher.Physics.SetPuckGravity(StartPuckGravity)

-- Callback Functions
function CutsceneStartedCallback()
	if UseCutSceneFunction == 1 then
-- This determines which line to put back onto the ice in the case of an icing call if the "IcingManagement" option is set to true
		if SetIcingLine == 1 and IcingLineManagement == true and PPT == 0 and IcingPlayer >= 0 then
			if IcingPlayer > 19 then
				IcingPlayer = IcingPlayer - 20
				IcingHomeLine = -1
				IcingPlayerID = -1
				loopcount = 0
				repeat
					loopplayer = Launcher.Line.AwayPlayer(0,loopcount)
					if loopplayer == IcingPlayer then
						IcingPlayerID = loopplayer
					else
						loopcount = loopcount + 1
					end
				until IcingPlayerID == loopplayer
				if IcingPlayerID < 3 then
					IcingAwayLine = 0
				elseif IcingPlayerID < 6 then
					IcingAwayLine = 1
				elseif IcingPlayerID < 9 then
					IcingAwayLine = 2
				elseif IcingPlayerID < 12 then
					IcingAwayLine = 3
				elseif IcingPlayerID < 14 then
					IcingAwayLine = 0
				elseif IcingPlayerID < 16 then
					IcingAwayLine = 1
				else
					IcingAwayLine = 2
				end
			else
				IcingAwayLine = -1
				IcingPlayerID = -1
				loopcount = 0
				repeat
					loopplayer = Launcher.Line.HomePlayer(0,loopcount)
					if loopplayer == IcingPlayer then
						IcingPlayerID = loopplayer
					else
						loopcount = loopcount + 1
					end
				until IcingPlayerID == loopplayer
				if IcingPlayerID < 3 then
					IcingHomeLine = 0
				elseif IcingPlayerID < 6 then
					IcingHomeLine = 1
				elseif IcingPlayerID < 9 then
					IcingHomeLine = 2
				elseif IcingPlayerID < 12 then
					IcingHomeLine = 3
				elseif IcingPlayerID < 14 then
					IcingHomeLine = 0
				elseif IcingPlayerID < 16 then
					IcingHomeLine = 1
				else
					IcingHomeLine = 2
				end
			end
			SetIcingLine = 2
		end
-- This resets the Checking attribute if it was just in play for a big hit
		if CheckingTweak == true and Checking > 1 and OnlinePlay == false then
			Checking = math.random ()
			if Checking < 0.5 then
				Checking = 0.75
			end
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,0,true)
			Checking = math.random ()
			if Checking < 0.5 then
				Checking = 0.75
			end
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,1,true)
		end
-- This resets the strange bounce option if active
		if DeterioratingIce == true then
			Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
		end
	end
-- This reloads the player's default attributes if the Fresh Attributes setting is false
	if FreshAttributes == false then
		for loopcount=0, 39 do
			for attributecount=0, 16 do
				Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
				Value = players[loopcount] [attributecount]
				if loopcount == 18 or loopcount == 19 or loopcount == 38 or loopcount == 39 then
					if GoalieCount == 0 then
						if attributecount == 4 or attributecount == 5 or attributecount == 7 or attributecount == 9 or attributecount == 16 then
							Value = math.floor(Value * (1 + (GoalieVariation / 100)))
						end
					else
						if attributecount == 4 or attributecount == 5 or attributecount == 7 or attributecount == 9 or attributecount == 16 then
							Value = math.floor(Value * (1 - (GoalieVariation / 100)))
						end
					end
				end
				Launcher.Mem.WriteByte(Pointer, Value)
			end
		end
		if GoalieCount == 0 then
			GoalieCount = 1
		else
			GoalieCount = 0
		end
	end
-- This corrects the game stats relating to Major and Misconduct penalties where a bug in the base game miscalculates the number of attempted Power Plays
	PPT = Launcher.Game.PowerplayTime()
	if PPT == 0 and AwayFixPending == 1 then 
		if AwayFixGoals ~= Launcher.Stats.AwayGoals() then
			AwayFixGoalDifference = Launcher.Stats.AwayGoals() - AwayFixGoals
			AwayNewPPTotal = Launcher.Stats.AwayPowerPlays() - AwayFixGoalDifference
			Launcher.Stats.AwayPowerPlays(AwayNewPPTotal)
			AwayFixGoals = Launcher.Stats.AwayGoals()
			AwayFixPending = 0
		else
			AwayFixPending = 0
		end
	end
	if PPT == 0 and HomeFixPending == 1 then
		if HomeFixGoals ~= Launcher.Stats.HomeGoals() then
			HomeFixGoalDifference = Launcher.Stats.HomeGoals() - HomeFixGoals
			HomeNewPPTotal = Launcher.Stats.HomePowerPlays() - HomeFixGoalDifference
			Launcher.Stats.HomePowerPlays(HomeNewPPTotal)
			HomeFixGoals = Launcher.Stats.HomeGoals()
			HomeFixPending = 0
		else
			HomeFixPending = 0
		end
	end
	if PPT == 0 and FixAwayMisconduct == 1 and ExpectedAwayTotalPP ~= Launcher.Stats.AwayPowerPlays() then
		AwayNewPPTotal = Launcher.Stats.AwayPowerPlays() - 1
		Launcher.Stats.AwayPowerPlays(AwayNewPPTotal)
		FixAwayMisconduct = 0
	end
	if PPT == 0 and FixHomeMisconduct == 1 and ExpectedHomeTotalPP ~= Launcher.Stats.HomePowerPlays() then
		HomeNewPPTotal = Launcher.Stats.HomePowerPlays() - 1
		Launcher.Stats.HomePowerPlays(HomeNewPPTotal)
		FixHomeMisconduct = 0
	end
-- This ends the game if the "First to Three" game mode is active and a team has scored its 3rd goal
	if FirsttoThree == true and Launcher.Game.Period() < 4 then
		if Launcher.Stats.HomeGoals() == 3 or Launcher.Stats.AwayGoals() == 3 then
			Launcher.Game.SetPeriod(4)
			Launcher.Game.SetTime(0)
			Launcher.Game.Over()
		end
	end
-- This ends the game if the Mercy Rule is active and one team is leading by the Mercy Rule limit
	if MercyRule == true and AbsoluteScore == MercyRuleLimit then
		Launcher.Game.SetPeriod(4)
		Launcher.Game.SetTime(0)
		Launcher.Game.Over()
	end
-- This ends the game if the "Empty Net Goal Ends Game" option is active
	if EmptyNetGoals == true and Launcher.Game.Period() == 3 and Launcher.Game.Time() < 120 and (Launcher.Stats.AwayEmptyNetGoals() > 0 or Launcher.Stats.HomeEmptyNetGoals() > 0) then
		Launcher.Game.SetPeriod(4)
		Launcher.Game.SetTime(0)
		Launcher.Game.Over()
	end
-- This randomizes the chances of a Double Minor or Major if the "XHL Penalties" option is active and it is the appropriate time to do so
	if AdditionalPenalties == true and XHLPenalties == true and OnlinePlay == false and APPause == false then
		if Launcher.Game.Period() == 1 then
			if MaxMajors > 0 and ForceMajor == 0 then
				ForceMajorChance = math.random ()
				if ForceMajorChance > 0.99 then
					ForceMajor = 1
				end
			end
			if MaxDoubleMinors > 0 and ForceDoubleMinor == 0 then
				ForceDoubleMinorChance = math.random ()
				if ForceDoubleMinorChance < 0.015 then
					ForceDoubleMinor = 1
				end
			end
		elseif Launcher.Game.Period() == 2 then
			if MaxMajors > 0 and ForceMajor == 0 then
				ForceMajorChance = math.random ()
				if ForceMajorChance > 0.985 then
					ForceMajor = 1
				end
			end
			if MaxDoubleMinors > 0 and ForceDoubleMinor == 0 then
				ForceDoubleMinorChance = math.random ()
				if ForceDoubleMinorChance < 0.02 then
					ForceDoubleMinor = 1
				end
			end
		elseif Launcher.Game.Period() == 3 then
			if MaxMajors > 0 and ForceMajor == 0 then
				ForceMajorChance = math.random ()
				if ForceMajorChance > 0.98 then
					ForceMajor = 1
				end
			end
			if MaxDoubleMinors > 0 and ForceDoubleMinor == 0 then
				ForceDoubleMinorChance = math.random ()
				if ForceDoubleMinorChance < 0.025 then
					ForceDoubleMinor = 1
				end
			end
		end
	end
-- Check for a fight cut scene and if one is happening, temporarily disable most of the Additional Penalties
	if Launcher.Cutscene.ID() == 13 or Launcher.Cutscene.ID() == 14 and AdditionalPenalties == true then
		APPause = true
		APTimer = Launcher.Game.Time() - 300
	end
end
function CutsceneStoppedCallback()
-- This handles the random chance of a goaltender suffering a simulated in-game injury
	if OnlinePlay == false and GoalieInjuries == true and Diagnosis == 0 and Launcher.Game.Time() > 450 and Launcher.Game.Period() < 4 then
		InjuredGoalieChance = math.random ()
		if InjuredGoalieChance < (GoalieInjuryChance / 100) or GoalieInjuryLikely == true then
			InjuredGoalie = math.random (0, 39)
			if (InjuredGoalie == 18 and (Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19) and ControllerOnlyInjuries == false or (ControllerOnlyInjuries == true and HomeController == 1)) or (InjuredGoalie == 38 and (Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) and ControllerOnlyInjuries == false or (ControllerOnlyInjuries == true and AwayController == 1)) then
				if InjuredGoalie == 18 and Launcher.Stats.AwayShots() > 0 and (Launcher.Player.ShotsAgainst(18) == 0 or Launcher.Player.ShotsAgainst(19) == 0) then
					GoalieInjuryLikely = false
					if Launcher.Player.ShotsAgainst(18) == 0 then
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+19*4) + 0x7C + attributecount
							Value = players[19] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[19] [attributecount] = NewValue
						end
						os.execute('start cmd /k echo Goaltender ' .. Launcher.Player.FirstName(19) .. ' ' .. Launcher.Player.LastName(19) .. ' (' .. Launcher.Game.HomeNameAbbreviation() .. ') is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(19)
							GoalieLName = Launcher.Player.LastName(19)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 600 then
								Whistles = 3
							else
								Whistles = math.random (10, 25)
							end
						end
					else
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+18*4) + 0x7C + attributecount
							Value = players[18] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[18] [attributecount] = NewValue
						end
						os.execute('start cmd /k echo Goaltender ' .. Launcher.Player.FirstName(18) .. ' ' .. Launcher.Player.LastName(18) .. ' (' .. Launcher.Game.HomeNameAbbreviation() .. ') is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(18)
							GoalieLName = Launcher.Player.LastName(18)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 600 then
								Whistles = 3
							else
								Whistles = math.random (10, 25)
							end
						end
					end
				elseif InjuredGoalie == 38 and Launcher.Stats.HomeShots() > 0 and (Launcher.Player.ShotsAgainst(38) == 0 or Launcher.Player.ShotsAgainst(39) == 0) then
					GoalieInjuryLikely = false
					if Launcher.Player.ShotsAgainst(38) == 0 then
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+39*4) + 0x7C + attributecount
							Value = players[39] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[39] [attributecount] = NewValue
						end
						os.execute('start cmd /k echo Goaltender ' .. Launcher.Player.FirstName(39) .. ' ' .. Launcher.Player.LastName(39) .. ' (' .. Launcher.Game.AwayNameAbbreviation() .. ') is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(39)
							GoalieLName = Launcher.Player.LastName(39)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 600 then
								Whistles = 3
							else
								Whistles = math.random (10, 25)
							end
						end
					else
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+38*4) + 0x7C + attributecount
							Value = players[38] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[38] [attributecount] = NewValue
						end
						os.execute('start cmd /k echo Goaltender ' .. Launcher.Player.FirstName(38) .. ' ' .. Launcher.Player.LastName(38) .. ' (' .. Launcher.Game.AwayNameAbbreviation() .. ') is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(38)
							GoalieLName = Launcher.Player.LastName(38)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 600 then
								Whistles = 3
							else
								Whistles = math.random (10, 25)
							end
						end
					end
				end
			end
		end
	end
-- This decides the fate of the injured goaltender if the "GoalieDiagnosis" option is enabled
	if GoalieDiagnosis == true and Diagnosis == 1 and OnlinePlay == false then
		Whistles = Whistles - 1
		if (PPT == 0 and Whistles <= 0) or (Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300) then
			Whistles = 0
			InjuryNumber = math.random (7, 23)
			if InjuryNumber == 7 then
				InjuryType = "A BROKEN RIGHT FOOT"
			elseif InjuryNumber == 8 then
				InjuryType = "A SORE ANKLE"
			elseif InjuryNumber == 9 then
				InjuryType = "TORN KNEE CARTILAGE"
			elseif InjuryNumber == 10 then
				InjuryType = "A BRUISED QUADRICEP"
			elseif InjuryNumber == 11 then
				InjuryType = "A PULLED GROIN"
			elseif InjuryNumber == 12 then
				InjuryType = "A SORE HIP"
			elseif InjuryNumber == 13 then
				InjuryType = "AN ABDOMINAL TEAR"
			elseif InjuryNumber == 14 then
				InjuryType = "A STRAINED RIB MUSCLE"
			elseif InjuryNumber == 15 then
				InjuryType = "DISC SURGERY"
			elseif InjuryNumber == 16 then
				InjuryType = "SHOULDER CONTUSIONS"
			elseif InjuryNumber == 17 then
				InjuryType = "A LACERATED ARM"
			elseif InjuryNumber == 18 then
				InjuryType = "A SORE ELBOW"
			elseif InjuryNumber == 19 then
				InjuryType = "A BRUISED LEFT WRIST"
			elseif InjuryNumber == 20 then
				InjuryType = "A DISLOCATED RIGHT THUMB"
			elseif InjuryNumber == 21 then
				InjuryType = "WHIPLASH"
			elseif InjuryNumber == 22 then
				InjuryType = "A HEAD LACERATION"
			else
				InjuryType = "A MILD CONCUSSION"
			end
			InjuryLength = math.random (2, 10)
			if InjuryNumber == 7 or InjuryNumber == 15 then
				InjuryLength = 11
			elseif InjuryNumber == 8 or InjuryNumber == 12 or InjuryNumber == 18 then
				InjuryLength = 0
			elseif (InjuryNumber == 14 or InjuryNumber == 19 or InjuryNumber == 23) and InjuryLength < 5 then
				InjuryLength = 0
			elseif InjuryNumber == 14 or InjuryNumber == 19 or InjuryNumber == 23 then
				InjuryTime = " DAYS"
			else
				InjuryTime = " WEEKS"
			end
			if InjuryLength == 0 then
				os.execute('start cmd /k echo Injured Goalie Diagnosis: ' .. GoalieFName .. ' ' .. GoalieLName .. ' IS OUT FOR THE REMAINDER OF THIS GAME ONLY WITH ' .. InjuryType .. '.')
			elseif InjuryLength == 11 then
				os.execute('start cmd /k echo Injured Goalie Diagnosis: ' .. GoalieFName .. ' ' .. GoalieLName .. ' IS OUT FOR THE REMAINDER OF THE SEASON WITH ' .. InjuryType .. ' (Injury Number ' .. InjuryNumber .. ').')
			else
				os.execute('start cmd /k echo Injured Goalie Diagnosis: ' .. GoalieFName .. ' ' .. GoalieLName .. ' IS OUT FOR ' .. InjuryLength .. InjuryTime .. ' WITH ' .. InjuryType .. ' (Injury Number ' .. InjuryNumber .. ').')
			end
			if Launcher.Game.Period() == 3 then
				Diagnosis = 2
			else
				Diagnosis = 0
			end
		end
	end
-- This handles the random chance of a forward or defenceman suffering a simulated in-game injury
	if OnlinePlay == false and SkaterInjuries == true and DiagnosisSkater == 0 and Launcher.Game.Time() > 450 and Launcher.Game.Period() < 4 then
		InjuredSkaterChance = math.random ()
		if InjuredSkaterChance < (SkaterInjuryChance / 100) then
			InjuredSkater = math.random (0, 39)
			if (InjuredSkater < 20 and (ControllerOnlyInjuries == false or (ControllerOnlyInjuries == true and HomeController == 1))) or (InjuredSkater > 19 and (ControllerOnlyInjuries == false or (ControllerOnlyInjuries == true and AwayController == 1))) then
				if InjuredSkater ~= 18 and InjuredSkater ~= 19 and InjuredSkater ~= 38 and InjuredSkater ~= 39 then
					InjuredSkaterChanceCount = InjuredSkaterChanceCount + 1
					if InjuredSkaterChanceCount == 2 then
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+InjuredSkater*4) + 0x7C + attributecount
							Value = players[InjuredSkater] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[InjuredSkater] [attributecount] = NewValue
						end
						if InjuredSkater < 20 then
							os.execute('start cmd /k echo ' .. Launcher.Player.FirstName(InjuredSkater) .. ' ' .. Launcher.Player.LastName(InjuredSkater) .. ' (' .. Launcher.Game.HomeNameAbbreviation() .. ') is injured.  His performance will be reduced.  Recommend removing him from the lineup.')
						else
							os.execute('start cmd /k echo ' .. Launcher.Player.FirstName(InjuredSkater) .. ' ' .. Launcher.Player.LastName(InjuredSkater) .. ' (' .. Launcher.Game.AwayNameAbbreviation() .. ') is injured.  His performance will be reduced.  Recommend removing him from the lineup.')
						end
						if SkaterDiagnosis == true then
							DiagnosisSkater = 1
							SkaterFName = Launcher.Player.FirstName(InjuredSkater)
							SkaterLName = Launcher.Player.LastName(InjuredSkater)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 600 then
								SkaterWhistles = 3
							else
								SkaterWhistles = math.random (10, 25)
							end
						end
					end
				end
			end
		end
	end
-- This decides the fate of the injured forward or defenceman if the "SkaterDiagnosis" option is enabled
	if SkaterDiagnosis == true and DiagnosisSkater == 1 and OnlinePlay == false then
		SkaterWhistles = SkaterWhistles - 1
		if (PPT == 0 and SkaterWhistles <= 0) or (Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300) then
			InjuryNumber = math.random (7, 23)
			if InjuryNumber == 7 then
				InjuryType = "A SHATTERED RIGHT HEEL"
			elseif InjuryNumber == 8 then
				InjuryType = "A SPRAINED ANKLE"
			elseif InjuryNumber == 9 then
				InjuryType = "A TORN ACL"
			elseif InjuryNumber == 10 then
				InjuryType = "A CHARLEY HORSE"
			elseif InjuryNumber == 11 then
				InjuryType = "A PULLED GROIN"
			elseif InjuryNumber == 12 then
				InjuryType = "A HIP INJURY"
			elseif InjuryNumber == 13 then
				InjuryType = "A HERNIA"
			elseif InjuryNumber == 14 then
				InjuryType = "A STRAINED RIB MUSCLE"
			elseif InjuryNumber == 15 then
				InjuryType = "A BRUISED BACK"
			elseif InjuryNumber == 16 then
				InjuryType = "A TORN ROTATOR CUFF"
			elseif InjuryNumber == 17 then
				InjuryType = "A FRACTURED LEFT FOREARM"
			elseif InjuryNumber == 18 then
				InjuryType = "A FRACTURED RIGHT ELBOW"
			elseif InjuryNumber == 19 then
				InjuryType = "A BROKEN WRIST"
			elseif InjuryNumber == 20 then
				InjuryType = "A SORE FINGER"
			elseif InjuryNumber == 21 then
				InjuryType = "AN INJURED COLLARBONE"
			elseif InjuryNumber == 22 then
				InjuryType = "A FRACTURED CHEEKBONE"
			else
				InjuryType = "A CONCUSSION"
			end
			InjuryLength = math.random (2, 10)
			InjuryTime = " WEEKS"
			if InjuryNumber == 9 or InjuryNumber == 17 or InjuryNumber == 19 then
				InjuryLength = 11
			elseif InjuryNumber == 8 or InjuryNumber == 10 or InjuryNumber == 12 or InjuryNumber == 14 or InjuryNumber == 20 then
				InjuryLength = 0
			end
			if InjuryLength == 0 then
				os.execute('start cmd /k echo Injured Skater Diagnosis: ' .. SkaterFName .. ' ' .. SkaterLName .. ' IS OUT FOR THE REMAINDER OF THIS GAME ONLY WITH ' .. InjuryType .. '.')
			elseif InjuryLength == 11 then
				os.execute('start cmd /k echo Injured Skater Diagnosis: ' .. SkaterFName .. ' ' .. SkaterLName .. ' IS OUT FOR THE REMAINDER OF THE SEASON WITH ' .. InjuryType .. ' (Injury Number ' .. InjuryNumber .. ').')
			else
				os.execute('start cmd /k echo Injured Skater Diagnosis: ' .. SkaterFName .. ' ' .. SkaterLName .. ' IS OUT FOR ' .. InjuryLength .. InjuryTime .. ' WITH ' .. InjuryType .. ' (Injury Number ' .. InjuryNumber .. ').')
			end
			if Launcher.Game.Period() == 3 then
				DiagnosisSkater = 2
			else
				DiagnosisSkater = 0
				InjuredSkaterChanceCount = 0
			end
		end
	end
end
function FaceOffStartedCallback()
	if FirstFaceoff == 0 then
		UseCutSceneFunction = 1		
-- This picks a random time remaining in the period for the "snow debris" buildup if that option is active
		if SnowyIce == true then
			SnowyTime = math.random(210, 420)
		end
-- This ensures that ShotFlow is active if using the "Jail Break" rule
		if JailBreakGoals == true and ShotFlow == false then
			JailBreakGoals = false
		end
-- This ensures that the WildShot ranges were set correctly
		if WildShotRangeHigh < WildShotRange then
			WildShotRangeHigh = WildShotRange * 2
		end
-- This sets the length of time that the initial shots will miss if the "FirstShotsMiss" option is enabled
		if FirstShotsMiss == true then
			if FirstShotsMaxTime < 30 then
				FirstShotsMaxTime = 45
			end
			FirstShotsLength = 1200 - (math.random(30, FirstShotsMaxTime))
		end
-- This disables the misconduct penalties to avoid issues if the "All Majors" game mode is set to true
		if AllMajorPenalties == true then
			Misconducts = false
		end
-- This makes sure there is a sufficient enough value if the Bumpy Ice option is active
		if BumpyIce == true and BumpyHeightLimit < 20 then
			BumpyHeightLimit = 20
		end
-- This randomizes the ShotsPerMinute value for the period if the Shots Randomizer option is set to true
		if ShotsRandomizer == true and OnlinePlay == false then
			ShotsPlusMinus = math.random ()
			if ShotsPlusMinus > 0.5 then
				ShotsPlus = (math.random (0, ShotsRandomizerAmount)) / 100
				ShotsPerMinute = ShotsPerMinute + ShotsPlus
			else
				ShotsMinus = (math.random (0, ShotsRandomizerAmount)) / 100
				ShotsPerMinute = ShotsPerMinute - ShotsMinus
			end
		end
-- This sets penalty chances and timing options depending on what game mode is being played
		if RealTime == true or FirsttoThree == true then
			RealTime = true
			ShotFlowPP = false
			if RealTimeStartInThird == true then
				ShotFlow = false
				Launcher.Game.SetPeriod(3)
			end
			Launcher.Game.SetTimer(28)
			Launcher.Game.SetPenaltyTimer(28)
		end		
		if ShotFlow == true then
			Launcher.Game.SetTimer(CurrentTimer)
		end
		if APFrequency == 1 then
			RoughingChance = 0.0125
			RoughingMisconduct = 0.975
			DoubleMinorChance = 0.975
			MajorChance = 0.0125
			MajorMisconduct = 0.01
		elseif APFrequency == 2 then
			RoughingChance = 0.033
			RoughingMisconduct = 0.95
			DoubleMinorChance = 0.95
			MajorChance = 0.033
			MajorMisconduct = 0.025
		elseif APFrequency == 3 then
			RoughingChance = 0.075
			RoughingMisconduct = 0.875
			DoubleMinorChance = 0.9
			MajorChance = 0.075
			MajorMisconduct = 0.05
		elseif APFrequency == 4 then
			RoughingChance = 0.0125
			RoughingMisconduct = 0.975
			DoubleMinorChance = 0.85
			MajorChance = 0.15
			MajorMisconduct = 0.125
		else
			RoughingChance = 0.033
			RoughingMisconduct = 0.95
			DoubleMinorChance = 0.95
			MajorChance = 0.033
			MajorMisconduct = 0.025
		end
-- This ensures a proper value is set for Wild Shot Range
		if WildShotRange < 1 then
			WildShotRange = 1
		end
	end
-- This resets the previous pause of the Wild Shot system, if applicable
	if WildShot == true and WildShotPause == true then
		WildShotPause = false
	end
-- This resets the eligibility of an enforcement of a missed shot
	if WildShot == true then
		ForceMissed = 0
	end
-- This resets the eligibility of the possibility of a puck being sent out of play for a Delay of Game penalty
	if DelayPenalty == true then
		StopforDelay = 0
	end
-- This pauses the Wild Shot system if there is an active Power Play and the option to disable missed shots on Power Plays is enabled
	PPT = Launcher.Game.PowerplayTime()
	if WildShot == true and MissedPP == 0 and PPT > 0 and OnlinePlay == false then
		MissedPPPause = true
	elseif WildShot == true and MissedPP > 0 and PPT > 0 and OnlinePlay == false then
		MissedPPPercent = math.random ()
		if MissedPPPercent < (MissedPP / 100) then
			MissedPPPause = false
		else
			MissedPPPause = true
		end
	else
		MissedPPPause = false
	end																																	
-- This keeps track of the total faceoffs for use with the Game Flow system
	TotalFaceoffs = TotalFaceoffs + 1
-- This updates hit totals to avoid roughing situations that occurred prior to this faceoff being penalized right after this faceoff
	if FirstFaceoff ~= 0 then
		for loopcount=0, 39 do
			if hittotals[loopcount] ~= Launcher.Player.Hits(loopcount) then
				hittotals[loopcount] = Launcher.Player.Hits(loopcount)
			end
		end
	end
-- This resets the period and clock to one second remaining in the third period to complete the setup for the hybrid 3-on-3 OT if it's active
	if ThreeonThreeOT == true and Launcher.Game.Period() == 4 and ThreeonThree == 1 then
		Launcher.Game.SetPeriod(3)
		Launcher.Game.SetTime(1)
		ThreeonThree = 2
	end
-- This randomizes how quickly or how slowly the referee drops the puck during a face-off
	if RandomPuckDrops == true and OnlinePlay == false then
		PuckDropTime = math.random (35, 127)
		Launcher.Game.SetPuckDropTime(PuckDropTime,60)
-- This defines the parameters for a false start on a face-off and stops play if they are valid
		CurrentTime = math.floor(Launcher.Game.Time())
		if FalseStarts == true and FirstFaceoff ~= 0 and PPT == 0 and CurrentTime > 60 and SetIcingLine == 0 and FalseStartsMax > 0 then
			FalseStartChance = math.random ()
			if FalseStartChance > 0.95 then
				FalseStartsMax = FalseStartsMax - 1
				FalseStartDelay = 1
				FalseStartTime = CurrentTime
			end
		end
	end
-- This saves the original attributes of all 40 dressed players to be reloaded prior to each subsequent face-off
	if FirstFaceoff == 0 then
		players = {}
		for loopcount=0, 39 do
			players[loopcount] = {}
			for attributecount =0, 16 do
				Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
				Value = Launcher.Mem.Byte(Pointer)
				if loopcount == 18 or loopcount == 19 then
					if attributecount == 4 then
						Value = math.floor(Value * (HomeGloveHigh / 100))
					elseif attributecount == 5 then
						Value = math.floor(Value * (HomeGloveLow / 100))
					elseif attributecount == 7 then
						Value = math.floor(Value * (HomeStickLow / 100))
					elseif attributecount == 9 then
						Value = math.floor(Value * (HomeFiveHole / 100))
					elseif attributecount == 16 then
						Value = math.floor(Value * (HomeStickHigh / 100))
					end
				elseif loopcount == 38 or loopcount == 39 then
					if attributecount == 4 then
						Value = math.floor(Value * (AwayGloveHigh / 100))
					elseif attributecount == 5 then
						Value = math.floor(Value * (AwayGloveLow / 100))
					elseif attributecount == 7 then
						Value = math.floor(Value * (AwayStickLow / 100))
					elseif attributecount == 9 then
						Value = math.floor(Value * (AwayFiveHole / 100))
					elseif attributecount == 16 then
						Value = math.floor(Value * (AwayStickHigh / 100))
					end
				end
				players[loopcount] [attributecount] = Value
			end
		end
-- This sets up an array to keep track of which players have dished out hits in order to assess Roughing, Double Minor and Major penalties
		hittotals = {}
		for loopcount=0, 39 do
			hittotals[loopcount] = Launcher.Player.Hits(loopcount)
		end
-- This determines whether the game is using default or no-touch icing and disables the Icing Line Management if using default icing
		IcingType = Launcher.Mem.Byte(0x4b48eb)
		if IcingType == 235 then
			NoTouchIcing = false
			IcingLineManagement = false
		else
			NoTouchIcing = true
		end
    end
-- This attempts to balance the face-off win percentages between the two teams if the "BalancedFaceoffs" option is active
	if BalancedFaceoffs == true then
		FaceOffHome = Launcher.Stats.HomeFaceoffsWon() - Launcher.Stats.AwayFaceoffsWon()
		FaceOffVis = Launcher.Stats.AwayFaceoffsWon() - Launcher.Stats.HomeFaceoffsWon()
		if FirstFaceoff == 0 and OnlinePlay == false then
			RandomFaceoff = math.random (1,99)
			Launcher.Player.AllSetAttribute(9,RandomFaceoff,0,true)
			RandomFaceoff = math.random (1,99)
			Launcher.Player.AllSetAttribute(9,RandomFaceoff,1,true)
		elseif FirstFaceoff == 0 then
			Launcher.Player.AllSetAttribute(9,99,0,true)
			Launcher.Player.AllSetAttribute(9,99,1,true)
		elseif FaceOffHome > 3 then
			Launcher.Player.AllSetAttribute(9,1,0,true)
			Launcher.Player.AllSetAttribute(9,50,1,true)
		elseif FaceOffVis > 3 then
			Launcher.Player.AllSetAttribute(9,50,0,true)
			Launcher.Player.AllSetAttribute(9,1,1,true)
		else
			Launcher.Player.AllSetAttribute(9,50,0,true)
			Launcher.Player.AllSetAttribute(9,50,1,true)
		end
	end
-- This contains most of the player attribute tweaks (some are defined below in the PassCallback section)
	if AccelTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Accel = 1 - (RandomVariation / 100)
		else
			Accel = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(1,Accel,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Accel = 1 - (RandomVariation / 100)
		else
			Accel = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(1,Accel,1,true)
	else
		Accel = AccelTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(1,Accel,0,true)
		Launcher.Player.AllSetAttributeMultiplier(1,Accel,1,true)
	end
	if AgilityTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Agility = 1 - (RandomVariation / 100)
		else
			Agility = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Agility = 1 - (RandomVariation / 100)
		else
			Agility = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,1,true)
	else
		Agility = AgilityTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,0,true)
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,1,true)
	end
	if BalanceTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Balance = 1 - (RandomVariation / 100)
		else
			Balance = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(3,Balance,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Balance = 1 - (RandomVariation / 100)
		else
			Balance = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(3,Balance,1,true)
	else
		Balance = BalanceTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(3,Balance,0,true)
		Launcher.Player.AllSetAttributeMultiplier(3,Balance,1,true)
	end
	if PowerTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			ShotPower = 1 - (RandomVariation / 100)
		else
			ShotPower = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			ShotPower = 1 - (RandomVariation / 100)
		else
			ShotPower = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,true)
	else
		ShotPower = PowerTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,true)
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,true)
	end
	if AccuracyTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			ShotAccuracy = 1 - (RandomVariation / 100)
		else
			ShotAccuracy = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAccuracy,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			ShotAccuracy = 1 - (RandomVariation / 100)
		else
			ShotAccuracy = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAccuracy,1,true)
	else
		ShotAccuracy = AccuracyTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAccuracy,0,true)
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAccuracy,1,true)
	end
	if DekingTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Deking = 1 - (RandomVariation / 100)
		else
			Deking = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Deking = 1 - (RandomVariation / 100)
		else
			Deking = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,1,true)
	else
		Deking = DekingTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,0,true)
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,1,true)
	end
	if PuckControlTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			PuckControl = 1 - (RandomVariation / 100)
		else
			PuckControl = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(8,PuckControl,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			PuckControl = 1 - (RandomVariation / 100)
		else
			PuckControl = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(8,PuckControl,1,true)
	else
		PuckControl = PuckControlTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(8,PuckControl,0,true)
		Launcher.Player.AllSetAttributeMultiplier(8,PuckControl,1,true)
	end
	if AggressionTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Aggression = 1 - (RandomVariation / 100)
		else
			Aggression = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(10,Aggression,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Aggression = 1 - (RandomVariation / 100)
		else
			Aggression = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(10,Aggression,1,true)
	else
		Aggression = AggressionTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(10,Aggression,0,true)
		Launcher.Player.AllSetAttributeMultiplier(10,Aggression,1,true)
	end
	if EnduranceTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Endurance = 1 - (RandomVariation / 100)
		else
			Endurance = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Endurance = 1 - (RandomVariation / 100)
		else
			Endurance = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,1,true)
	else
		Endurance = EnduranceTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,0,true)
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,1,true)
	end
	if PenaltyTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Penalty = 1 - (RandomVariation / 100)
		else
			Penalty = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(14,Penalty,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Penalty = 1 - (RandomVariation / 100)
		else
			Penalty = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(14,Penalty,1,true)
	else
		Penalty = PenaltyTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(14,Penalty,0,true)
		Launcher.Player.AllSetAttributeMultiplier(14,Penalty,1,true)
	end
	if ToughnessTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Toughness = 1 - (RandomVariation / 100)
		else
			Toughness = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(15,Toughness,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Toughness = 1 - (RandomVariation / 100)
		else
			Toughness = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(15,Toughness,1,true)
	else
		Toughness = ToughnessTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(15,Toughness,0,true)
		Launcher.Player.AllSetAttributeMultiplier(15,Toughness,1,true)
	end
	if InjuryChance == 0 then
		Launcher.Player.AllSetAttribute(16,99,0,true)
		Launcher.Player.AllSetAttribute(16,99,1,true)
	elseif InjuryChance == 1 then
		Injuries = math.random (50, 99)
		Launcher.Player.AllSetAttribute(16,Injuries,0,true)
		Injuries = math.random (50, 99)
		Launcher.Player.AllSetAttribute(16,Injuries,1,true)
	elseif InjuryChance == 2 then
		Injuries = math.random (50, 75)
		Launcher.Player.AllSetAttribute(16,Injuries,0,true)
		Injuries = math.random (50, 75)
		Launcher.Player.AllSetAttribute(16,Injuries,1,true)
	end
-- This disables the code that needs to be executed only on the first face-off of the game
	if FirstFaceoff == 0 then
		FirstFaceoff = 1
	end
-- This checks whether or not to reset the pause on Additional Penalties if there was a fight earlier
	if APPause == true then
		if Launcher.Game.Time() < APTimer then
			APPause = false
			APTimer = 0
		end
	end
-- This handles the "Jail Break" function of terminating a penalty for a shorthanded goal
	if JailBreakActive == 3 then
		JailBreakAwaySHG = Launcher.Stats.AwayShortHandedGoals()
		JailBreakHomeSHG = Launcher.Stats.HomeShortHandedGoals()
		JailBreakActive = 0
		Launcher.Game.SetPeriod(JailBreakResetPeriod)
		Launcher.Game.SetTime(JailBreakResetClock)
		Launcher.Game.SetTimer(28)
		Launcher.Game.SetPenaltyTimer(28)
	end
	if JailBreakActive == 1 then
		if JailBreakAwaySHG ~= Launcher.Stats.AwayShortHandedGoals() or JailBreakHomeSHG ~= Launcher.Stats.HomeShortHandedGoals() then
			JailBreakActive = 2
			JailBreakResetClock = Launcher.Game.Time()
			JailBreakResetPeriod = Launcher.Game.Period()
		end
	end
-- This checks to see which controllers, if any, are enabled
		if Launcher.Game.ControllerTeam(0) == 0 or Launcher.Game.ControllerTeam(1) == 0 then
			HomeController = 1
		else
			HomeController = 0
		end
		if Launcher.Game.ControllerTeam(0) == 1 or Launcher.Game.ControllerTeam(1) == 1 then
			AwayController = 1
		else
			AwayController = 0
		end
end
function PassCallback()
-- This creates the possibility of a fanned pass if that option is active
	if FannedPasses == true and FannedActive == 0 then
		FannedPassChance = math.random (0, 100)
		if FannedPassChance <= FannedPercentage then
			FannedActive = 1
			FannedSpeed = StartPassSpeed * (math.random(25,75) / 100)
			Launcher.Physics.SetPassBaseSpeed(FannedSpeed)
		elseif FannedCentering == true and FannedPassChance <= 50 then
			x, y, z = Launcher.Game.PuckPosition()
			if z < -4200 or z > 4200 then
				FannedActive = 1
				FannedSpeed = StartPassSpeed * (math.random(25,50) / 100)
				Launcher.Physics.SetPassBaseSpeed(FannedSpeed)
			end
		end
	else
		FannedActive = 0
		Launcher.Physics.SetPassBaseSpeed(PassSpeed)
	end
-- This prepares for a missed shot if the goalie plays the puck directly to an opponent
	if GoofyGoalie > 0 then
		if GoofyGoalie == 1 and GoaliePass == 0 and (Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19 or Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) then
			GoaliePass = 2
		elseif GoofyGoalie == 2 and GoaliePass == 0 and ((Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19) and HomeController == 1) or ((Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) and AwayController == 1) then
			GoaliePass = 2
		end
	end
-- If an icing call just occurred, this forces the line that iced the puck back onto the ice if the "IcingLineManagement" option is set to true
	if SetIcingLine == 2 and IcingLineManagement == true and PPT == 0 then
		if IcingAwayLine == -1 then
			CurrentLine = Launcher.Game.HomeLine()
			if CurrentLine == IcingHomeLine then
				IcingHomeLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(0,IcingHomeLine)
				SetIcingLine = 0
			end
		else
			CurrentLine = Launcher.Game.AwayLine()
			if CurrentLine == IcingAwayLine then
				IcingAwayLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(1,IcingAwayLine)
				SetIcingLine = 0
			end
		end
	end
-- This checks for pending Major or Misconduct penalties
	if Majors == 1 then
		Majors = 2
	elseif MisconductPenalty == 1 then
		MisconductPenalty = 2
	end
-- This resets the strange bounce option if active
	if StrangeBounceChance > 0.75 and DeterioratingIce == true and OnlinePlay == false then
		Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
	end
-- This section contains tweaks related to passing and checking
	if PassingTweak == 0 then
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Passing = 1 - (RandomVariation / 100)
		else
			Passing = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(6,Passing,0,true)
		UporDown = math.random ()
		RandomVariation = math.random (0,Variation)
		if UporDown < 0.5 then
			Passing = 1 - (RandomVariation / 100)
		else
			Passing = 1 + (RandomVariation / 100)
		end
		Launcher.Player.AllSetAttributeMultiplier(6,Passing,1,true)
	else
		Passing = PassingTweak / 100
		Launcher.Player.AllSetAttributeMultiplier(6,Passing,0,true)
		Launcher.Player.AllSetAttributeMultiplier(6,Passing,1,true)
	end
	if CheckingTweak == true and OnlinePlay == false then
		Checking = math.random ()
		if Checking < 0.5 then
			if BigHits == true then
				if Checking < 0.075 then
					Checking = 2.5
				elseif Checking < 0.125 then
					Checking = 2.25
				elseif Checking < 0.175 then
					Checking = 2
				else
					Checking = 0.75
				end
			else
				Checking = 0.75
			end
		end
		Launcher.Player.AllSetAttributeMultiplier(11,Checking,0,true)
		Launcher.Player.AllSetAttributeMultiplier(11,Checking,1,true)
	end
-- This section is only performed if either no regular penalty is pending or a Misconduct penalty is pending
	PenaltyPending = Launcher.Mem.Byte(0x79B9BC)
	if (PenaltyPending == 0 or Majors == 2 or MisconductPenalty == 2) and OnlinePlay == false then
-- This sets up the Game Misconduct penalty connected with the previous Major for Checking from Behind
		if MajorPenalties == true and Misconducts == true and Majors == 2 then
			if MajorHomePlayer >= 0 then
				FixAwayMisconduct = 1
				ExpectedAwayTotalPP = Launcher.Stats.AwayPowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				FixHomeMisconduct = 1
				ExpectedHomeTotalPP = Launcher.Stats.HomePowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			Majors = 3
			Launcher.Game.StopPlay()
		end
-- This sets up the Game Misconduct penalty connected with the previous minor for Roughing
		if MajorPenalties == true and Misconducts == true and MisconductPenalty == 2 then
			if MajorHomePlayer >= 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			MisconductPenalty = 3
			Launcher.Game.StopPlay()
		end
-- This triggers the chance at Minor, Double Minor or Major penalties relating to what the game considers a "Hit" in the stats
		CurrentHitCount = 0
		BigHitPlayer = -1
		for loopcount=0, 39 do
			if hittotals[loopcount] ~= Launcher.Player.Hits(loopcount) then
				CurrentHitCount = CurrentHitCount + 1
				if loopcount ~= ExclPID1 and loopcount ~= ExclPID2 and loopcount ~= ExclPID3 and loopcount ~= ExclPID4 and loopcount ~= ExclPID5 and loopcount ~= ExclPID6 then
					BigHitPlayer = loopcount	
				end
			end
		end
		CurrentTime = Launcher.Game.Time()
		if CurrentHitCount > 0 and Checking == 2.5 and Majors == 0 and CurrentTime > 300 then
			MajorTrigger = 1
		elseif CurrentHitCount > 0 and Checking > 2 and Majors == 0 and CurrentTime > 300 then
			MajorTrigger = 2
		else
			MajorTrigger = 0
		end
-- This assesses the coincidental minor penalty if that option is enabled
		if CoincidentalMinor > 0 and AdditionalPenalties == true and CoincidentalMinors == true and APMaximum > 0 and APPause == false then
			APMaximum = APMaximum - 1
			PenaltySet = 0
			repeat
				PenaltyPlayer = math.random (0,17)
				if PenaltyPlayer ~= ExclPID1 and PenaltyPlayer ~= ExclPID2 and PenaltyPlayer ~= ExclPID3 and PenaltyPlayer ~= ExclPID4 and PenaltyPlayer ~= ExclPID5 and PenaltyPlayer ~= ExclPID6 then
					PenaltySet = 1
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 or ExclPID1Time < 0 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 or ExclPID2Time < 0 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 or ExclPID3Time < 0 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 or ExclPID4Time < 0 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 or ExclPID5Time < 0 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 or ExclPID6Time < 0 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
				end
			until PenaltySet == 1
			RandPenalty = math.random (21,45)
			if RandPenalty == 33 or (RandPenalty > 37 and RandPenalty < 43) then
				RandPenalty = math.random (21,29)
			end
			if CoincidentalPenaltyTeam == 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				if AllMajorPenalties == true then
					Launcher.Game.SetPenaltyPendingTime(8)
					AwayFixPending = 1
					AwayFixGoals = Launcher.Stats.AwayGoals()
				else
					Launcher.Game.SetPenaltyPendingTime(2)
				end
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				if AllMajorPenalties == true then
					Launcher.Game.SetPenaltyPendingTime(8)
					HomeFixPending = 1
					HomeFixGoals = Launcher.Stats.HomeGoals()
				else
					Launcher.Game.SetPenaltyPendingTime(2)
				end
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			if ExclPID1 == -1 then
				ExclPID1 = PenaltyPlayer
			elseif ExclPID2 == -1 then
				ExclPID2 = PenaltyPlayer
			elseif ExclPID3 == -1 then
				ExclPID3 = PenaltyPlayer
			elseif ExclPID4 == -1 then
				ExclPID4 = PenaltyPlayer
			elseif ExclPID5 == -1 then
				ExclPID5 = PenaltyPlayer
			else
				ExclPID6 = PenaltyPlayer
			end
			CoincidentalMinor = 0
			ScriptedPending = 1
-- This creates a long 5-on-3 situation if that option is enabled
		elseif L5on3 > 0 and AdditionalPenalties == true and Long5on3 == true and APMaximum > 0 and APPause == false then
			APMaximum = APMaximum - 1
			PenaltySet = 0
			repeat
				PenaltyPlayer = math.random (0,17)
				if PenaltyPlayer ~= ExclPID1 and PenaltyPlayer ~= ExclPID2 and PenaltyPlayer ~= ExclPID3 and PenaltyPlayer ~= ExclPID4 and PenaltyPlayer ~= ExclPID5 and PenaltyPlayer ~= ExclPID6 and PenaltyPlayer ~= 18 and PenaltyPlayer ~= 19 then
					PenaltySet = 1
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 or ExclPID1Time < 0 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 or ExclPID2Time < 0 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 or ExclPID3Time < 0 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 or ExclPID4Time < 0 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 or ExclPID5Time < 0 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 or ExclPID6Time < 0 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
				end
			until PenaltySet == 1
			RandPenalty = math.random (21,45)
			if RandPenalty == 33 or (RandPenalty > 37 and RandPenalty < 43) then
				RandPenalty = math.random (21,29)
			end
			if L5on3PenaltyTeam == 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				if AllMajorPenalties == true then
					Launcher.Game.SetPenaltyPendingTime(8)
					AwayFixPending = 1
					AwayFixGoals = Launcher.Stats.AwayGoals()
				else
					Launcher.Game.SetPenaltyPendingTime(2)
				end
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				if AllMajorPenalties == true then
					Launcher.Game.SetPenaltyPendingTime(8)
					HomeFixPending = 1
					HomeFixGoals = Launcher.Stats.HomeGoals()
				else
					Launcher.Game.SetPenaltyPendingTime(2)
				end
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			if ExclPID1 == -1 then
				ExclPID1 = PenaltyPlayer
			elseif ExclPID2 == -1 then
				ExclPID2 = PenaltyPlayer
			elseif ExclPID3 == -1 then
				ExclPID3 = PenaltyPlayer
			elseif ExclPID4 == -1 then
				ExclPID4 = PenaltyPlayer
			elseif ExclPID5 == -1 then
				ExclPID5 = PenaltyPlayer
			else
				ExclPID6 = PenaltyPlayer
			end
			L5on3 = 0
			ScriptedPending = 1
-- If there were no coincidental minor or 5-on-3 situations, check to see if there is a Double Minor for High Sticking
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and DoubleMinorPenalties == true and Checking >= 2 and APMaximum > 0 and APPause == false then
			if MaxDoubleMinors > 0 then
				RandomPenalty = math.random()
				if RandomPenalty > DoubleMinorChance then
					APMaximum = APMaximum - 1
					MaxDoubleMinors = MaxDoubleMinors - 1
					if BigHitPlayer < 20 then
						Launcher.Mem.WriteByte(0x79b3f4, 0)
						Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
						Launcher.Game.SetPenaltyPendingID(28)
						if AllMajorPenalties == true then
							Launcher.Game.SetPenaltyPendingTime(8)
							AwayFixPending = 1
							AwayFixGoals = Launcher.Stats.AwayGoals()
						else
							Launcher.Game.SetPenaltyPendingTime(4)
						end
						Launcher.Mem.WriteByte(0x79B9BC, 1)
					else
						BigHitPlayer = BigHitPlayer - 20
						Launcher.Mem.WriteByte(0x79b3f4, 1)
						Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
						Launcher.Game.SetPenaltyPendingID(28)
						if AllMajorPenalties == true then
							Launcher.Game.SetPenaltyPendingTime(8)
							HomeFixPending = 1
							HomeFixGoals = Launcher.Stats.HomeGoals()
						else
							Launcher.Game.SetPenaltyPendingTime(4)
						end
						Launcher.Mem.WriteByte(0x79B9BC, 1)
					end
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 or ExclPID1Time < 0 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 or ExclPID2Time < 0 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 or ExclPID3Time < 0 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 or ExclPID4Time < 0 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 or ExclPID5Time < 0 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 or ExclPID6Time < 0 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
					if ExclPID1 == -1 then
						ExclPID1 = BigHitPlayer
					elseif ExclPID2 == -1 then
						ExclPID2 = BigHitPlayer
					elseif ExclPID3 == -1 then
						ExclPID3 = BigHitPlayer
					elseif ExclPID4 == -1 then
						ExclPID4 = BigHitPlayer
					elseif ExclPID5 == -1 then
						ExclPID5 = BigHitPlayer
					else
						ExclPID6 = BigHitPlayer
					end
					ScriptedPending = 1
				end
			end
-- Now check for a forced Double Minor
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and DoubleMinorPenalties == true and ForceDoubleMinor == 1 and APMaximum > 0 and APPause == false then
			ForceDoubleMinor = 2
			if MaxDoubleMinors > 0 then
				APMaximum = APMaximum - 1
				MaxDoubleMinors = MaxDoubleMinors - 1
				if BigHitPlayer < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(28)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(4)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					BigHitPlayer = BigHitPlayer - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(28)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(4)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				ScriptedPending = 1
			end
-- If there were no Double Minors, check to see if there is a Major for Checking From Behind with a Game Misconduct penalty
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and MajorPenalties == true and Misconducts == true and MajorTrigger == 1 and Majors == 0 and APMaximum > 0 and APPause == false then
			if MaxMajors > 0 then
				RandomPenalty = math.random()
				if RandomPenalty < MajorMisconduct then
					APMaximum = APMaximum - 1
					MaxMajors = MaxMajors - 1
					Majors = 1
					if BigHitPlayer < 20 then
						MajorHomePlayer = BigHitPlayer
						MajorAwayPlayer = -1
						Launcher.Mem.WriteByte(0x79b3f4, 0)
						Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
						Launcher.Game.SetPenaltyPendingID(30)
						Launcher.Game.SetPenaltyPendingTime(8)
						Launcher.Mem.WriteByte(0x79B9BC, 1)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						BigHitPlayer = BigHitPlayer - 20
						MajorAwayPlayer = BigHitPlayer
						MajorHomePlayer = -1
						Launcher.Mem.WriteByte(0x79b3f4, 1)
						Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
						Launcher.Game.SetPenaltyPendingID(30)
						Launcher.Game.SetPenaltyPendingTime(8)
						Launcher.Mem.WriteByte(0x79B9BC, 1)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					end
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 or ExclPID1Time < 0 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 or ExclPID2Time < 0 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 or ExclPID3Time < 0 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 or ExclPID4Time < 0 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 or ExclPID5Time < 0 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 or ExclPID6Time < 0 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
					if ExclPID1 == -1 then
						ExclPID1 = BigHitPlayer
					elseif ExclPID2 == -1 then
						ExclPID2 = BigHitPlayer
					elseif ExclPID3 == -1 then
						ExclPID3 = BigHitPlayer
					elseif ExclPID4 == -1 then
						ExclPID4 = BigHitPlayer
					elseif ExclPID5 == -1 then
						ExclPID5 = BigHitPlayer
					else
						ExclPID6 = BigHitPlayer
					end
					Launcher.Game.StopPlay()
				end
			end
-- If no Major with a Game Misconduct was called, check to see if there is a Major penalty for Checking From Behind
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and MajorPenalties == true and MajorTrigger == 2 and APMaximum > 0 then
			if MaxMajors > 0 and APPause == false then
				RandomPenalty = math.random()
				if RandomPenalty < MajorChance then
					APMaximum = APMaximum - 1
					MaxMajors = MaxMajors - 1
					if BigHitPlayer < 20 then
						MajorHomePlayer = BigHitPlayer
						MajorAwayPlayer = -1
						Launcher.Mem.WriteByte(0x79b3f4, 0)
						Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
						Launcher.Game.SetPenaltyPendingID(30)
						Launcher.Game.SetPenaltyPendingTime(8)
						Launcher.Mem.WriteByte(0x79B9BC, 1)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						BigHitPlayer = BigHitPlayer - 20
						MajorAwayPlayer = BigHitPlayer
						MajorHomePlayer = -1
						Launcher.Mem.WriteByte(0x79b3f4, 1)
						Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
						Launcher.Game.SetPenaltyPendingID(30)
						Launcher.Game.SetPenaltyPendingTime(8)
						Launcher.Mem.WriteByte(0x79B9BC, 1)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					end
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 or ExclPID1Time < 0 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 or ExclPID2Time < 0 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 or ExclPID3Time < 0 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 or ExclPID4Time < 0 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 or ExclPID5Time < 0 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 or ExclPID6Time < 0 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
					if ExclPID1 == -1 then
						ExclPID1 = BigHitPlayer
					elseif ExclPID2 == -1 then
						ExclPID2 = BigHitPlayer
					elseif ExclPID3 == -1 then
						ExclPID3 = BigHitPlayer
					elseif ExclPID4 == -1 then
						ExclPID4 = BigHitPlayer
					elseif ExclPID5 == -1 then
						ExclPID5 = BigHitPlayer
					else
						ExclPID6 = BigHitPlayer
					end
					ScriptedPending = 1
				end
			end
-- Now check for a forced Major
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and MajorPenalties == true and ForceMajor == 1 and APMaximum > 0 and APPause == false then
			ForceMajor = 2
			if MaxMajors > 0 then
				APMaximum = APMaximum - 1
				MaxMajors = MaxMajors - 1
				if BigHitPlayer < 20 then
					MajorHomePlayer = BigHitPlayer
					MajorAwayPlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(41)
					Launcher.Game.SetPenaltyPendingTime(8)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
					AwayFixPending = 1
					AwayFixGoals = Launcher.Stats.AwayGoals()
				else
					BigHitPlayer = BigHitPlayer - 20
					MajorAwayPlayer = BigHitPlayer
					MajorHomePlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(41)
					Launcher.Game.SetPenaltyPendingTime(8)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
					HomeFixPending = 1
					HomeFixGoals = Launcher.Stats.HomeGoals()
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				ScriptedPending = 1
			end
-- If there were no Major or Double Minor penalties called, check to see if there is a Roughing call with a Game Misconduct
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and Misconducts == true and Checking >= 2 and MisconductPenalty == 0 and APMaximum > 0 and APPause == false then
			RandomPenalty = math.random()
			if RandomPenalty > RoughingMisconduct then
				APMaximum = APMaximum - 1
				if BigHitPlayer < 20 then
					MajorHomePlayer = BigHitPlayer
					MajorAwayPlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					BigHitPlayer = BigHitPlayer - 20
					MajorAwayPlayer = BigHitPlayer
					MajorHomePlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				MisconductPenalty = 1
			 	Launcher.Game.StopPlay()
			end
-- Lastly, check to see if there is a Roughing penalty
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and RoughingPenalty == true and APMaximum > 0 and APPause == false then
			RandomPenalty = math.random()
			if RandomPenalty < RoughingChance then
				APMaximum = APMaximum - 1
				if BigHitPlayer < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					BigHitPlayer = BigHitPlayer - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				ScriptedPending = 1
			end
		end
-- This resets the Checking attribute if it was just in play for a big hit
		if CheckingTweak == true and Checking > 1 and OnlinePlay == false then
			Checking = math.random ()
			if Checking < 0.5 then
				Checking = 0.75
			end
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,0,true)
			Checking = math.random ()
			if Checking < 0.5 then
				Checking = 0.75
			end
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,1,true)
		end
	end
-- This enables the chance of the puck bouncing on a rough patch of ice
	CurrentTime = Launcher.Game.Time()
	if BumpyIce == true and BumpyIceActive == 0 and OnlinePlay == false and CurrentTime < 600 then
		RandomBumpyIceChance = math.random ()
		if RandomBumpyIceChance < (BumpyIceChance / 100) then
			BumpyIceActive = 1
			BumpLocation = math.random (-4750, 4750)
		end
	end
end
function PenaltyPendingCallback()
-- This keeps track of which players are in the penalty box to avoid accidental duplicates
	PenaltyTeam = Launcher.Game.PenaltyPendingTeam()
	PPPlayer = Launcher.Game.PenaltyPendingPlayer()
	CurrentTime = Launcher.Game.Time()
	ExclPID1Time = ExclPID1Time - CurrentTime
	ExclPID2Time = ExclPID2Time - CurrentTime
	ExclPID3Time = ExclPID3Time - CurrentTime
	ExclPID4Time = ExclPID4Time - CurrentTime
	ExclPID5Time = ExclPID5Time - CurrentTime
	ExclPID6Time = ExclPID6Time - CurrentTime
	if ExclPID1Time > 360 or ExclPID1Time < 0 then
		ExclPID1 = -1
		ExclPID1Time = CurrentTime
	end
	if ExclPID2Time > 360 or ExclPID2Time < 0 then
		ExclPID2 = -1
		ExclPID2Time = CurrentTime
	end
	if ExclPID3Time > 360 or ExclPID3Time < 0 then
		ExclPID3 = -1
		ExclPID3Time = CurrentTime
	end
	if ExclPID4Time > 360 or ExclPID4Time < 0 then
		ExclPID4 = -1
		ExclPID4Time = CurrentTime
	end
	if ExclPID5Time > 360 or ExclPID5Time < 0 then
		ExclPID5 = -1
		ExclPID5Time = CurrentTime
	end
	if ExclPID6Time > 360 or ExclPID6Time < 0 then
		ExclPID6 = -1
		ExclPID6Time = CurrentTime
	end
	if PPPlayer > 19 then
		PPPlayer = PPPlayer - 20
	end
	if ExclPID1 == -1 then
		ExclPID1 = PPPlayer
	elseif ExclPID2 == -1 then
		ExclPID2 = PPPlayer
	elseif ExclPID3 == -1 then
		ExclPID3 = PPPlayer
	elseif ExclPID4 == -1 then
		ExclPID4 = PPPlayer
	elseif ExclPID5 == -1 then
		ExclPID5 = PPPlayer
	else
		ExclPID6 = PPPlayer
	end
-- This triggers the chance of a scripted coincidental minor penalty being called if that option is enabled
    if AdditionalPenalties == true and CoincidentalMinors == true and OnlinePlay == false and APPause == false and APPause == false then
		RandomPenalty = math.random()
		if RandomPenalty < 0.1 then
			if PenaltyTeam == 0 then
				CoincidentalPenaltyTeam = 1
			else
				CoincidentalPenaltyTeam = 0
			end
			CoincidentalMinor = 1
		end
	end
-- This triggers the chance of a scripted penalty being called against the same team right after the first penalty, creating a long 5-on-3 situation if that option is enabled
    if AdditionalPenalties == true and Long5on3 == true and CoincidentalMinor == 0 and OnlinePlay == false then
		RandomPenalty = math.random()
		if RandomPenalty > 0.95 then
			if PenaltyTeam == 0 then
				L5on3PenaltyTeam = 0
			else
				L5on3PenaltyTeam = 1
			end
			L5on3 = 1
		end
	end
-- This makes all penalites Majors if the "All Majors" game mode is active
	if AllMajorPenalties == true then
		Launcher.Game.SetPenaltyPendingTime(8)
		AwayFixGoals = Launcher.Stats.AwayGoals()
		AwayFixPending = 1
		HomeFixGoals = Launcher.Stats.HomeGoals()
		HomeFixPending = 1
	end
end
function PeriodStartedCallback()
-- Randomizes the seed based on current OS time to produce different sets of random numbers for each period
	math.randomseed(os.time())
-- This resets the physics values to default at the start of each period
	if DeterioratingIce == true then
		Launcher.Physics.SetPuckBoardFriction(StartPuckBoardFriction)
		PuckBoardFriction = StartPuckBoardFriction
		Launcher.Physics.SetPuckBounceFriction(StartPuckBounceFriction)
		Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
		Launcher.Physics.SetPlayerSpeedEnergyMultiplier(StartEnergyMultiplier)
		PuckBounceFriction = Launcher.Mem.Float(0x79C768)
		PuckBoardBounceFriction = Launcher.Mem.Float(0x79C76C)
		Launcher.Physics.SetPuckGravity(StartPuckGravity)
		Launcher.Physics.SetPassBaseSpeed(StartPassSpeed)
		PassSpeed = StartPassSpeed
	end
-- This resets parameters relating to penalties
	BigHitPlayer = -1
	CurrentHitCount = 0
	CoincidentalMinor = 0
	ScriptedPending = 0
	IcingCount = 0
	OffsideCount = 0
	LastIcingTeam = -1
	LastOffsideTeam = -1
	ExclPID1Time = 1200
	ExclPID2Time = 1200
	ExclPID3Time = 1200
	ExclPID4Time = 1200
	ExclPID5Time = 1200
	ExclPID6Time = 1200
	if Launcher.Game.Period() == 4 and (Launcher.GameOption.OTMode() == 3 or Launcher.GameOption.OTMode() == 4) then
		ExclPID1Time = 300
		ExclPID2Time = 300
		ExclPID3Time = 300
		ExclPID4Time = 300
		ExclPID5Time = 300
		ExclPID6Time = 300
	end
-- This randomizes the ShotsPerMinute value for the period if the Shots Randomizer option is set to true
	if ShotsRandomizer == true and OnlinePlay == false then
		ShotsPerMinute = OriginalShotsPerMinute
		ShotsPlusMinus = math.random ()
		if ShotsPlusMinus > 0.5 then
			ShotsPlus = (math.random (0, ShotsRandomizerAmount)) / 100
			ShotsPerMinute = ShotsPerMinute + ShotsPlus
		else
			ShotsMinus = (math.random (0, ShotsRandomizerAmount)) / 100
			ShotsPerMinute = ShotsPerMinute - ShotsMinus
		end
	end
-- This increases the chances of Bumpy Ice each period if the progressive switch for Bumpy Ice is set to true
	if BumpyIceChanceHigher == true and OnlinePlay == false then
		BumpyIceUp = ((math.random (1, 25)) / 100) + 1
		BumpyIceChance = math.floor(BumpyIceChance * BumpyIceUp)
	end
-- This may or may not adjust the attributes based on which coach's influence options are set and how the game is going
	if AwayCoachInfluence > 0 and Launcher.Game.Period() > 1 then
		if AwayCoachInfluence == 1 and (Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals()) then
			for loopcount=20, 37 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					AwayCoachAttribute = math.random()
					if AwayCoachAttribute > 0.67 then
						Value = math.floor(Value * AwayCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end
		elseif AwayCoachInfluence == 2 and ((Launcher.Stats.HomeGoals() >= Launcher.Stats.AwayGoals()) or (Launcher.Stats.HomeShots() > Launcher.Stats.AwayShots())) then
			for loopcount=20, 37 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					AwayCoachAttribute = math.random()
					if AwayCoachAttribute > 0.75 then
						Value = math.floor(Value * AwayCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end			
		elseif AwayCoachInfluence == 3 then
			for loopcount=20, 37 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					AwayCoachAttribute = math.random()
					if AwayCoachAttribute < 0.25 then
						AwayCoachAttribute = AwayCoachAttribute + 1
					end
					if AwayCoachAttribute > 0.89 and AwayCoachAttribute < 1.11 then
						Value = math.floor(Value * AwayCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end	
		elseif AwayCoachInfluence == 4 and ((Launcher.Stats.HomeGoals() >= Launcher.Stats.AwayGoals()) or (Launcher.Stats.HomeShots() > Launcher.Stats.AwayShots())) then
			for loopcount=20, 37 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					AwayCoachAttribute = math.random() + 1
					if AwayCoachAttribute > 1 and AwayCoachAttribute < 1.25 then
						Value = math.floor(Value * AwayCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end	
		elseif AwayCoachInfluence == 5 and (Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals()) then
			for loopcount=20, 37 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					AwayCoachAttribute = math.random() + 1
					if AwayCoachAttribute > 1 and AwayCoachAttribute < 1.33 then
						Value = math.floor(Value * AwayCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end	
		end
	end
	if HomeCoachInfluence > 0 and Launcher.Game.Period() > 1 then
		if HomeCoachInfluence == 1 and (Launcher.Stats.AwayGoals() > Launcher.Stats.HomeGoals()) then
			for loopcount=0, 17 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					HomeCoachAttribute = math.random()
					if HomeCoachAttribute > 0.67 then
						Value = math.floor(Value * HomeCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end
		elseif HomeCoachInfluence == 2 and ((Launcher.Stats.AwayGoals() >= Launcher.Stats.HomeGoals()) or (Launcher.Stats.AwayShots() > Launcher.Stats.HomeShots())) then
			for loopcount=0, 17 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					HomeCoachAttribute = math.random()
					if HomeCoachAttribute > 0.75 then
						Value = math.floor(Value * HomeCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end			
		elseif HomeCoachInfluence == 3 then
			for loopcount=0, 17 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					HomeCoachAttribute = math.random()
					if HomeCoachAttribute < 0.25 then
						HomeCoachAttribute = HomeCoachAttribute + 1
					end
					if HomeCoachAttribute > 0.89 and HomeCoachAttribute < 1.11 then
						Value = math.floor(Value * HomeCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end	
		elseif HomeCoachInfluence == 4 and ((Launcher.Stats.AwayGoals() >= Launcher.Stats.HomeGoals()) or (Launcher.Stats.AwayShots() > Launcher.Stats.HomeShots())) then
			for loopcount=0, 17 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					HomeCoachAttribute = math.random() + 1
					if HomeCoachAttribute > 1 and HomeCoachAttribute < 1.25 then
						Value = math.floor(Value * HomeCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end	
		elseif HomeCoachInfluence == 5 and (Launcher.Stats.AwayGoals() > Launcher.Stats.HomeGoals()) then
			for loopcount=0, 17 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					HomeCoachAttribute = math.random() + 1
					if HomeCoachAttribute > 1 and HomeCoachAttribute < 1.33 then
						Value = math.floor(Value * HomeCoachAttribute)
						Launcher.Mem.WriteByte(Pointer, Value)
					end
				end
			end	
		end
	end
-- This may or may not adjust the influence level of the coaches for the next period based on randomness and the current state of the game
	if AwayCoachInfluence > 0 and Launcher.Game.Period() > 1 then
		if (AwayCoachInfluence == 5 or AwayCoachInfluence == 4) and Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals() then
			AwayCoachAttribute = math.random()
			if AwayCoachAttribute > 0.9 then
				AwayCoachInfluence = AwayCoachInfluence - 1
			end
		elseif AwayCoachInfluence == 3 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
			AwayCoachAttribute = math.random()
			if AwayCoachAttribute > 0.9 then
				AwayCoachInfluence = AwayCoachInfluence - 1
			elseif AwayCoachAttribute < 0.1 then
				AwayCoachInfluence = AwayCoachInfluence + 1
			end
		elseif (AwayCoachInfluence == 2 or AwayCoachInfluence == 1) and Launcher.Stats.HomeGoals() < Launcher.Stats.AwayGoals() then
			AwayCoachAttribute = math.random()
			if AwayCoachAttribute > 0.9 then
				AwayCoachInfluence = AwayCoachInfluence + 1
			end
		end
	end
	if HomeCoachInfluence > 0 and Launcher.Game.Period() > 1 then
		if (HomeCoachInfluence == 5 or HomeCoachInfluence == 4) and Launcher.Stats.HomeGoals() < Launcher.Stats.AwayGoals() then
			HomeCoachAttribute = math.random()
			if HomeCoachAttribute > 0.9 then
				HomeCoachInfluence = HomeCoachInfluence - 1
			end
		elseif AwayCoachInfluence == 3 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
			HomeCoachAttribute = math.random()
			if HomeCoachAttribute > 0.9 then
				HomeCoachInfluence = HomeCoachInfluence - 1
			elseif HomeCoachAttribute < 0.1 then
				HomeCoachInfluence = HomeCoachInfluence + 1
			end
		elseif (HomeCoachInfluence == 2 or HomeCoachInfluence == 1) and Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals() then
			HomeCoachAttribute = math.random()
			if HomeCoachAttribute > 0.9 then
				HomeCoachInfluence = HomeCoachInfluence + 1
			end
		end
	end		
-- This resets the shots to possibly miss to start the period if the FirstShotsMissAllGame option is set to Yes
	if FirstShotsMissAllGame == true and Launcher.Game.Period() > 1 then
		FirstShotsMiss = true
		FirstShotsLength = 1200 - (math.random(30, FirstShotsMaxTime))
	end
-- This resets the time for the Additional Penalties pause if the fight occurred within the last 5 minutes of the previous period
	if APPause == true and APTimer < 0 then
		APTimer = 900
	end
-- This resets the Jail Break time to the start of the period for penalty time that was still active at the end of the period
	if Launcher.Game.Period() == 4 and JailBreakGoals == true and (Launcher.GameOption.OTMode() == 3 or Launcher.GameOption.OTMode() == 4) then
		JailBreakGoals = false
		JailBreakActive = 0
	elseif JailBreakActive > 0 then
		JailBreakStopTime = 1200 + JailBreakStopTime
	end
-- This picks a random time remaining in the period for the "snow debris" buildup if that option is active
	if SnowyIce == true then
		SnowyTime = math.random(180, 300)
	end
end
function PlayStoppedCallback(Reason)
-- This handles whether or not "Jail Break" goals are active
	if JailBreakActive < 2 and JailBreakGoals == true then
		PenaltyTime = Launcher.Mem.Byte(0x79b3f7)
		if PenaltyTime == 8 then
			if JailBreakMajors == true then
				JailBreakActive = 1
				JailBreakStopTime = Launcher.Game.Time() - 300
			end
		elseif PenaltyTime == 4 then
			if JailBreakDoubleMinors == true then
				JailBreakActive = 1
				JailBreakStopTime = Launcher.Game.Time() - 240
			end
		elseif PenaltyTime == 2 then
			JailBreakActive = 1
			JailBreakStopTime = Launcher.Game.Time() - 120
		end
	end
-- This resets the enforcement of a missed shot and pauses the WildShot system until the next face-off if that option is set to true
	if WildShot == true then
		ForceMissed = 2
		WildShotPause = true
	end
-- This resets the possibility of a puck being sent out of play for a Delay of Game penalty
	if DelayPenalty == true then
		StopforDelay = 2
	end
-- This resets the bumpy ice option if that is enabled
	if BumpyIce == true then
		BumpyIceActive = 0
	end
-- This sets the parameters to trigger sending the line that iced the puck back onto the ice if the "IcingLineManagement" option is set to true
	if Reason == LauncherPlayStoppedIcing and IcingLineManagement == true and PPT == 0 then
		SetIcingLine = 1
		IcingPlayer = Launcher.Game.PlayerWithPuck()
	end
-- This resets the Goalie Pass flag if it was active when play stopped
	GoaliePass = 0
-- This negates a pending scripted penalty if a goal was scored
	if (Reason == LauncherPlayStoppedGoalAway or Reason == LauncherPlayStoppedGoalHome) and ScriptedPending == 1 then
		ScriptedPending = 0
	end
-- This sets up the major Delay of Game penalties in preparation for the hybrid 3-on-3 OT if that option is active
	if ThreeonThreeOT == true and Launcher.Game.Period() == 3 and Launcher.Game.Time() == 0 and Launcher.Stats.HomeGoals() == Launcher.Stats.AwayGoals() then
		if ThreeonThree == 0 then
			if Launcher.Player.ShotsAgainst(18) > Launcher.Player.ShotsAgainst(19) then
				HomePlayerToSit = 18
			else
				HomePlayerToSit = 19
			end
			Launcher.Mem.WriteByte(0x79b3f4, 0)
			Launcher.Mem.WriteByte(0x79b3f5, HomePlayerToSit)
			Launcher.Game.SetPenaltyPendingID(42)
			Launcher.Game.SetPenaltyPendingTime(8)
			Launcher.Mem.WriteByte(0x79B9BC, 1)
			ThreeonThree = 1
		elseif ThreeonThree == 2 then
			if Launcher.Player.ShotsAgainst(38) > Launcher.Player.ShotsAgainst(39) then
				AwayPlayerToSit = 18
			else
				AwayPlayerToSit = 19
			end
			Launcher.Mem.WriteByte(0x79b3f4, 1)
			Launcher.Mem.WriteByte(0x79b3f5, AwayPlayerToSit)
			Launcher.Game.SetPenaltyPendingID(42)
			Launcher.Game.SetPenaltyPendingTime(8)
			Launcher.Mem.WriteByte(0x79B9BC, 1)
			ThreeonThree = 3
		end
	end
-- This transitions to a shootout after the 3-on-3 OT if that option is enabled
	if ThreeonThreeOT == true and Launcher.GameOption.OTMode() ~= 5 and SOAfterOT == true and Launcher.Game.Period() == 4 and Launcher.Game.Time() == 0.0 and Reason ~= LauncherPlayStoppedIcing and Reason ~= LauncherPlayStoppedOffside and Launcher.Stats.HomeGoals() == Launcher.Stats.AwayGoals() then
		Launcher.Game.SetPeriod(0)
	end
-- These are scripted penalties related to stoppages in play that will randomly come into effect if they are enabled
	if AdditionalPenalties == true then
		CurrentTime = Launcher.Game.Time()
-- This penalizes the player who sent the puck out of play if the "DelayPenalty" option is enabled
		if DelayPenalty == true and OnlinePlay == false and DelayPenaltySet == 1 then
			StopforDelay = 0
			DelayPenaltySet = 0
			ExclPID1Time = ExclPID1Time - CurrentTime
			ExclPID2Time = ExclPID2Time - CurrentTime
			ExclPID3Time = ExclPID3Time - CurrentTime
			ExclPID4Time = ExclPID4Time - CurrentTime
			ExclPID5Time = ExclPID5Time - CurrentTime
			ExclPID6Time = ExclPID6Time - CurrentTime
			if ExclPID1Time > 360 or ExclPID1Time < 0 then
				ExclPID1 = -1
				ExclPID1Time = CurrentTime
			end
			if ExclPID2Time > 360 or ExclPID2Time < 0 then
				ExclPID2 = -1
				ExclPID2Time = CurrentTime
			end
			if ExclPID3Time > 360 or ExclPID3Time < 0 then
				ExclPID3 = -1
				ExclPID3Time = CurrentTime
			end
			if ExclPID4Time > 360 or ExclPID4Time < 0 then
				ExclPID4 = -1
				ExclPID4Time = CurrentTime
			end
			if ExclPID5Time > 360 or ExclPID5Time < 0 then
				ExclPID5 = -1
				ExclPID5Time = CurrentTime
			end
			if ExclPID6Time > 360 or ExclPID6Time < 0 then
				ExclPID6 = -1
				ExclPID6Time = CurrentTime
			end
			if ExclPID1 == -1 then
				ExclPID1 = PlayerPenalty
			elseif ExclPID2 == -1 then
				ExclPID2 = PlayerPenalty
			elseif ExclPID3 == -1 then
				ExclPID3 = PlayerPenalty
			elseif ExclPID4 == -1 then
				ExclPID4 = PlayerPenalty
			elseif ExclPID5 == -1 then
				ExclPID5 = PlayerPenalty
			else
				ExclPID6 = PlayerPenalty
			end
			if PlayerPenalty > 19 then
				PlayerPenalty = PlayerPenalty - 20
			end
			if Launcher.Game.TeamWithPuck() == 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
				Launcher.Game.SetPenaltyPendingID(42)
				if AllMajorPenalties == true then
					Launcher.Game.SetPenaltyPendingTime(8)
					AwayFixPending = 1
					AwayFixGoals = Launcher.Stats.AwayGoals()
				else
					Launcher.Game.SetPenaltyPendingTime(2)
				end
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
				Launcher.Game.SetPenaltyPendingID(42)
				if AllMajorPenalties == true then
					Launcher.Game.SetPenaltyPendingTime(8)
					HomeFixPending = 1
					HomeFixGoals = Launcher.Stats.HomeGoals()
				else
					Launcher.Game.SetPenaltyPendingTime(2)
				end
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
		elseif Reason == LauncherPlayStoppedIcing and IcingPenalty == true then
-- This penalizes a team if they commit five consecutive icings if the "IcingPenalty" option is enabled
			IcingCount = IcingCount + 1
			if LastIcingTeam == Launcher.Game.TeamWithPuck() and IcingCount == 5 then
				IcingCount = 0
				if NoTouchIcing == false then
					PlayerPenalty = 17
					PenaltySet = 0
					repeat
						if PlayerPenalty ~= ExclPID1 and PlayerPenalty ~= ExclPID2 and PlayerPenalty ~= ExclPID3 and PlayerPenalty ~= ExclPID4 and PlayerPenalty ~= ExclPID5 and PlayerPenalty ~= ExclPID6 then 
							PenaltySet = 1
						else
							PlayerPenalty = PlayerPenalty - 1
						end
					until PenaltySet == 1
				else
					PlayerPenalty = Launcher.Game.PlayerWithPuck()
				end
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
				if PlayerPenalty > 19 then
					PlayerPenalty = PlayerPenalty - 20
				end
				if Launcher.Game.TeamWithPuck() == 0 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(42)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(4)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(42)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(4)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
			end
			if LastIcingTeam ~= Launcher.Game.TeamWithPuck() and LastIcingTeam ~= -1 then
				IcingCount = 1
			end
			LastIcingTeam = Launcher.Game.TeamWithPuck()
		elseif Reason == LauncherPlayStoppedOffside and OffsidePenalty == true then
-- This penalizes a team if they commit five consecutive offsides if the "OffsidePenalty" option is enabled
			OffsideCount = OffsideCount + 1
			if LastOffsideTeam == Launcher.Game.TeamWithPuck() and OffsideCount == 5 then
				OffsideCount = 0
				PlayerPenalty = Launcher.Game.PlayerWithPuck()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
				if PlayerPenalty > 19 then
					PlayerPenalty = PlayerPenalty - 20
				end
				if LastOffsideTeam == 0 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(42)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(4)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(42)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(4)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
			end
			if LastOffsideTeam ~= Launcher.Game.TeamWithPuck() then
				OffsideCount = 1
			end
			LastOffsideTeam = Launcher.Game.TeamWithPuck()
		elseif Reason == LauncherPlayStoppedFight and InstigatorPenalty == true and APMaximum > 0 and OnlinePlay == false then
-- This randomly puts one of the two fighters in the box with a Fight Instigator penalty if the "InstigatorPenalty" option is enabled
			RandomPenaltyChance = math.random ()
			if RandomPenaltyChance > 0.67 then
				APMaximum = APMaximum - 1
				RandomPenalty = math.random (0, 39)
				if RandomPenalty < 20 then
					PlayerPenalty = Launcher.Game.HomeFighter()
				else
					PlayerPenalty = Launcher.Game.AwayFighter()
				end
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
				if RandomPenalty < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(39)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					PlayerPenalty = PlayerPenalty - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(39)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
			end
		elseif Reason == LauncherPlayStoppedPeriod and OfficialAbusePenalty == true and APMaximum > 0 and OnlinePlay == false then
-- This will randomly penalize one of the 40 dressed players to simulate them verbally abusing an official at the end of a period if the "OfficialAbusePenalty" option is enabled
			RandomPenaltyChance = math.random ()
			if RandomPenaltyChance > 0.98 then
				APMaximum = APMaximum - 1
				PlayerPenalty = math.random (0, 39)
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 or ExclPID1Time < 0 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 or ExclPID2Time < 0 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 or ExclPID3Time < 0 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 or ExclPID4Time < 0 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 or ExclPID5Time < 0 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 or ExclPID6Time < 0 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if PlayerPenalty < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(40)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						AwayFixPending = 1
						AwayFixGoals = Launcher.Stats.AwayGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					PlayerPenalty = PlayerPenalty - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(40)
					if AllMajorPenalties == true then
						Launcher.Game.SetPenaltyPendingTime(8)
						HomeFixPending = 1
						HomeFixGoals = Launcher.Stats.HomeGoals()
					else
						Launcher.Game.SetPenaltyPendingTime(2)
					end
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
			end
		end
	end
-- This calculates the difference in the score of the game to determine if it will be a dramatic finish or not
	if (Reason == LauncherPlayStoppedGoalAway or Reason == LauncherPlayStoppedGoalHome) then
		AbsoluteScore = math.abs (Launcher.Stats.HomeGoals() - Launcher.Stats.AwayGoals())
	end
end
function ShotAwayCallback()
-- This prepares for a missed shot if the goalie plays the puck directly to an opponent
	if GoofyGoalie > 0 then
		if GoofyGoalie == 1 and GoaliePass == 0 and (Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) then
			GoaliePass = 2
		elseif GoofyGoalie == 2 and GoaliePass == 0 and (Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) and AwayController == 1 then
			GoaliePass = 2
		end
	end
-- This forces the first shots of the period to miss if that option is enabled
	if OnlinePlay == false and WildShot == true and FirstShotsMiss == true then
		x, y, startingz = Launcher.Game.PuckPosition()
		newz = startingz
		RandomPower = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,1,true)
		ForceMissed = 1
		ForceMissedTimer = os.clock()
	end
-- This will occasionally produce a shot attempt by a visiting player that misses wildly if the "WildShot" option is enabled
	MissedHigh = 0
	MissedLeftorRight = math.random ()
	if ForceMissed == 0 and OnlinePlay == false and WildShot == true and WildShotPause == false and MissedPPPause == false and Launcher.Game.PuckZone() ~= 0 then
		RandomWildShot = math.random ()
		if RandomWildShot < (WildShotFrequency / 100) then
			x, y, startingz = Launcher.Game.PuckPosition()
			newz = startingz
			RandomPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,1,true)
			ForceMissed = 1
			ForceMissedTimer = os.clock()
			ForceMissedHigh = math.random ()
			if ForceMissedHigh < (MissedShotsHigh / 100) then
				MissedAmount = math.random (WildShotRange, WildShotRangeHigh) + math.random ()
				MissedHighLeftorRight = math.random (-3, 3) + math.random ()
				if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and startingz < 2500 then
					MissedHigh = 1
				elseif Launcher.Game.Period() == 2 and startingz > -2500 then
					MissedHigh = 1
				end
			end
		end
	end
-- This will force the puck to go over the glass for a "Delay of Game" penalty if the conditions are met
	if StopforDelay == 0 and Launcher.Game.Time() > 60 and OnlinePlay == false and AdditionalPenalties == true and DelayPenalty == true and PPT == 0 and (ClearingDelaysPerGame == 0 or TotalClearings < ClearingDelaysPerGame) and APMaximum > 0 and APPause == false then
		DelayofGameChance = math.random ()
		if DelayofGameChance < (ClearingDelayChance / 100) then
			startingx, y, z = Launcher.Game.PuckPosition()
			newz = z
			if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and z < -1450 then
				APMaximum = APMaximum - 1
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif Launcher.Game.Period() == 2 and z > 1450 then
				APMaximum = APMaximum - 1
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			end
		end
	end
-- This prepares for a missed shot in the event the goalie might pass the puck directly to an opponent
	if GoaliePass == 2 then
		GoaliePass = 1
		ForceMissed = 1
		MissedHigh = 1
		x, y, startingz = Launcher.Game.PuckPosition()
		newz = startingz
		ForceMissedTimer = os.clock()
		if OnlinePlay == false then
			RandomPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,1,true)
			MissedAmount = math.random (WildShotRange, WildShotRangeHigh) + math.random ()
			MissedHighLeftorRight = math.random (-5, 5) + math.random ()
		else
			MissedAmount = 5
			MissedHighLeftorRight = 0
		end
	end
	if ForceMissed == 1 then
		randomx = math.random () * WildShotRange
		randomy = math.random () * WildShotRange
	end
end
function ShotHomeCallback()
-- This prepares for a missed shot if the goalie plays the puck directly to an opponent
	if GoofyGoalie > 0 then
		if GoofyGoalie == 1 and GoaliePass == 0 and (Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19) then
			GoaliePass = 2
		elseif GoofyGoalie == 2 and GoaliePass == 0 and (Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19) and HomeController == 1 then
			GoaliePass = 2
		end
	end
-- This forces the first shots of the period to miss if that option is enabled
	if OnlinePlay == false and WildShot == true and FirstShotsMiss == true then
		x, y, startingz = Launcher.Game.PuckPosition()
		newz = startingz
		RandomPower = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,0,true)
		ForceMissed = 1
		ForceMissedTimer = os.clock()
	end
-- This will occasionally produce a shot attempt by a home team player that misses wildly if the "WildShot" option is enabled
	MissedHigh = 0
	MissedLeftorRight = math.random ()
	if ForceMissed == 0 and OnlinePlay == false and WildShot == true and WildShotPause == false and MissedPPPause == false and Launcher.Game.PuckZone() ~= 0 then
		RandomWildShot = math.random ()
		if RandomWildShot < (WildShotFrequency / 100) then
			x, y, startingz = Launcher.Game.PuckPosition()
			newz = startingz
			RandomPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,0,true)
			ForceMissed = 1
			ForceMissedTimer = os.clock()
			ForceMissedHigh = math.random ()
			if ForceMissedHigh < (MissedShotsHigh / 100) then
				MissedAmount = math.random (WildShotRange, WildShotRangeHigh) + math.random ()
				MissedHighLeftorRight = math.random (-3, 3) + math.random ()
				if Launcher.Game.Period() == 2 and startingz < 2500 then	
					MissedHigh = 1		
				elseif (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and startingz > -2500 then	
					MissedHigh = 1
				end
			end
		end
	end
-- This will force the puck to go over the glass for a "Delay of Game" penalty if the conditions are met
	if StopforDelay == 0 and Launcher.Game.Time() > 60 and OnlinePlay == false and AdditionalPenalties == true and DelayPenalty == true and PPT == 0 and (ClearingDelaysPerGame == 0 or TotalClearings < ClearingDelaysPerGame) and APMaximum > 0 and APPause == false then
		DelayofGameChance = math.random ()
		if DelayofGameChance < (ClearingDelayChance / 100) then
			startingx, y, z = Launcher.Game.PuckPosition()
			newz = z
			if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and z > 1450 then
				APMaximum = APMaximum - 1
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif Launcher.Game.Period() == 2 and z < -1450 then
				APMaximum = APMaximum - 1
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			end
		end
	end
-- This prepares for a missed shot in the event the goalie might pass the puck directly to an opponent
	if GoaliePass == 2 then
		GoaliePass = 1
		ForceMissed = 1
		MissedHigh = 1
		x, y, startingz = Launcher.Game.PuckPosition()
		newz = startingz
		ForceMissedTimer = os.clock()
		if OnlinePlay == false then
			RandomPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,1,true)
			MissedAmount = math.random (WildShotRange, WildShotRangeHigh) + math.random ()
			MissedHighLeftorRight = math.random (-5, 5) + math.random ()
		else
			MissedAmount = 5
			MissedHighLeftorRight = 0
		end
	end
	if ForceMissed == 1 then
		randomx = math.random () * WildShotRange
		randomy = math.random () * WildShotRange
	end
end
function TickCallback()
-- This sets the clock to tick appropriately depending on whether ShotFlow and/or ShotFlowPP are enabled
	PPT = Launcher.Game.PowerplayTime()
	if RealTime == true or (ShotFlow == true and ShotFlowPP == true and PPT > 0) then
		Launcher.Game.SetTimer(28)
		Launcher.Game.SetPenaltyTimer(28)
	elseif ShotFlow == true and ShotFlowPP == false and PPT > 0 then
		Launcher.Game.SetTimer(CurrentTimer)
		Launcher.Game.SetPenaltyTimer(CurrentTimer)
	end
-- This handles the "Jail Break" function of terminating a penalty for a shorthanded goal
	if JailBreakActive == 2 and Launcher.Game.Time() > 0 then
		if Launcher.Game.Time() > JailBreakStopTime then
			Launcher.Game.SetPuckPosition(0,-100,0)
			Launcher.Game.SetTimer(1)
			Launcher.Game.SetPenaltyTimer(1)
		else
			JailBreakActive = 3
			Launcher.Game.StopPlay()
		end
	elseif JailBreakActive == 1 and Launcher.Game.Period() == 3 and Launcher.Game.Time() <= 125 then
		JailBreakActive = 0
		JailBreakGoals = false
	end
-- This stops play if there is a script-initiated penalty pending
	if ScriptedPending == 1 then
		if (Launcher.Game.PenaltyPendingTeam() == 0 and Launcher.Game.TeamWithPuck() == 0) or (Launcher.Game.PenaltyPendingTeam() == 1 and Launcher.Game.TeamWithPuck() == 1) then
			ScriptedPending = 0
			Launcher.Game.StopPlay()
		end
	end
-- This stops play if there is a False Start face-off underway
	if FalseStartDelay == 1 then
		CurrentTime = math.floor(Launcher.Game.Time())
		FalseStartTimeDiff = FalseStartTime - CurrentTime
		if FalseStartTimeDiff > 0 then
			FalseStartDelay = 0
			Launcher.Game.StopPlay()
			CurrentTime = CurrentTime + 1
			Launcher.Game.SetTime(CurrentTime)
		end
	end
-- This prepares for a missed shot if the goalie plays the puck directly to an opponent
	if GoofyGoalie > 0 then
		if GoofyGoalie == 1 and GoaliePass == 0 and (Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19 or Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) then
			GoaliePass = 2
		elseif GoofyGoalie == 2 and GoaliePass == 0 and ((Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19) and HomeController == 1) or ((Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39) and AwayController == 1) then
			GoaliePass = 2
		end
	end
-- This handles whether or not to enforce a missed shot
	x, y, z = Launcher.Game.PuckPosition()
	CurrentOSClock = os.clock()
	ForcedLength = CurrentOSClock - ForceMissedTimer
	if ForceMissed == 1 and ForcedLength >= 2 then
		ForceMissed = 0
 	end
	if ForceMissed == 1 and (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) then
		if (z < -1450 and Launcher.Game.TeamWithPuck() == 1) or (z > newz and Launcher.Game.TeamWithPuck() == 0) then
			ForceMissed = 0
		elseif (z > 1450 and Launcher.Game.TeamWithPuck() == 0) or (z < newz and Launcher.Game.TeamWithPuck() == 1) then
			ForceMissed = 0
		end
	elseif ForceMissed == 1 and Launcher.Game.Period() == 2 then
		if (z < -1450 and Launcher.Game.TeamWithPuck() == 0) or (z > newz and Launcher.Game.TeamWithPuck() == 1) then
			ForceMissed = 0
		elseif (z > 1450 and Launcher.Game.TeamWithPuck() == 1) or (z < newz and Launcher.Game.TeamWithPuck() == 0) then
			ForceMissed = 0
		end
	end
	if ForceMissed == 1 and ((z < 4700 and z > 1450) or (z > -4700 and z < -1450)) then
		if FirstShotsMiss == true or GoaliePass == 1 then
			x = x + (randomx * WildShotRangeHigh)
			y = y + (randomy + WildShotRange)
		elseif MissedHigh == 1 then
			y = y + (MissedAmount * 0.67)
			x = x + MissedHighLeftorRight
		elseif MissedLeftorRight > 0.9 and MissedShotsHigh > 0 then
			x = x + (randomx * WildShotRange)
			y = y + (randomy + WildShotRange)
		elseif MissedLeftorRight < 0.1 and MissedShotsHigh > 0 then
			x = x - (randomx * WildShotRange)
			y = y + (randomy + WildShotRange)
		elseif MissedLeftorRight > 0.9 then
			x = x + (randomx + WildShotRangeHigh)
		elseif MissedLeftorRight < 0.1 then
			x = x - (randomx + WildShotRange)
		elseif MissedLeftorRight < 0.5 then
			x = x - WildShotRangeHigh
		else
			x = x + WildShotRangeHigh
		end
		Launcher.Game.SetPuckPosition(x,y,z)
		newz = z
	else
		ForceMissed = 0
	end
-- This sends the puck out of play simulating the player clearing the puck over the glass if the "DelayPenalty" is set to true
	if StopforDelay == 1 then
		x, y, z = Launcher.Game.PuckPosition()
		ShotPower = 1
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,true)
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,true)
		if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and Launcher.Game.TeamWithPuck() == 1 then
			y = y + 15
			z = z + 10
		elseif Launcher.Game.Period() == 2 and Launcher.Game.TeamWithPuck() == 1 then
			y = y + 15
			z = z - 10
		elseif (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and Launcher.Game.TeamWithPuck() == 0 then
			y = y + 15
			z = z - 10
		elseif Launcher.Game.Period() == 2 and Launcher.Game.TeamWithPuck() == 0 then
			y = y + 15
			z = z + 10
		end
		if startingx <= 0 then
			x = x + 50
		else
			x = x - 50
		end
		Launcher.Game.SetPuckPosition(x,y,z)
		if DelayPenaltySet == 0 then
			DelayPenaltySet = 1
			PlayerPenalty = Launcher.Game.PlayerWithPuck()
		end
	end
-- This bounces the puck slightly upon hitting a rough patch of ice
	if BumpyIce == true and BumpyIceActive == 1 and OnlinePlay == false then
		x, y, z = Launcher.Game.PuckPosition()
		if Launcher.Game.Time() > 900 then
			BumpyHeightCurrentLimit = math.floor (BumpyHeightLimit / 4)
		elseif Launcher.Game.Time() > 600 then
			BumpyHeightCurrentLimit = math.floor (BumpyHeightLimit / 3)
		elseif Launcher.Game.Time() > 300 then
			BumpyHeightCurrentLimit = math.floor (BumpyHeightLimit / 2)
		else
			BumpyHeightCurrentLimit = BumpyHeightLimit
		end
		BumpLocationDifference = math.abs (z + BumpLocation)
		if y < 7 and BumpLocationDifference < 250 then
			BumpFactor = math.random (1, BumpyHeightCurrentLimit)
			y = y + BumpFactor
			Launcher.Game.SetPuckPosition(x,y,z)
			BumpyIceActive = 0
		end
	end
-- This sets the clock to tick in real time if the score is close near the end of regulation time
	if TwoMinuteWarning == true and Launcher.Game.Period() == 3 and Launcher.Game.Time() <= 120 and AbsoluteScore < 3 and JailBreakActive < 2 then
		Launcher.Game.SetTimer(28)
		Launcher.Game.SetPenaltyTimer(28)
		ShotFlow = false
	end
-- This resets the clock to 5 minutes for the OT period if the 10-minute OT option is enabled
	if TenMinuteOT == true and Launcher.Game.Period() == 4 and Launcher.Game.Time() < 2 then
		Launcher.Game.SetTime(300)
		TenMinuteOT = false
	end
-- This stops the clock if the Two-Minute Warning option is active
	if Launcher.Game.PlayStopped() ~= 1 and TwoMinuteWarningClockStop == true and StopClock == 1 and Launcher.Game.Period() == 3 and Launcher.Game.Time() <= 120 and JailBreakActive < 2 then
		Launcher.Game.StopPlay()
		StopClock = 0
	end
-- This disables Additional Penalties late in regulation
	if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 305 then
		AdditionalPenalties = false
	end
-- This enhances the attributes for the Power Play team if that tweak is active and the PP team is in the attack zone
	PPT = Launcher.Game.PowerplayTime()
	if OnlinePlay == false and PowerPlayTweak == true and PPT > 0 then
		if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and Launcher.Game.TeamWithPuck() == 0 and z < 0 then
			Launcher.Player.AllSetAttributeMultiplier(5,1.015,0,true)
			Launcher.Player.AllSetAttributeMultiplier(6,1.015,0,true)
			Launcher.Player.AllSetAttributeMultiplier(7,1.015,0,true)
			Launcher.Player.AllSetAttributeMultiplier(8,1.015,0,true)
		elseif Launcher.Game.Period() == 2 and Launcher.Game.TeamWithPuck() == 0 and z > 0 then
			Launcher.Player.AllSetAttributeMultiplier(5,1.015,0,true)
			Launcher.Player.AllSetAttributeMultiplier(6,1.015,0,true)
			Launcher.Player.AllSetAttributeMultiplier(7,1.015,0,true)
			Launcher.Player.AllSetAttributeMultiplier(8,1.015,0,true)
		elseif (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and Launcher.Game.TeamWithPuck() == 1 and z > 0 then
			Launcher.Player.AllSetAttributeMultiplier(5,1.015,1,true)
			Launcher.Player.AllSetAttributeMultiplier(6,1.015,1,true)
			Launcher.Player.AllSetAttributeMultiplier(7,1.015,1,true)
			Launcher.Player.AllSetAttributeMultiplier(8,1.015,1,true)
		elseif Launcher.Game.Period() == 2 and Launcher.Game.TeamWithPuck() == 1 and z < 0 then
			Launcher.Player.AllSetAttributeMultiplier(5,1.015,1,true)
			Launcher.Player.AllSetAttributeMultiplier(6,1.015,1,true)
			Launcher.Player.AllSetAttributeMultiplier(7,1.015,1,true)
			Launcher.Player.AllSetAttributeMultiplier(8,1.015,1,true)
		end
	end
end
function ZoneChangedCallback()
-- This keeps track of the number of zones crossed since the last time the player's default attributes were reloaded
	ZonesSinceStoppage = ZonesSinceStoppage + 1
-- This resets the enforcement of a missed shot
	ForceMissed = 0
-- This resets the Goalie Pass flag
	GoaliePass = 0
-- This checks the current rate of shots on goal and speeds up the clock if the shot totals are exceeding the ShotsPerMinute rate
	PPT = Launcher.Game.PowerplayTime()
	if ShotFlow == true and PPT == 0 and Launcher.Game.Period() ~= 0 then
		TotalShots = Launcher.Stats.AwayShots() + Launcher.Stats.HomeShots()
		CurrentTime = Launcher.Game.Time()
		if Launcher.Game.Period() == 1 then
			ElapsedTime = 1200 - CurrentTime
		elseif Launcher.Game.Period() == 2 then
			ElapsedTime = 2400 - CurrentTime
		elseif Launcher.Game.Period() == 3 then
			ElapsedTime = 3600 - CurrentTime
		elseif Launcher.Game.Period() == 4 then
			ElapsedTime = 4800 - CurrentTime
		elseif Launcher.Game.Period() == 5 then
			ElapsedTime = 6000 - CurrentTime
		elseif Launcher.Game.Period() == 6 then
			ElapsedTime = 7200 - CurrentTime
		else
			ShotFlow = false
		end
		ShotRate = (TotalShots * 60) / ElapsedTime
		if ShotRate > ShotsPerMinute then
			if RealTime == true then
				WildShotFrequency = WildShotFrequency * (1 + math.random())
			else
				if OnlinePlay == true then
					CurrentTimer = CurrentTimer - 3
				else
					CurrentTimer = CurrentTimer - math.random (2,5)
				end
				if CurrentTimer < 4 then
					CurrentTimer = 4
				end
				Launcher.Game.SetTimer(CurrentTimer)
			end
		else
			if RealTime == true then
				WildShotFrequency = WildShotFrequency * (0 + math.random())
			else
				if OnlinePlay == true then
					CurrentTimer = CurrentTimer + 2
				else
					CurrentTimer = CurrentTimer + math.random (0,3)
				end
				if CurrentTimer > 28 then
					CurrentTimer = 28
				end
				Launcher.Game.SetTimer(CurrentTimer)
			end
		end
	elseif ShotFlow == true and ShotFlowPP == true and PPT > 0 and Launcher.Game.Period() ~= 0 and Launcher.Game.Period() < 4 then
		Launcher.Game.SetTimer(28)
		Launcher.Game.SetPenaltyTimer(28)
	elseif ShotFlow == true and ShotFlowPP == false and PPT > 0 and Launcher.Game.Period() ~= 0 and Launcher.Game.Period() < 4 then
		TotalShots = Launcher.Stats.AwayShots() + Launcher.Stats.HomeShots()
		CurrentTime = Launcher.Game.Time()
		if Launcher.Game.Period() == 1 then
			ElapsedTime = 1200 - CurrentTime
		elseif Launcher.Game.Period() == 2 then
			ElapsedTime = 2400 - CurrentTime
		elseif Launcher.Game.Period() == 3 then
			ElapsedTime = 3600 - CurrentTime
		elseif Launcher.Game.Period() == 4 then
			ElapsedTime = 4800 - CurrentTime
		elseif Launcher.Game.Period() == 5 then
			ElapsedTime = 6000 - CurrentTime
		elseif Launcher.Game.Period() == 6 then
			ElapsedTime = 7200 - CurrentTime
		else
			ShotFlow = false
		end
		ShotRate = (TotalShots * 60) / ElapsedTime
		if ShotRate > ShotsPerMinute then
			if RealTime == true then
				WildShotFrequency = WildShotFrequency * (1 + math.random())
			else
				if OnlinePlay == true then
					CurrentTimer = CurrentTimer - 3
				else
					CurrentTimer = CurrentTimer - math.random (2,5)
				end
				if CurrentTimer < 4 then
					CurrentTimer = 4
				end
				Launcher.Game.SetTimer(CurrentTimer)
			end
		else
			if RealTime == true then
				WildShotFrequency = WildShotFrequency * (0 + math.random())
			else
				if OnlinePlay == true then
					CurrentTimer = CurrentTimer + 2
				else
					CurrentTimer = CurrentTimer + math.random (0,3)
				end
				if CurrentTimer > 28 then
					CurrentTimer = 28
				end
				Launcher.Game.SetTimer(CurrentTimer)
			end
		end
	end
-- This reloads the Visiting team player's default attributes when a new line comes onto the ice
	if FreshAttributes == true and Launcher.Game.Period() > 0 then
		if CurrentAwayLine ~= Launcher.Game.AwayLine() and IcingAwayLine == -1 and SetIcingLine < 2 then
			for loopcount=20, 39 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					if loopcount == 38 or loopcount == 39 then
						if GoalieCount == 0 then
							if attributecount == 4 or attributecount == 5 or attributecount == 7 or attributecount == 9 or attributecount == 16 then
								Value = math.floor(Value * (1 + (GoalieVariation / 100)))
							end
						else
							if attributecount == 4 or attributecount == 5 or attributecount == 7 or attributecount == 9 or attributecount == 16 then
								Value = math.floor(Value * (1 - (GoalieVariation / 100)))
							end
						end
					end
					Launcher.Mem.WriteByte(Pointer, Value)
				end
			end
			CurrentAwayLine = Launcher.Game.AwayLine()
		end
-- This reloads the Home team player's default attributes when a new line comes onto the ice
		if CurrentHomeLine ~= Launcher.Game.HomeLine() and IcingHomeLine == -1 and SetIcingLine < 2 then
			for loopcount=0, 19 do
				for attributecount=0, 16 do
					Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
					Value = players[loopcount] [attributecount]
					if loopcount == 18 or loopcount == 19 then
						if GoalieCount == 0 then
							if attributecount == 4 or attributecount == 5 or attributecount == 7 or attributecount == 9 or attributecount == 16 then
								Value = math.floor(Value * (1 + (GoalieVariation / 100)))
							end
						else
							if attributecount == 4 or attributecount == 5 or attributecount == 7 or attributecount == 9 or attributecount == 16 then
								Value = math.floor(Value * (1 - (GoalieVariation / 100)))
							end
						end
					end
					Launcher.Mem.WriteByte(Pointer, Value)
				end
			end
			CurrentHomeLine = Launcher.Game.HomeLine()
		end
		if GoalieCount == 0 then
			GoalieCount = 1
		else
			GoalieCount = 0
		end
	end
-- This reloads attributes relating to the Power Play tweak if that is enabled and the puck was cleared from the attack zone by the defense during a PP
	if PowerPlayTweak == true and PPT > 0 and Launcher.Game.PuckZone() == 0 and Launcher.Game.Period() > 0 then
		for loopcount=0, 39 do
			for attributecount=5, 8 do
				Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
				Value = players[loopcount] [attributecount]
				if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
					Launcher.Mem.WriteByte(Pointer, Value)
				end
			end
		end
	end
-- If an icing call just occurred, this forces the line that iced the puck back onto the ice if the "IcingLineManagement" option is enabled
	if SetIcingLine == 2 and IcingLineManagement == true and PPT == 0 then
		if IcingAwayLine == -1 then
			CurrentLine = Launcher.Game.HomeLine()
			if CurrentLine == IcingHomeLine then
				IcingHomeLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(0,IcingHomeLine)
				SetIcingLine = 0
			end
		else
			CurrentLine = Launcher.Game.AwayLine()
			if CurrentLine == IcingAwayLine then
				IcingAwayLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(1,IcingAwayLine)
				SetIcingLine = 0
			end
		end
	end
-- This will randomly vary the player's shot power and accuracy prior to each offensive zone entry providing those tweaks are set to true
	if OnlinePlay == false and Launcher.Game.PuckZone() == 0 then
		if PowerTweak ~= 100 then
			UporDown = math.random ()
			RandomVariation = math.random (0,Variation)
			if UporDown < 0.5 then
				ShotPower = 1 - (RandomVariation / 100)
			else
				ShotPower = 1 + (RandomVariation / 100)
			end
			Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,true)
			UporDown = math.random ()
			RandomVariation = math.random (0,Variation)
			if UporDown < 0.5 then
				ShotPower = 1 - (RandomVariation / 100)
			else
				ShotPower = 1 + (RandomVariation / 100)
			end
			Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,true)
		end
		if AccuracyTweak ~= 100 then
			UporDown = math.random ()
			RandomVariation = math.random (0,Variation)
			if UporDown < 0.5 then
				ShotAcc = 1 - (RandomVariation / 100)
			else
				ShotAcc = 1 + (RandomVariation / 100)
			end
			Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,0,true)
			UporDown = math.random ()
			RandomVariation = math.random (0,Variation)
			if UporDown < 0.5 then
				ShotAcc = 1 - (RandomVariation / 100)
			else
				ShotAcc = 1 + (RandomVariation / 100)
			end
			Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,1,true)
		end
	end
-- This checks for pending Major or Misconduct penalties
	if Majors == 1 then
		Majors = 2
	elseif MisconductPenalty == 1 then
		MisconductPenalty = 2
	end
	if Majors == 2 or MisconductPenalty == 2 then
-- This sets up the Game Misconduct penalty connected with the previous Major for Checking from Behind
		if MajorPenalties == true and Misconducts == true and Majors == 2 then
			if MajorHomePlayer >= 0 then
				FixAwayMisconduct = 1
				ExpectedAwayTotalPP = Launcher.Stats.AwayPowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			else
				FixHomeMisconduct = 1
				ExpectedHomeTotalPP = Launcher.Stats.HomePowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			end
			Majors = 3
		end
-- This sets up the Game Misconduct penalty connected with the previous minor for Roughing
		if MajorPenalties == true and Misconducts == true and MisconductPenalty == 2 then
			if MajorHomePlayer >= 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			end
			MisconductPenalty = 3
		end
	end
-- This resets the strange bounce option if active
	if Launcher.Game.PuckZone() == 0 and DeterioratingIce == true then
		Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
	end
-- This tweaks some skater and goalie abilities for each shot taken in a Shootout
	if Launcher.Game.Period() == 0 and OnlinePlay == false and ShootOutTweaks == true then
		Agility = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,0,false)
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,1,false)
		Recovery = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(3,Recovery,0,false)
		Launcher.Player.AllSetAttributeMultiplier(3,Recovery,1,false)
		ShotPower = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,false)
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,false)
		ShotAcc = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,0,false)
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,1,false)
		Deking = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,0,false)
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,1,false)
		Faceoffs = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(9,Faceoffs,0,false)
		Launcher.Player.AllSetAttributeMultiplier(9,Faceoffs,1,false)
		Endurance = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,0,false)
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,1,false)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Acceleration(18,GoalieAttribute)
		Launcher.Player.Acceleration(19,GoalieAttribute)
		Launcher.Player.Acceleration(38,GoalieAttribute)
		Launcher.Player.Acceleration(39,GoalieAttribute)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Aggression(18,GoalieAttribute)
		Launcher.Player.Aggression(19,GoalieAttribute)
		Launcher.Player.Aggression(38,GoalieAttribute)
		Launcher.Player.Aggression(39,GoalieAttribute)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Penalty(18,GoalieAttribute)
		Launcher.Player.Penalty(19,GoalieAttribute)
		Launcher.Player.Penalty(38,GoalieAttribute)
		Launcher.Player.Penalty(39,GoalieAttribute)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Toughness(18,GoalieAttribute)
		Launcher.Player.Toughness(19,GoalieAttribute)
		Launcher.Player.Toughness(38,GoalieAttribute)
		Launcher.Player.Toughness(39,GoalieAttribute)
	end
-- This sets how quickly the goaltender will cover the puck depending on whether or not a Power Play is active
	PPT = Launcher.Game.PowerplayTime()
	if QuickCover ~= 0 and Launcher.Game.Period() > 3 then
		Launcher.Game.SetGoalieCoverTime(100)
	elseif QuickCover == 1 and PPT == 0 then
		Launcher.Game.SetGoalieCoverTime(50)
	elseif QuickCover == 2 and PPT == 0 then
		Launcher.Game.SetGoalieCoverTime(5)
	end
-- This sets how the goalie handles the puck based on a Power Play in progress or a team trailing late in the third period or an excessive amount of faceoffs
	CurrentTime = Launcher.Game.Time()
	if Launcher.Game.Period() == 1 then
		ElapsedTime = 1200 - CurrentTime
	elseif Launcher.Game.Period() == 2 then
		ElapsedTime = 2400 - CurrentTime
	elseif Launcher.Game.Period() == 3 then
		ElapsedTime = 3600 - CurrentTime
	elseif Launcher.Game.Period() == 4 then
		ElapsedTime = 4800 - CurrentTime
	elseif Launcher.Game.Period() == 5 then
		ElapsedTime = 6000 - CurrentTime
	elseif Launcher.Game.Period() == 6 then
		ElapsedTime = 7200 - CurrentTime
	else
		ShotFlow = false
	end
	FaceoffRate = (TotalFaceoffs * 60) / ElapsedTime
	if QuickCover ~= 0 and GameFlow == true and ZonesSinceStoppage >= 12 and PPT == 0 then
		Launcher.Game.SetGoalieCoverTime(5)
		ZonesSinceStoppage = 0
	elseif QuickCover ~= 0 and GameFlow == true and FaceoffRate > FaceoffsPerMinute and Launcher.Game.Period() < 4 then
		Launcher.Game.SetGoalieCoverTime(125)
	elseif QuickCover ~= 0 and PPT > 0 then
		Launcher.Game.SetGoalieCoverTime(125)
		Launcher.Player.Passing(18,99)
		Launcher.Player.Passing(19,99)
		Launcher.Player.Passing(38,99)
		Launcher.Player.Passing(39,99)
	elseif QuickCover ~= 0 and Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
		Launcher.Game.SetGoalieCoverTime(125)
		if Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals() then
			Launcher.Player.Passing(38,99)
			Launcher.Player.Passing(39,99)
			Launcher.Player.Passing(18,0)
			Launcher.Player.Passing(19,0)
		else
			Launcher.Player.Passing(18,99)
			Launcher.Player.Passing(19,99)
			Launcher.Player.Passing(38,0)
			Launcher.Player.Passing(39,0)
		end
	end
-- This halts play if the "RefErrors" option is enabled, simulating the referee blowing the whistle by mistake
	if RefErrors == true and OnlinePlay == false and Launcher.Game.PuckZone() ~= 0 and Launcher.Game.Period() ~= 0 and PPT == 0 then
		RandomError = math.random()
		if RandomError > 0.9975 then
			Launcher.Game.StopPlay()
		end
	end
-- This changes physics related to puck bounce, board friction and pass speed if the "DeterioratingIce" option is enabled
	if Launcher.Game.PuckZone() ~= 0 and DeterioratingIce == true then
		CurrentTime = Launcher.Game.Time()
		if CurrentTime < 1140 then
			PuckBounceFriction = Launcher.Mem.Float(0x79C768)
			RandomBounce = math.random ()
			if RandomBounce > 0.0175 or OnlinePlay == true then
				RandomBounce = 0.0175
			end
			if RealTime == true then
				RandomBounce = 0.005
			end
			PuckBounceFriction = PuckBounceFriction * (1 + RandomBounce)
			if PuckBounceFriction > PuckBounceFrictionMax then
				PuckBounceFriction = PuckBounceFriction * (1 - RandomBounce)
			end
			Launcher.Physics.SetPuckBounceFriction(PuckBounceFriction)
			if RealTime == true or ShotFlow == true then
				Gravity = Launcher.Physics.PuckGravity()
				Gravity = Gravity + 0.0025
			else
				Gravity = Launcher.Physics.PuckGravity()
				Gravity = Gravity + 0.025
			end
			Launcher.Physics.SetPuckGravity(Gravity)
			if OnlinePlay == false then
				EnergyMultiplier = Launcher.Mem.Float(0x709f90)
				RandomEnergy = (math.random (1, 9) / 100000)
				MoreLessEnergy = math.random()
				if MoreLessEnergy < 0.5 then
					EnergyMultiplier = EnergyMultiplier - RandomEnergy
				else
					EnergyMultiplier = EnergyMultiplier + RandomEnergy
				end
				if EnergyMultiplier < StartEnergyMultiplier or EnergyMultiplier > (StartEnergyMultiplier * 1.1) then
					Launcher.Physics.SetPlayerSpeedEnergyMultiplier(StartEnergyMultiplier)
				else
					Launcher.Physics.SetPlayerSpeedEnergyMultiplier(EnergyMultiplier)
				end
			end
			if CurrentTime < 1140 then
				PuckBoardBounceFriction = Launcher.Mem.Float(0x79C76C)		
				RandomBoardBounce =	(math.random (50, 150)) / 100
				if OnlinePlay == false then
					PuckBoardBounceFriction = PuckBoardBounceFriction * RandomBoardBounce
				else
					PuckBoardBounceFriction = PuckBoardBounceFriction * 1.1
				end
				if PuckBoardBounceFriction < 0.05 or PuckBoardBounceFriction > 0.45 then
					Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
				else
					Launcher.Physics.SetPuckBoardBounceFriction(PuckBoardBounceFriction)
				end
				if SnowyIce == true and Launcher.Game.Time() < SnowyTime and OnlinePlay == false and PuckBoardBounceFriction > 0.25 then
					PuckBoardBounceFriction = PuckBoardBounceFriction * 0.5
					Launcher.Physics.SetPuckBoardBounceFriction(PuckBoardBounceFriction)
				end
			end
			if StrangeBounceTweak == true and OnlinePlay == false then
				if CurrentTime > 900 then
					StrangeBounceLimit = 0.85
				elseif CurrentTime > 600 then
					StrangeBounceLimit = 0.8
				elseif CurrentTime > 300 then
					StrangeBounceLimit = 0.75
				else
					StrangeBounceLimit = 0.7
				end
				StrangeBounceChance = math.random ()
				if StrangeBounceChance > StrangeBounceLimit then
					StrangeBounce = math.random ()
					if StrangeBounce > 0.375 then
						if StrangeBounceReduction == 1 then
							StrangeBounce = StrangeBounce - 0.7
						elseif StrangeBounceReduction == 2 then
							StrangeBounce = StrangeBounce - 0.6
						else
							StrangeBounce = StrangeBounce - 0.5
						end
					end
					if StrangeBounce < 0 then
						StrangeBounce = StrangeBounce + 0.33
					end
					Launcher.Physics.SetPuckBoardBounceFriction(StrangeBounce)
				end
			end
			if SlowingPassSpeed == true then
				if RealTime == true or ShotFlow == true or OnlinePlay == true then
					PassSpeed = PassSpeed - 0.1
					Launcher.Physics.SetPassBaseSpeed(PassSpeed)
				else
					RandomPassSpeed = math.random ()
					if RandomPassSpeed > 0.5 then
						RandomPassSpeed = 0.1
					end
					PassSpeed = PassSpeed - RandomPassSpeed
					Launcher.Physics.SetPassBaseSpeed(PassSpeed)
				end
				if RealTime == false and SnowyIce == true and Launcher.Game.Time() < SnowyTime and OnlinePlay == false then
					PassSpeed = PassSpeed - 0.35
					Launcher.Physics.SetPassBaseSpeed(PassSpeed)
					PuckBoardFriction = PuckBoardFriction - SnowyIceFriction
					Launcher.Physics.SetPuckBoardFriction(PuckBoardFriction)
				end
			end
		end
	end
-- This randomizes the saucer pass speed
	if OnlinePlay == false and SlowingPassSpeed == true then
		if Launcher.Game.Time() > 900 then
			SaucerPassSpeed = math.random () + 1
		elseif Launcher.Game.Time() > 600 then
			SaucerPassSpeed = math.random () + 0.75
		elseif Launcher.Game.Time() > 300 then
			SaucerPassSpeed = math.random () + 0.5
		else
			SaucerPassSpeed = math.random () + 0.25
		end
		if SaucerPassSpeed > 1.5 then
			SaucerPassSpeed = SaucerPassSpeed - 1
		end
		Launcher.Physics.SetSaucerPassSpeedMultiplier(SaucerPassSpeed)
	end
-- This stops the initial shots from missing if that option is enabled
	if FirstShotsMiss == true and Launcher.Game.Time() < FirstShotsLength then
		FirstShotsMiss = false
	end
end

-- Callback Registrations
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
Launcher.Callback.Register("CutsceneStopped",CutsceneStoppedCallback)
Launcher.Callback.Register("FaceoffStarted",FaceOffStartedCallback)
Launcher.Callback.Register("Pass",PassCallback)
Launcher.Callback.Register("PenaltyPending",PenaltyPendingCallback)
Launcher.Callback.Register("PeriodStarted",PeriodStartedCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("ShotAway",ShotAwayCallback)
Launcher.Callback.Register("ShotHome",ShotHomeCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("ZoneChanged",ZoneChangedCallback)

-- ========================================================================== END OF SCRIPT CODE SECTION =========================================================================