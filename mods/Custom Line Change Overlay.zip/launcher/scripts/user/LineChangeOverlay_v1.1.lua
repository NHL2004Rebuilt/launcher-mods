-- ============================================================
-- MODDER QUICK START (v1.0)
-- ============================================================
-- This release supports customization of the two existing layouts:
-- Column and Tabs. It does NOT load additional layout Lua files.
--
-- ARTWORK: Replace PNGs in:
--   launcher/media/textures/LineChangeV28/Column/
--   launcher/media/textures/LineChangeV28/Tabs/
-- For the simplest reskin, keep the original PNG filenames, dimensions,
-- and transparency. Different image dimensions may require changes to
-- ChooseProfile() and DrawColumn()/DrawTabs() placement or clipping.
--
-- POSITION / DIMENSIONS: Search for 'local function ChooseProfile()'.
--   'top' and 'marginRight' set the common overlay anchor.
--   'column' and 'tabs' tables hold layout-specific geometry/fonts.
--   Values use the 1920x1080 HUD coordinate space.
--
-- ASSET PATHS: Search for 'local function LoadAssets()'.
--   Both cbase and v2base point to the Column folder; update BOTH if
--   relocating Column artwork. Update tbase for Tabs artwork.
--
-- DRAWING: Search for 'local function DrawColumn(team)' or
--   'local function DrawTabs(team)' to alter placement or composition.
--   Keep the game-state, energy, callbacks, and render-target code intact.
--
-- LAUNCHER: Existing 'linechangeoverlay' setting: 0=off, 1=Column,
--   2=Tabs. Adding a third layout requires code work; it is NOT an
--   automatic folder-discovery or registration API in v1.0.
--
-- CAUTION: Avoid changing memory patches, line-selection behavior,
-- fatigue calculations, callbacks, or render-target handling unless
-- you understand their purpose. Back up the tested Lua before editing.
-- ============================================================

-- ============================================================
-- NHL 2004 Custom Line Change Overlay
--
-- Selectable Column / Tabs renderer for the game's line-change UI.
-- Uses the stock selector/input state, live line energy data, and
-- custom launcher assets.
-- ============================================================
local TEAM_PTR_BASE = 0x0079C254
local PLAYER_PTR_BASE = 0x0079C310

local TEAM_CANDIDATES_OFFSET = 0x28
local TEAM_SELECTED_LINE_OFFSET = 0xD8

local HOME_SELECTOR_ACTIVE = 0x007911A0
local AWAY_SELECTOR_ACTIVE = 0x007911A1
local HOME_MENU_PTR = 0x00791188
local AWAY_MENU_PTR = 0x00791190

local STOCK_SELECTOR_X_IMMEDIATE = 0x004170DE
local AWAY_REPOSITION_CALL = 0x00591492

local POST_CLOSE_FRAMES = 30
-- Preserve overlay visibility across brief gaps in the normal-line selector.
-- The F8 prefix is an internal variable name, not a required key binding.
local F8_CONTINUITY_FRAMES = 8
-- Maximum selector rows moved per render frame; movement can be interrupted.
local F8_SELECTOR_ROWS_PER_FRAME = 0.60
local HERO_REVEAL_FRAMES = 24
local MAX_ENERGY = 4096
local SPECIAL_MODE_RELEASE_FRAMES = 60
local MANUAL_EVENT_GRACE_FRAMES = 10

local STYLE_DISABLED = 0
local STYLE_COLUMN = 1
local STYLE_TABS = 2
local CONFIG_OPTION = "linechangeoverlay"

-- Render the complete overlay on a 1920x1080 HUD surface, then scale that
-- surface to the active game width. This matches the broadcast/scorebug
-- approach and keeps sprites, fonts, bars, and spacing proportional.
local NATIVE_RESOLUTION_X = 1920
local NATIVE_RESOLUTION_Y = 1080
local NATIVE_RESOLUTION_ASPECT = NATIVE_RESOLUTION_Y / NATIVE_RESOLUTION_X

-- Original selector X immediate (ADD ESI, 0x16C).
local STOCK_SELECTOR_X_ORIGINAL = { 0x6C, 0x01, 0x00, 0x00 }
local STOCK_SELECTOR_X_HIDDEN   = { 0x00, 0x10, 0x00, 0x00 }

-- CALL 00416AD0 at 00591492 moves the AWAY selector back onscreen.
local AWAY_REPOSITION_ORIGINAL = { 0xE8, 0x39, 0x56, 0xE8, 0xFF }
local AWAY_REPOSITION_DISABLED = { 0x90, 0x90, 0x90, 0x90, 0x90 }

local Column = {
    V2Base = nil,
    V2Tiles = {},
    PanelHero = nil,
    HeroTile = nil,
    PanelPP = {},
    PanelPK = {},
    BarGreen = nil,
    BarYellow = nil,
    BarRed = nil,
    BarHero = nil,
    TeamFont = nil,
    PercentFont = nil,
}

local Tabs = {
    PanelSel = {},
    PanelSelNoHero = {},
    PanelHero = nil,
    HeroTile = nil,
    PanelPP = {},
    PanelPK = {},
    MiniGreen = nil,
    MiniYellow = nil,
    MiniRed = nil,
    MiniGreenST = nil,
    MiniYellowST = nil,
    MiniRedST = nil,
    BarGreen = nil,
    BarYellow = nil,
    BarRed = nil,
    BarHero = nil,
    TeamFont = nil,
    PercentFont = nil,
    HeroPercentFont = nil,
}

local profile = nil
local assetsLoaded = false
local OverlaySurface = nil
local OverlaySurfaceScale = -1

local state = {
    [0] = {
        selected=0, committed=-1, lastD8=-1, hold=0, wasActive=false, heroReveal=0,
        forceHidden=false,
        manualGrace=0,
        f8Continuity=0,
        animatedRow=0, animatedReady=false,
        lastManualRow=-1,
        manualSession=0,
        heroLockSession=-1,
        heroResetGuard=false,
        specialLatched=false, specialKind=nil, equalFrames=0,
        specialSignature=nil, specialEnergyReady=false
    },
    [1] = {
        selected=0, committed=-1, lastD8=-1, hold=0, wasActive=false, heroReveal=0,
        forceHidden=false,
        manualGrace=0,
        f8Continuity=0,
        animatedRow=0, animatedReady=false,
        lastManualRow=-1,
        manualSession=0,
        heroLockSession=-1,
        heroResetGuard=false,
        specialLatched=false, specialKind=nil, equalFrames=0,
        specialSignature=nil, specialEnergyReady=false
    },
}

local function ResetOverlayState()
    for team = 0, 1 do
        local s = state[team]
        s.selected = 0
        s.committed = -1
        s.lastD8 = -1
        s.hold = 0
        s.wasActive = false
        s.heroReveal = 0
        s.forceHidden = false
        s.manualGrace = 0
        s.f8Continuity = 0
        s.animatedRow = 0
        s.animatedReady = false
        s.lastManualRow = -1
        s.manualSession = 0
        s.heroLockSession = -1
        s.heroResetGuard = false
        s.specialLatched = false
        s.specialKind = nil
        s.equalFrames = 0
        s.specialSignature = nil
        s.specialEnergyReady = false
    end
end


local COLOR_INACTIVE = 0xFFC7CBD0
local COLOR_ACTIVE   = 0xFFFFFFFF
local COLOR_YELLOW   = 0xFFF2C21C

local function S32(v)
    if v >= 0x80000000 then
        return v - 0x100000000
    end
    return v
end

local function OverlayStyle()
    local style = Launcher.Config.Int(CONFIG_OPTION, STYLE_COLUMN)
    if style ~= STYLE_DISABLED and style ~= STYLE_COLUMN and style ~= STYLE_TABS then
        return STYLE_COLUMN
    end
    return style
end

local function BytesMatch(addr, bytes)
    for i = 1, #bytes do
        if (Launcher.Mem.Byte(addr + i - 1) % 256) ~= bytes[i] then
            return false
        end
    end
    return true
end

local function WriteBytes(addr, bytes)
    for i = 1, #bytes do
        Launcher.Mem.WriteByte(addr + i - 1, bytes[i])
    end
end

local function DisableStockLineSelector()
    if not BytesMatch(STOCK_SELECTOR_X_IMMEDIATE, STOCK_SELECTOR_X_HIDDEN) then
        WriteBytes(STOCK_SELECTOR_X_IMMEDIATE, STOCK_SELECTOR_X_HIDDEN)
    end
end

local function DisableAwayReposition()
    -- Only patch the verified original bytes; leave unknown versions untouched.
    if BytesMatch(AWAY_REPOSITION_CALL, AWAY_REPOSITION_DISABLED) then return end
    if not BytesMatch(AWAY_REPOSITION_CALL, AWAY_REPOSITION_ORIGINAL) then return end
    pcall(function()
        Launcher.Mem.WriteASM(AWAY_REPOSITION_CALL, [[
            nop
            nop
            nop
            nop
            nop
        ]])
    end)
end

local function RestoreAwayReposition()
    if BytesMatch(AWAY_REPOSITION_CALL, AWAY_REPOSITION_DISABLED) then
        Launcher.Mem.WriteASM(AWAY_REPOSITION_CALL, [[
            call 0x00416AD0
        ]])
    end
end

local function RestoreStockLineSelector()
    -- Only restore when the bytes are exactly our off-screen patch.
    -- This avoids overwriting an unrelated third-party patch.
    if BytesMatch(STOCK_SELECTOR_X_IMMEDIATE, STOCK_SELECTOR_X_HIDDEN) then
        WriteBytes(STOCK_SELECTOR_X_IMMEDIATE, STOCK_SELECTOR_X_ORIGINAL)
    end
end

local function EnsureStockLineSelectorState()
    if OverlayStyle() == STYLE_DISABLED then
        RestoreStockLineSelector()
        RestoreAwayReposition()
    else
        DisableStockLineSelector()
        DisableAwayReposition()
    end
end

local function TeamPointer(team)
    return Launcher.Mem.Long(TEAM_PTR_BASE + team * 4)
end

local function SelectorActive(team)
    local addr = (team == 0) and HOME_SELECTOR_ACTIVE or AWAY_SELECTOR_ACTIVE
    return Launcher.Mem.Byte(addr) ~= 0
end

local function MenuPointer(team)
    local addr = (team == 0) and HOME_MENU_PTR or AWAY_MENU_PTR
    return Launcher.Mem.Long(addr)
end

local function ReadD8(team)
    local t = TeamPointer(team)
    if t == 0 then return -1 end
    return Launcher.Mem.Byte(t + TEAM_SELECTED_LINE_OFFSET)
end

local function TeamManpower(team)
    local t = TeamPointer(team)
    if t == 0 then return 6 end
    return Launcher.Mem.Byte(t + 0xD6)
end

local function OpponentManpower(team)
    local t = TeamPointer(team)
    if t == 0 then return 6 end

    local opp = Launcher.Mem.Long(t + 0x00)
    if opp == 0 then return 6 end

    return Launcher.Mem.Byte(opp + 0xD6)
end

local function UpdateSpecialMode(team)
    local own = TeamManpower(team)
    local opp = OpponentManpower(team)
    local s = state[team]

    if own ~= opp and own < 6 then
        local kind = (own > opp) and "pp" or "pk"
        local signature = tostring(own) .. ":" .. tostring(opp) .. ":" .. kind

        -- A manpower change changes the meaning of candidate rows 0/1.
        -- Do not trust their energy until the stock selector opens and
        -- 00416F30 has rebuilt the candidate table through 004A6590.
        if s.specialSignature ~= signature then
            s.specialSignature = signature
            s.specialEnergyReady = false
        end

        s.specialLatched = true
        s.specialKind = kind
        s.equalFrames = 0
        return
    end

    if s.specialLatched and own == opp then
        s.equalFrames = s.equalFrames + 1
        if s.equalFrames < SPECIAL_MODE_RELEASE_FRAMES then
            return
        end
    end

    s.specialLatched = false
    s.specialKind = nil
    s.specialSignature = nil
    s.specialEnergyReady = false
    s.equalFrames = 0
end

local function IsSpecialDisplay(team)
    return state[team].specialLatched
end

local function SpecialKind(team)
    return state[team].specialKind
end

local function VisibleNormalLineCount(team)
    if IsSpecialDisplay(team) then
        return 2
    end

    return 4
end

local function ReadMenuInitialRow(team)
    local menu = MenuPointer(team)
    if menu == 0 then return -1 end
    local row = Launcher.Mem.Byte(menu + 0x08)
    if row >= 0 and row <= 3 then return row end
    return -1
end

-- Mirrors the normal 004A5DE0 candidate-line average using live data.
-- Candidate row stride = 7 dwords = 0x1C.
-- Slots 1..5 are the five skaters; slot 0 is goalie-role territory,
-- and slot 6 is the alternate goalie/extra-role entry.
local function LineEnergyRaw(team, line)
    if team < 0 or team > 1 then return 0, 0 end
    if line < 0 or line > 4 then return 0, 0 end

    local t = TeamPointer(team)
    if t == 0 then return 0, 0 end

    local row = t + TEAM_CANDIDATES_OFFSET + line * 0x1C
    local sum = 0
    local count = 0

    for slot = 1, 5 do
        local idx = S32(Launcher.Mem.Long(row + slot * 4))

        if idx >= 0 and idx < 40 then
            local p = Launcher.Mem.Long(PLAYER_PTR_BASE + idx * 4)

            if p ~= 0 then
                local e = Launcher.Mem.Long(p + 0xF4)

                if e < 0 then e = 0 end
                if e > MAX_ENERGY then e = MAX_ENERGY end

                sum = sum + e
                count = count + 1
            end
        end
    end

    if count == 0 then return 0, 0 end
    return math.floor(sum / count), count
end

local function CandidateSignature(team, line)
    local t = TeamPointer(team)
    if t == 0 then return "none" end

    local row = t + TEAM_CANDIDATES_OFFSET + line * 0x1C
    local parts = {}

    for slot = 1, 5 do
        parts[#parts + 1] = tostring(S32(Launcher.Mem.Long(row + slot * 4)))
    end

    return table.concat(parts, ",")
end

-- Regular 5v5 roster slots from FUN_004A6310 / lookup 0x00757408.
-- Read the live roster byte mapping rather than the candidate table, which
-- can retain special-teams selections after PP/PK ends.
local REGULAR_ROSTER_OFFSETS = {
    {0, 1, 2, 12, 13},
    {3, 4, 5, 14, 15},
    {6, 7, 8, 16, 17},
    {9, 10, 11}, -- L4 defensive positions are dynamically selected by the game.
}
local ROSTER_MAPPING_BASE = 0x007A87BC
local ROSTER_MAPPING_TEAM_STRIDE = 0x6A8

local function RegularRosterEnergyRaw(team, line)
    if team < 0 or team > 1 or line < 0 or line > 3 then return nil end
    local slots = REGULAR_ROSTER_OFFSETS[line + 1]
    local base = ROSTER_MAPPING_BASE + team * ROSTER_MAPPING_TEAM_STRIDE
    local seen, sum, count = {}, 0, 0
    for _, offset in ipairs(slots) do
        local rosterIdx = Launcher.Mem.Byte(base + offset)
        if rosterIdx == nil or rosterIdx < 0 or rosterIdx >= 20 then return nil end
        local idx = rosterIdx + team * 20
        if seen[idx] then return nil end
        seen[idx] = true
        local player = Launcher.Mem.Long(PLAYER_PTR_BASE + idx * 4)
        if player == nil or player == 0 then return nil end
        local energy = Launcher.Mem.Long(player + 0xF4)
        if energy == nil then return nil end
        if energy < 0 then energy = 0 end
        if energy > MAX_ENERGY then energy = MAX_ENERGY end
        sum, count = sum + energy, count + 1
    end
    if count ~= #slots then return nil end
    return math.floor(sum / count), count
end

local function LineEnergy01(team, line)
    local raw, count
    if line >= 0 and line <= 3 and not IsSpecialDisplay(team) then
        raw, count = RegularRosterEnergyRaw(team, line)
    end
    if raw == nil then raw, count = LineEnergyRaw(team, line) end
    local v = raw / MAX_ENERGY
    if v < 0 then v = 0 end
    if v > 1 then v = 1 end
    return v, raw, count
end

-- FUN_004A6310 special-teams mapping: the slot lookup is selected by
-- manpower and is independent of the lazily rebuilt candidate rows.
-- These offsets are into 0x007A87BC + team*0x6A8.
local SPECIAL_ROSTER_OFFSETS = {
    pp = {
        [0] = {21, 22, 18, 19, 20}, -- 5 vs 4: selection 4
        [1] = {26, 27, 23, 24, 25}, -- selection 5
    },
    pk = {
        [0] = {40, 41, 38, 39}, -- 4 vs 5: selection 8
        [1] = {44, 45, 42, 43}, -- selection 9
    },
}

local function SpecialRosterEnergyRaw(team, line)
    if team < 0 or team > 1 or line < 0 or line > 1 then return nil end
    local own, opp = TeamManpower(team), OpponentManpower(team)
    local kind, slots
    if own == 5 and opp == 4 then kind = "pp"
    elseif own == 4 and opp == 5 then kind = "pk"
    else return nil end -- Other manpower cases retain the existing fallback.
    slots = SPECIAL_ROSTER_OFFSETS[kind][line]
    local base = ROSTER_MAPPING_BASE + team * ROSTER_MAPPING_TEAM_STRIDE
    local seen, sum, count = {}, 0, 0
    for _, offset in ipairs(slots) do
        local rosterIdx = Launcher.Mem.Byte(base + offset)
        if rosterIdx == nil or rosterIdx < 0 or rosterIdx >= 20 then return nil end
        local idx = rosterIdx + team * 20
        if seen[idx] then return nil end
        seen[idx] = true
        local player = Launcher.Mem.Long(PLAYER_PTR_BASE + idx * 4)
        if player == nil or player == 0 then return nil end
        local energy = Launcher.Mem.Long(player + 0xF4)
        if energy == nil then return nil end
        if energy < 0 then energy = 0 end
        if energy > MAX_ENERGY then energy = MAX_ENERGY end
        sum, count = sum + energy, count + 1
    end
    if count ~= #slots then return nil end
    return math.floor(sum / count), count
end

local function DisplayEnergy01(team, line)
    if not IsSpecialDisplay(team) then return LineEnergy01(team, line) end
    -- Use stable source roster assignments even before the candidate builder
    -- has run. Avoid transient orange->green jumps on selector input.
    local raw, count = SpecialRosterEnergyRaw(team, line)
    if raw ~= nil then return raw / MAX_ENERGY, raw, count end
    -- For unsupported manpower or invalid roster data, fall back to
    -- candidate-line energy only after the selector has refreshed it.
    if not state[team].specialEnergyReady then return 0, 0, 0 end
    return LineEnergy01(team, line)
end


local function UpdateOverlaySurfaceScale()
    if OverlaySurface == nil then return end

    local scale = Launcher.Screen.Width() / NATIVE_RESOLUTION_X
    if scale <= 0 then return end

    if math.abs(scale - OverlaySurfaceScale) > 0.0001 then
        Launcher.Sprite.Scale(OverlaySurface, scale, scale)
        OverlaySurfaceScale = scale
    end
end

local function CreateOverlaySurface()
    if OverlaySurface ~= nil then
        UpdateOverlaySurfaceScale()
        return
    end

    OverlaySurface = Launcher.Sprite.Create(NATIVE_RESOLUTION_X, NATIVE_RESOLUTION_Y, 1)
    OverlaySurfaceScale = -1
    UpdateOverlaySurfaceScale()
end

-- ============================================================
-- VISUAL CUSTOMIZATION: LAYOUT GEOMETRY / TYPOGRAPHY
-- All coordinates/sizes here are in the fixed 1920x1080 HUD space.
-- 'top' / 'marginRight' are shared anchors; 'column' / 'tabs' control
-- their respective layout. Keep the existing keys when editing.
-- ============================================================
local function ChooseProfile()
    return {
        marginRight = 0,
        top = 86,

        column = {
            panelW = 196,
            panelH = 418,
            specialH = 202,
            firstY = 52,
            tileH = 72,
            percentRightX = 174,
            percentY = 28,
            barX = 22,
            barY = 48,
            barW = 152,
            teamCenterX = 40,
            teamY = 4,
            teamFont = 30,
            percentFont = 22,
        },

        tabs = {
            panelW = 524,
            panelH = 254,
            specialH = 194,
            teamCenterX = 44,
            teamY = 4,
            teamFont = 28,

            miniY = 104,
            miniW = 100,
            miniX0 = 20,
            miniStep = 128,

            specialMiniW = 228,
            specialMiniX0 = 20,
            specialMiniStep = 256,

            selectedBarX = 166,
            selectedBarY = 140,
            selectedBarW = 248,

            selectedPercentRightX = 498,
            selectedPercentCenterY = 154,
            percentFont = 28,

            heroBarX = 242,
            heroBarY = 206,
            heroBarW = 172,
            heroPercentRightX = 498,
            heroPercentCenterY = 218,
            heroPercentFont = 26,
        },
    }
end

-- ============================================================
-- VISUAL CUSTOMIZATION: TEXTURE FILES AND FONT LOADING
-- To reskin, replace the existing PNGs with matching filenames.
-- For a different folder, update BOTH cbase and v2base (Column),
-- or tbase (Tabs) below. Do not delete a texture load unless its draw use
-- has also been removed.
-- ============================================================
local function LoadAssets()
    if assetsLoaded then return end
    ResetOverlayState()
    profile = ChooseProfile()
    CreateOverlaySurface()
    EnsureStockLineSelectorState()

    local cbase = "launcher/media/textures/LineChangeV28/Column/"
    local v2base = "launcher/media/textures/LineChangeV28/Column/"
    Column.V2Base = Launcher.Sprite.Load(v2base .. "background.png")
    for i = 0, 3 do
        Column.V2Tiles[i] = Launcher.Sprite.Load(v2base .. "selector_row" .. tostring(i + 1) .. ".png")
    end
    Column.PanelHero = Launcher.Sprite.Load(cbase .. "panel_bg_hero.png")
    Column.HeroTile = Launcher.Sprite.Load(cbase .. "panel_hero_tile.png")
    Column.PanelPP[0] = Launcher.Sprite.Load(cbase .. "panel_bg_pp_sel1.png")
    Column.PanelPP[1] = Launcher.Sprite.Load(cbase .. "panel_bg_pp_sel2.png")
    Column.PanelPK[0] = Launcher.Sprite.Load(cbase .. "panel_bg_pk_sel1.png")
    Column.PanelPK[1] = Launcher.Sprite.Load(cbase .. "panel_bg_pk_sel2.png")
    Column.BarGreen = Launcher.Sprite.Load(cbase .. "bar_fill_green.png")
    Column.BarNeutral = Launcher.Sprite.Load(cbase .. "bar_fill_neutral.png")
    Column.BarYellow = Launcher.Sprite.Load(cbase .. "bar_fill_yellow.png")
    Column.BarRed = Launcher.Sprite.Load(cbase .. "bar_fill_red.png")
    Column.BarHero = Launcher.Sprite.Load(cbase .. "bar_fill_hero.png")
    Column.TeamFont = Launcher.Font.Load("Trebuchet MS", profile.column.teamFont, 800)
    Column.PercentFont = Launcher.Font.Load("Trebuchet MS", profile.column.percentFont, 800)

    local tbase = "launcher/media/textures/LineChangeV28/Tabs/"
    Tabs.PanelSel[0] = Launcher.Sprite.Load(tbase .. "panel_bg_sel1.png")
    Tabs.PanelSel[1] = Launcher.Sprite.Load(tbase .. "panel_bg_sel2.png")
    Tabs.PanelSel[2] = Launcher.Sprite.Load(tbase .. "panel_bg_sel3.png")
    Tabs.PanelSel[3] = Launcher.Sprite.Load(tbase .. "panel_bg_sel4.png")
    Tabs.PanelSelNoHero[0] = Launcher.Sprite.Load(tbase .. "panel_bg_sel1_nohero.png")
    Tabs.PanelSelNoHero[1] = Launcher.Sprite.Load(tbase .. "panel_bg_sel2_nohero.png")
    Tabs.PanelSelNoHero[2] = Launcher.Sprite.Load(tbase .. "panel_bg_sel3_nohero.png")
    Tabs.PanelSelNoHero[3] = Launcher.Sprite.Load(tbase .. "panel_bg_sel4_nohero.png")
    Tabs.PanelHero = Launcher.Sprite.Load(tbase .. "panel_bg_hero.png")
    Tabs.HeroTile = Launcher.Sprite.Load(tbase .. "panel_hero_tile.png")
    Tabs.PanelPP[0] = Launcher.Sprite.Load(tbase .. "panel_bg_pp_sel1.png")
    Tabs.PanelPP[1] = Launcher.Sprite.Load(tbase .. "panel_bg_pp_sel2.png")
    Tabs.PanelPK[0] = Launcher.Sprite.Load(tbase .. "panel_bg_pk_sel1.png")
    Tabs.PanelPK[1] = Launcher.Sprite.Load(tbase .. "panel_bg_pk_sel2.png")

    Tabs.MiniNeutral = Launcher.Sprite.Load(tbase .. "minibar_fill_neutral.png")
    Tabs.MiniNeutralST = Launcher.Sprite.Load(tbase .. "minibar_fill_neutral_st.png")
    Tabs.BarNeutral = Launcher.Sprite.Load(tbase .. "bar_fill_neutral.png")
    Tabs.MiniGreen = Launcher.Sprite.Load(tbase .. "minibar_fill_green.png")
    Tabs.MiniYellow = Launcher.Sprite.Load(tbase .. "minibar_fill_yellow.png")
    Tabs.MiniRed = Launcher.Sprite.Load(tbase .. "minibar_fill_red.png")
    Tabs.MiniGreenST = Launcher.Sprite.Load(tbase .. "minibar_fill_green_st.png")
    Tabs.MiniYellowST = Launcher.Sprite.Load(tbase .. "minibar_fill_yellow_st.png")
    Tabs.MiniRedST = Launcher.Sprite.Load(tbase .. "minibar_fill_red_st.png")

    Tabs.BarGreen = Launcher.Sprite.Load(tbase .. "bar_fill_green.png")
    Tabs.BarYellow = Launcher.Sprite.Load(tbase .. "bar_fill_yellow.png")
    Tabs.BarRed = Launcher.Sprite.Load(tbase .. "bar_fill_red.png")
    Tabs.BarHero = Launcher.Sprite.Load(tbase .. "bar_fill_hero.png")

    Tabs.TeamFont = Launcher.Font.Load("Trebuchet MS", profile.tabs.teamFont, 800)
    Tabs.PercentFont = Launcher.Font.Load("Trebuchet MS", profile.tabs.percentFont, 800)
    Tabs.HeroPercentFont = Launcher.Font.Load("Trebuchet MS", profile.tabs.heroPercentFont, 800)
    assetsLoaded = true
end

local function ShouldHide()
    if Launcher.Game.InReplay() then return true end
    if Launcher.Game.IsShootout() then return true end
    return false
end

local function LineChangedCallback(team, line)
    if team < 0 or team > 1 then return end
    if line < 0 or line > 4 then return end

    local s = state[team]
    local activeNow = SelectorActive(team)
    local manualEvent = activeNow or s.manualGrace > 0


    -- CPU/background/intro line applications are never presentation authority.
    if not manualEvent then
        s.hold = 0
        return
    end

    -- Genuine HERO commit.
    if line == 4 then
        local alreadyHero = (s.committed == 4)
        s.committed = 4
        s.selected = 4
        if alreadyHero then
            s.heroReveal = HERO_REVEAL_FRAMES
        else
            s.heroReveal = 1
        end
        s.heroLockSession = s.manualSession

        -- After HERO is committed, the game may briefly report line 0
        -- while its committed line (D8) is still HERO. Guard against one
        -- such reset callback; this does not prevent every HERO quirk.
        s.heroResetGuard = true

        s.manualGrace = 0
        s.forceHidden = false
        s.hold = POST_CLOSE_FRAMES
        return
    end

    -- Ignore one spurious line-0 callback while HERO remains committed.
    -- Consume the guard so a later intentional Line 1 change can work.
    if s.heroResetGuard and s.committed == 4 and line == 0 and ReadD8(team) == 4 then
        s.heroResetGuard = false
        s.selected = 4
        s.committed = 4
        s.heroReveal = HERO_REVEAL_FRAMES
        s.manualGrace = 0
        s.forceHidden = false
        s.hold = POST_CLOSE_FRAMES
        return
    end

    -- Any accepted normal-line choice consumes HERO reset protection.
    s.heroResetGuard = false
    s.heroLockSession = -1
    s.manualGrace = 0

    local previousCommitted = s.committed
    local sameCommitted = (previousCommitted == line)

    s.committed = line
    s.selected = line
    s.heroReveal = 0

    if sameCommitted then
        s.hold = 0
        s.forceHidden = true
        return
    end

    s.forceHidden = false
    s.hold = POST_CLOSE_FRAMES
end

-- Poll Team+D8 only as a state-synchronization source. Background/CPU D8
-- changes must never make the overlay visible; presentation authority stays
-- with an actual selector lifecycle / LineChanged event.
local function PollCommittedLine(team)
    local s = state[team]
    local d8 = ReadD8(team)

    if d8 < 0 or d8 > 4 then
        return
    end

    if s.lastD8 == -1 then
        s.lastD8 = d8
        if s.committed == -1 then
            s.committed = d8
            s.selected = d8
        end
        return
    end

    if d8 ~= s.lastD8 then
        s.lastD8 = d8
        s.committed = d8

        -- Keep the internal cursor synchronized only while a genuine manual
        -- selector session is active (or inside its short callback grace).
        -- Do not arm hold or clear forceHidden here.
        if SelectorActive(team) then
            -- The stock controller cycles the live four-row menu. Prefer its cursor over the
            -- committed D8 line so a late commit cannot rewind the asset.
            -- HERO remains governed by the existing HERO session logic.
            local row = ReadMenuInitialRow(team)
            if s.committed ~= 4 and row >= 0 and row <= 3 then
                s.selected = row
            elseif row < 0 then
                s.selected = d8
            end
        elseif s.manualGrace > 0 then
            s.selected = d8
        end

        if d8 == 4 then
            s.heroResetGuard = true
        else
            s.heroResetGuard = false
            s.heroLockSession = -1
        end
    end
end

local function UpdateState(team)
    local s = state[team]
    local active = SelectorActive(team)

    -- Presentation-only continuity for the four normal F8 rows. A short
    -- selector-active gap must not clear the surface or restart its hold.
    -- HERO and special-team presentation retain their existing behavior.
    if active then
        s.f8Continuity = 0
    elseif s.f8Continuity > 0 then
        s.f8Continuity = s.f8Continuity - 1
    end

    -- Keep a tiny grace window after close because LineChanged is commonly
    -- delivered 1-2 frames after the active byte falls.
    if active then
        local mr = ReadMenuInitialRow(team)
        if mr >= 0 and mr <= 3 then
            s.lastManualRow = mr

            -- Keep the custom cursor synced while the stock selector is open.
            -- The four-row menu is independent of the committed HERO line.
            -- Opening it after key 5 must show its actual native row.
            s.selected = mr
        end

        -- Rising edge = a new selector lifecycle.
        if not s.wasActive then
            s.manualSession = s.manualSession + 1

            -- 00416F30 rebuilds the candidate table before the selector is
            -- presented. At this rising edge, PP/PK rows 0/1 are therefore
            -- authoritative for the current manpower state.
            if IsSpecialDisplay(team) then
                s.specialEnergyReady = true
            end

        end

        s.manualGrace = MANUAL_EVENT_GRACE_FRAMES
    elseif s.manualGrace > 0 then
        s.manualGrace = s.manualGrace - 1
    end

    -- Falling edge: stock selector just closed.
    -- Hide immediately. If a different LineChanged callback is delivered,
    -- that callback will deliberately re-arm the short post-selection hold.
    -- If no callback comes (the common same-line toggle-close case), it
    -- stays gone just like the stock overlay.
    if s.wasActive and not active then
        if s.selected >= 0 and s.selected <= 3 and
           (not IsSpecialDisplay(team) or s.specialEnergyReady) then
            -- Retain visibility through the short selector teardown/rebuild,
            -- including PP/PK. Never bypass specialEnergyReady validation.
            s.f8Continuity = F8_CONTINUITY_FRAMES
            s.hold = math.max(s.hold, F8_CONTINUITY_FRAMES)
            s.forceHidden = false
        else
            s.hold = 0
            s.forceHidden = true
        end
    end

    if s.forceHidden then
        s.hold = 0

        -- Do not clear the latch merely because active became false.
        -- A later authoritative LineChanged for a DIFFERENT line clears it.
        -- Opening the selector again also clears it below.
        if active and not s.wasActive then
            s.forceHidden = false
        else
            s.wasActive = active
            return
        end
    end

    if active and not s.wasActive then
        -- Once we have an authoritative committed line, trust it over
        -- transient menu/D8 setup values. This is especially important for
        -- HERO, where the stock four-row menu can initialize at row 0.
        local d8 = ReadD8(team)
        local row = ReadMenuInitialRow(team)
        if row >= 0 and row <= 3 then
            s.selected = row
            s.heroReveal = 0
        elseif d8 >= 0 and d8 <= 4 then
            s.selected = d8
            s.heroReveal = (d8 == 4) and HERO_REVEAL_FRAMES or 0
        end
    end

    if active then
        s.hold = POST_CLOSE_FRAMES
    elseif s.f8Continuity > 0 then
        s.hold = math.max(s.hold, s.f8Continuity)
    elseif s.hold > 0 then
        s.hold = s.hold - 1
    end

    if s.selected == 4 and s.heroReveal > 0 and s.heroReveal < HERO_REVEAL_FRAMES then
        s.heroReveal = s.heroReveal + 1
    end

    s.wasActive = active
end

local function TeamAbbreviation(team)
    if team == 0 then
        return Launcher.Game.HomeNameAbbreviation()
    end
    return Launcher.Game.AwayNameAbbreviation()
end



local function EnergyPercent(team, line)
    local v = DisplayEnergy01(team, line)
    local pct = math.floor(v * 100 + 0.5)
    if pct < 0 then pct = 0 end
    if pct > 100 then pct = 100 end
    return v, pct
end

local function NormalBar(fillGreen, fillYellow, fillRed, value01)
    if value01 > 0.60 then return fillGreen end
    if value01 > 0.30 then return fillYellow end
    return fillRed
end

-- Six-stop energy palette, interpolated continuously. ARGB blend color.
local ENERGY_STOPS = {
    {0,   237,   0,   0},
    {30,  243, 152,   0},
    {45,  255, 240,   0},
    {65,  182, 212, 117},
    {80,   43, 183,  72},
    {100,  43, 183,  72},
}
local function EnergyTint(value01)
    local pct = math.max(0, math.min(100, value01 * 100))
    for i = 1, #ENERGY_STOPS - 1 do
        local a, b = ENERGY_STOPS[i], ENERGY_STOPS[i + 1]
        if pct <= b[1] then
            local t = (pct - a[1]) / (b[1] - a[1])
            local r = math.floor(a[2] + (b[2] - a[2]) * t + 0.5)
            local g = math.floor(a[3] + (b[3] - a[3]) * t + 0.5)
            local blue = math.floor(a[4] + (b[4] - a[4]) * t + 0.5)
            return 0xFF000000 + r * 65536 + g * 256 + blue
        end
    end
    return 0xFF2BB748
end

-- Presentation-only smoothing. Never modifies the actual energy/percentage.
local energyColorDisplay = {[0] = {}, [1] = {}}
local ENERGY_COLOR_EASE = 0.16
local function SmoothedEnergyColor(team, line, actualValue)
    local target = math.max(0, math.min(1, actualValue))
    local previous = energyColorDisplay[team][line]
    if previous == nil then
        previous = target
    else
        previous = previous + (target - previous) * ENERGY_COLOR_EASE
        if math.abs(previous - target) < 0.002 then previous = target end
    end
    energyColorDisplay[team][line] = previous
    return previous
end

local function DrawTintedEnergy(fill, x, y, maxW, value01, colorValue01)
    if fill == nil then return end
    local fillW = math.floor(maxW * value01 + 0.5)
    if fillW <= 0 then return end
    Launcher.Sprite.Clip(fill, 0, 0, fillW, 1000)
    Launcher.Sprite.Draw(fill, x, y, 0, EnergyTint(colorValue01 or value01))
end

local function ApproxTextWidth(text, fontPx)
    return #text * fontPx * 0.56
end

local function DrawClippedFill(fill, x, y, maxW, value01)
    if fill == nil then return end
    local fillW = math.floor(maxW * value01 + 0.5)
    if fillW <= 0 then return end
    Launcher.Sprite.Clip(fill, 0, 0, fillW, 1000)
    Launcher.Sprite.Draw(fill, x, y)
end

local function DrawTeamChip(font, fontPx, team, x, y, centerX, textY)
    local text = TeamAbbreviation(team)
    local w = ApproxTextWidth(text, fontPx)
    Launcher.Font.DrawText(
        font,
        text,
        x + centerX - math.floor(w * 0.5),
        y + textY,
        0xFFFFFFFF
    )
end

local function HeroReveal01(team)
    local frames = state[team].heroReveal
    if frames <= 0 then return 0 end
    local t = frames / HERO_REVEAL_FRAMES
    if t < 0 then return 0 end
    if t > 1 then return 1 end
    return t
end

local function DrawHeroTileReveal(sprite, x, y, fullHeight, reveal01)
    if sprite == nil or reveal01 <= 0 then return end

    local h = math.floor(fullHeight * reveal01 + 0.5)
    if h <= 0 then return end

    Launcher.Sprite.Clip(sprite, 0, 0, 10000, h)
    Launcher.Sprite.Draw(sprite, x, y)
end

-- ============================================================
-- VISUAL CUSTOMIZATION: COLUMN RENDERER
-- Edit artwork composition here after adjusting profile.column.
-- This is drawing code, not line-selection/energy game logic.
-- ============================================================
local function DrawColumn(team)
    local s = state[team]
    local p = profile.column
    local special = IsSpecialDisplay(team)
    local kind = SpecialKind(team)
    local visualSelected = s.selected

    if special then
        if visualSelected < 0 then visualSelected = 0 end
        if visualSelected > 1 then visualSelected = 1 end
    end

    local sw = NATIVE_RESOLUTION_X
    local x = sw - profile.marginRight - p.panelW
    local y = profile.top

    if special then
        s.animatedReady = false
        local panel
        if kind == "pk" then
            panel = Column.PanelPK[visualSelected]
        else
            panel = Column.PanelPP[visualSelected]
        end

        if panel ~= nil then
            Launcher.Sprite.Draw(panel, x, y)
        end
    elseif s.selected == 4 then
        s.animatedReady = false
        -- Draw the neutral normal-line portion first, then reveal HERO below it.
        if Column.PanelHero ~= nil then
            Launcher.Sprite.Clip(Column.PanelHero, 0, 0, 10000, 344)
            Launcher.Sprite.Draw(Column.PanelHero, x, y)
        end

        DrawHeroTileReveal(
            Column.HeroTile,
            x,
            y + 344,
            74,
            HeroReveal01(team)
        )
    else
        -- Column normal-line layout: keep the background fixed and move
        -- the selected-row artwork toward the current menu row.
        local target = math.max(0, math.min(3, s.selected))
        if Column.V2Base ~= nil and Column.V2Tiles[target] ~= nil then
            if not s.animatedReady then
                s.animatedRow = target
                s.animatedReady = true
            else
                local delta = target - s.animatedRow
                -- Constant-speed motion starts on the very first frame the
                -- menu target changes. A new target can interrupt mid-flight.
                -- Unlike exponential easing, this has no slow tail/pause.
                local step = math.min(math.abs(delta), F8_SELECTOR_ROWS_PER_FRAME)
                if delta > 0 then
                    s.animatedRow = s.animatedRow + step
                elseif delta < 0 then
                    s.animatedRow = s.animatedRow - step
                end
            end
            Launcher.Sprite.Draw(Column.V2Base, x, y)
            Launcher.Sprite.Draw(Column.V2Tiles[target], x,
                y + p.firstY + math.floor(s.animatedRow * p.tileH + 0.5))
        end
    end

    DrawTeamChip(Column.TeamFont, p.teamFont, team, x, y, p.teamCenterX, p.teamY)

    local count = special and 2 or 4
    for line = 0, count - 1 do
        local value01, pct = EnergyPercent(team, line)
        local tileY = y + p.firstY + line * p.tileH

        -- Tint the neutral bar; use the colored fill textures as a fallback.
        if Column.BarNeutral ~= nil then
            DrawTintedEnergy(Column.BarNeutral, x + p.barX, tileY + p.barY, p.barW, value01, SmoothedEnergyColor(team, line, value01))
        else
            local fill = NormalBar(Column.BarGreen, Column.BarYellow, Column.BarRed, value01)
            DrawClippedFill(fill, x + p.barX, tileY + p.barY, p.barW, value01)
        end

        local text = tostring(pct)
        local textW = ApproxTextWidth(text, p.percentFont)
        local selected = (visualSelected == line)

        Launcher.Font.DrawText(
            Column.PercentFont,
            text,
            x + p.percentRightX - math.floor(textW),
            tileY + p.percentY - math.floor(p.percentFont * 0.50),
            selected and 0xFFFBF9FB or 0xFF1E2024
        )
    end

    -- HERO values appear only with the HERO reveal.
    if not special and s.selected == 4 then
        local reveal = HeroReveal01(team)
        if reveal >= 0.55 then
            local value01, pct = EnergyPercent(team, 4)
            local tileY = y + p.firstY + 4 * p.tileH

            DrawClippedFill(
                Column.BarHero,
                x + p.barX,
                tileY + p.barY,
                p.barW,
                value01
            )

            if reveal >= 0.75 then
                local text = tostring(pct)
                local textW = ApproxTextWidth(text, p.percentFont)
                Launcher.Font.DrawText(
                    Column.PercentFont,
                    text,
                    x + p.percentRightX - math.floor(textW),
                    tileY + p.percentY - math.floor(p.percentFont * 0.50),
                    0xFF281E06
                )
            end
        end
    end


end

-- ============================================================
-- VISUAL CUSTOMIZATION: TABS RENDERER
-- Edit artwork composition here after adjusting profile.tabs.
-- This is drawing code, not line-selection/energy game logic.
-- ============================================================
local function DrawTabs(team)
    local s = state[team]
    local p = profile.tabs
    local special = IsSpecialDisplay(team)
    local kind = SpecialKind(team)
    local visualSelected = s.selected

    if special then
        if visualSelected < 0 then visualSelected = 0 end
        if visualSelected > 1 then visualSelected = 1 end
    end

    local sw = NATIVE_RESOLUTION_X
    local x = sw - profile.marginRight - p.panelW
    local y = profile.top

    if special then
        local panel
        if kind == "pk" then
            panel = Tabs.PanelPK[visualSelected]
        else
            panel = Tabs.PanelPP[visualSelected]
        end

        if panel ~= nil then
            Launcher.Sprite.Draw(panel, x, y)
        end
    elseif s.selected == 4 then
        -- HERO uses the neutral top section plus an animated HERO row.
        if Tabs.PanelHero ~= nil then
            Launcher.Sprite.Clip(Tabs.PanelHero, 0, 0, 10000, 194)
            Launcher.Sprite.Draw(Tabs.PanelHero, x, y)
        end

        DrawHeroTileReveal(
            Tabs.HeroTile,
            x,
            y + 194,
            60,
            HeroReveal01(team)
        )
    else
        local panel = Tabs.PanelSelNoHero[s.selected]
        if panel ~= nil then
            Launcher.Sprite.Draw(panel, x, y)
        end
    end

    DrawTeamChip(Tabs.TeamFont, p.teamFont, team, x, y, p.teamCenterX, p.teamY)

    local miniCount = special and 2 or 4
    for line = 0, miniCount - 1 do
        local value01 = EnergyPercent(team, line)
        local fill
        local miniX
        local miniW

        if special then
            fill = NormalBar(Tabs.MiniGreenST, Tabs.MiniYellowST, Tabs.MiniRedST, value01)
            miniX = x + p.specialMiniX0 + line * p.specialMiniStep
            miniW = p.specialMiniW
        else
            fill = NormalBar(Tabs.MiniGreen, Tabs.MiniYellow, Tabs.MiniRed, value01)
            miniX = x + p.miniX0 + line * p.miniStep
            miniW = p.miniW
        end

        local neutral = special and Tabs.MiniNeutralST or Tabs.MiniNeutral
        if neutral ~= nil then
            DrawTintedEnergy(neutral, miniX, y + p.miniY, miniW, value01, SmoothedEnergyColor(team, line, value01))
        else
            DrawClippedFill(fill, miniX, y + p.miniY, miniW, value01)
        end
    end

    -- Main detail remains tied to the selected normal line / ST unit.
    local mainLine = visualSelected
    if mainLine == 4 then
        mainLine = 0
    end

    local mainValue, mainPct = EnergyPercent(team, mainLine)
    local mainFill = NormalBar(Tabs.BarGreen, Tabs.BarYellow, Tabs.BarRed, mainValue)
    if Tabs.BarNeutral ~= nil then
        DrawTintedEnergy(Tabs.BarNeutral, x + p.selectedBarX, y + p.selectedBarY, p.selectedBarW, mainValue, energyColorDisplay[team][mainLine] or mainValue)
    else
        DrawClippedFill(mainFill, x + p.selectedBarX, y + p.selectedBarY, p.selectedBarW, mainValue)
    end

    local mainText = tostring(mainPct)
    local mainTextW = ApproxTextWidth(mainText, p.percentFont)
    Launcher.Font.DrawText(
        Tabs.PercentFont,
        mainText,
        x + p.selectedPercentRightX - math.floor(mainTextW),
        y + p.selectedPercentCenterY - math.floor(p.percentFont * 0.50),
        0xFF1E2024
    )

    if not special and s.selected == 4 then
        local reveal = HeroReveal01(team)
        if reveal >= 0.55 then
            local heroValue, heroPct = EnergyPercent(team, 4)
            DrawClippedFill(Tabs.BarHero, x + p.heroBarX, y + p.heroBarY, p.heroBarW, heroValue)

            if reveal >= 0.75 then
                local heroText = tostring(heroPct)
                local heroTextW = ApproxTextWidth(heroText, p.heroPercentFont)
                Launcher.Font.DrawText(
                    Tabs.HeroPercentFont,
                    heroText,
                    x + p.heroPercentRightX - math.floor(heroTextW),
                    y + p.heroPercentCenterY - math.floor(p.heroPercentFont * 0.50),
                    0xFF281E06
                )
            end
        end
    end
end

local function DrawSelector(team)
    local s = state[team]
    if s.hold <= 0 then
        s.animatedReady = false
        return
    end
    if s.selected < 0 or s.selected > 4 then return end
    if profile == nil then return end

    -- Never render stale PP/PK candidate values from the previous manpower
    -- state. A genuine selector open marks them ready in UpdateState().
    if IsSpecialDisplay(team) and not s.specialEnergyReady then return end

    local style = OverlayStyle()
    if style == STYLE_DISABLED then
        return
    elseif style == STYLE_TABS then
        DrawTabs(team)
    else
        DrawColumn(team)
    end
end


-- Read the native menu highlight directly as a final, read-only fallback.
-- The four child states are authoritative for both HOME and AWAY and avoid
-- stale selection state overriding the current selector row.
local function ApplyNativeLiveSelector(team)
    if not SelectorActive(team) then return end
    local menu = MenuPointer(team)
    if menu == 0 then return end
    local maxRow = IsSpecialDisplay(team) and 1 or 3
    local ok, selected = pcall(function()
        for row = 0, maxRow do
            local child = menu + (row + 1) * 0x6C
            if Launcher.Mem.Long(child + 0x68) == menu
                and Launcher.Mem.Byte(child + 4) == 2
                and (Launcher.Mem.Long(child + 8) % 256) == row then
                return row
            end
        end
        return nil
    end)
    if not ok or selected == nil then return end
    local s = state[team]
    if s.selected ~= selected then
        s.selected = selected
        s.heroReveal = 0
    end
    s.hold = math.max(s.hold, POST_CLOSE_FRAMES)
    s.forceHidden = false
end

local function UpdateOverlaySurface()
    -- Some packaged user scripts can be loaded after DeviceCreated has already
    -- fired. Lazily initialize here as well so a clean mod install still works.
    if not assetsLoaded then
        LoadAssets()
    end

    EnsureStockLineSelectorState()

    if OverlayStyle() == STYLE_DISABLED then
        return
    end

    if ShouldHide() then return end
    if OverlaySurface == nil then return end


    PollCommittedLine(0)
    PollCommittedLine(1)

    -- Update PP/PK state exactly once per rendered frame/team.
    UpdateSpecialMode(0)
    UpdateSpecialMode(1)

    UpdateState(0)
    UpdateState(1)


    -- Final per-frame presentation sync: use the currently highlighted menu
    -- row, not the potentially later D8/LineChanged commit. Do not touch
    -- visibility, input, special-team state, or HERO selection.
    for team = 0, 1 do
        local s = state[team]
        if SelectorActive(team) then
            local row = ReadMenuInitialRow(team)
            local maxRow = IsSpecialDisplay(team) and 1 or 3
            if row >= 0 and row <= maxRow then
                s.selected = row
            end
        end
    end

    -- Read the live selector directly from game memory.
    ApplyNativeLiveSelector(0)
    ApplyNativeLiveSelector(1)

    Launcher.Screen.SetRenderTarget(1, OverlaySurface)
    if Launcher.Screen.BeginScene() then
        Launcher.Screen.Clear(0)
        DrawSelector(0)
        DrawSelector(1)
        Launcher.Screen.EndScene()
    end
    Launcher.Screen.ResetRenderTarget()
end

local function RenderCallback()
    if not assetsLoaded then
        LoadAssets()
    end

    EnsureStockLineSelectorState()

    if OverlayStyle() == STYLE_DISABLED then
        return
    end

    if ShouldHide() then return end
    if OverlaySurface == nil then return end

    UpdateOverlaySurfaceScale()
    Launcher.Sprite.Draw(OverlaySurface, 0, 0)
end

-- Register the callbacks required for the overlay first.
-- The launcher releases all sprites/fonts when the D3D device is destroyed.
-- Lua globals survive that transition, so cached handles must be discarded
-- when a NEW device is created. Do not call Sprite.Release/Font.Release here:
-- the launcher has already released the previous device's resources.
local function DeviceCreatedLineChange()
    assetsLoaded = false
    OverlaySurface = nil
    OverlaySurfaceScale = -1
    Column = {
        V2Base=nil, V2Tiles={}, PanelHero=nil, HeroTile=nil,
        PanelPP={}, PanelPK={}, BarGreen=nil, BarYellow=nil,
        BarRed=nil, BarHero=nil, TeamFont=nil, PercentFont=nil
    }
    Tabs = {
        PanelSel={}, PanelSelNoHero={}, PanelHero=nil, HeroTile=nil,
        PanelPP={}, PanelPK={}, MiniGreen=nil, MiniYellow=nil,
        MiniRed=nil, MiniGreenST=nil, MiniYellowST=nil, MiniRedST=nil,
        BarGreen=nil, BarYellow=nil, BarRed=nil, BarHero=nil,
        TeamFont=nil, PercentFont=nil, HeroPercentFont=nil
    }
    LoadAssets()
end
Launcher.Callback.Register("DeviceCreated", DeviceCreatedLineChange)
Launcher.Callback.Register("Reloaded", LoadAssets)
Launcher.Callback.Register("Tick", UpdateOverlaySurface)
Launcher.Callback.Register("RenderBackground", RenderCallback)

Launcher.Callback.Register("LineChanged", LineChangedCallback)

-- Apply the selector presentation state immediately as well. RenderBackground
-- will keep enforcing/restoring it if the game recreates the stock UI.
pcall(function()
    EnsureStockLineSelectorState()
end)
