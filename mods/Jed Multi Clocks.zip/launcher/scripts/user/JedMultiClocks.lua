-- Lines that start with "--" are comments. They are not executed 
-- Let's define some basic global variables to make it easier to adjust things
PenaltyTextLookup = {}
-- drgullen change started: updated/added penalties
PenaltyTextLookup[0] = "Game Misconduct"
PenaltyTextLookup[20] = "Fighting"
PenaltyTextLookup[21] = "Charging"
PenaltyTextLookup[22] = "Slashing"
PenaltyTextLookup[23] = "Roughing"
PenaltyTextLookup[24] = "Cross-Checking"
PenaltyTextLookup[25] = "Hooking"
PenaltyTextLookup[26] = "Tripping"
PenaltyTextLookup[27] = "Interference"
PenaltyTextLookup[28] = "High Sticking"
PenaltyTextLookup[29] = "Elbowing"
PenaltyTextLookup[30] = "Checking From Behind"
PenaltyTextLookup[31] = "Boarding"
PenaltyTextLookup[32] = "Holding"
PenaltyTextLookup[34] = "Hooking"
PenaltyTextLookup[35] = "Holding"
PenaltyTextLookup[36] = "Tripping"
PenaltyTextLookup[37] = "Roughing"
PenaltyTextLookup[38] = "Fighting"
PenaltyTextLookup[39] = "Fighting Instigator"
PenaltyTextLookup[40] = "Abusing the Official"
PenaltyTextLookup[41] = "Attempting to Injure"
PenaltyTextLookup[42] = "Delay of Game"
PenaltyTextLookup[43] = "Holding the Stick"
PenaltyTextLookup[44] = "Diving"
PenaltyTextLookup[45] = "Spearing"
assists = {}
for loopcount=0, 39 do
	assists[loopcount] = 0
end
clockWidth = 1024
clockHeight = 128
FontSize = 50
FontSize2 = 60
FontSize3 = 25
FontSize4 = 40
FontWeight = 760
FontWeight2 = 730

SFontsize0 = 75
SFontsize1 = 40
SFontSize2 = 25
SFontSize3 = 17
SFontSize4 = 14

FontColor6 = 0xeeEC0D0D


HomeGoalsX = 687
AwayGoalsX = 423
TimeX = 780

PPHXoffset = 411
PPAXoffset = 673

-- The following is the ideal screen resolution. Anything higher or lower will result in scaling of the surface
NativeResolutionX = 1920 
NativeResolutionY = 1080
NativeResolutionAspect = NativeResolutionY/NativeResolutionX
SurfaceSprite = 0
PauseSprite = 0
 CenterscreenX = Launcher.Screen.Width()/2
 CenterscreenY = Launcher.Screen.Height()/2

RightscreenX = Launcher.Screen.Width()
BottomscreenY = Launcher.Screen.Height()
-- Jump down to see the callback definitions


-- ************ CALLBACK FUNCTIONS ************ 

-- The following callback function is called as soon as the D3D device is created, right before the game loading screen.
-- It is only called once, so this is where we load things like fonts, textures and sprites

Launcher.Override.DisableOverlay()
function LoadAssets()
  Homebroadcast = Launcher.Config.Int("broadcaster",1)
  Statoverlay = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/"..Homebroadcast.."/statoverlay.png")
  SPOTBCKSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/"..Homebroadcast.."/Statsoverlay.png")
  Redstat = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/redstat.png")
  FontTSN = Launcher.Font.AddFile("launcher/media/fonts/Coupe-TSN-Display.otf")
  FontMagenta = Launcher.Font.AddFile("launcher/media/fonts/Tele Neo Bold.otf")
  FontMagenta2 = Launcher.Font.AddFile("launcher/media/fonts/Tele Neo Extrabold.otf")
 FontNHL = Launcher.Font.AddFile("launcher/media/fonts/trebuc.ttf")
 FontNHL2 = Launcher.Font.AddFile("launcher/media/fonts/trebucbd.ttf")
    local Width, Height
    -- First, let's load the background image of our gameclock. The image dimensions should be pow2. 
    -- 2D images drawn to the screen are called "sprites". Sprites can be scaled, rotated, faded etc.
    -- After the sprite is loaded, the handle is stored in the BGSprite variable
	
	SurfaceSprite = Launcher.Sprite.Create(NativeResolutionX, NativeResolutionY,1)
	Launcher.Sprite.Scale(SurfaceSprite,Launcher.Screen.Width()/NativeResolutionX, (Launcher.Screen.Width()*NativeResolutionAspect)/NativeResolutionY)
-- Let's retrieve the home and away team abbreviations for loading the pogs and store them in HomeAbbreviation and AwayAbbreviation global variables
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    HomeShortName = Launcher.Game.HomeShortName ()
    AwayShortName = Launcher.Game.AwayShortName ()

    
    Intro = Launcher.Config.Bool("Intro",false)
    EndHPogoffset = 0
    EndAPogoffset = 0
   if Launcher.Config.Int("broadcaster",1) == 1 then
     -- Colors are ARGB
FontColor1 = 0xeeffffff
FontColor2 = 0xee000000
FontColor3 = 0xeeecc10d
FontColor4 = 0xeeffcc1b
FontColor6 = 0xeeEC0D0D
         ClockX = 30
    ClockY = 60
    FontFamily = "Tw Cen MT"
FontFamily2 = "Coupe TSN Display"
FontFamily3 = "Trebuchet MS"
SFontSize5 = 22
ClockSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/1/clock.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/1/Pause.png")	
        STARTSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/1/Start.png")
          
SPOTBCKSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/Statsoverlay.png")          
        WCLOCKSPRITE = 1024
        HCLOCKSPRITE = 64
          
EventoffsetX = RightscreenX - 300
 EventoffsetY = -20       
        XGOALSPRITE = 0
        YGOALSPRITE = 128
        WGOALSPRITE = 440
        HGOALSPRITE = 244
        
        XPENSPRITE = 0
        YPENSPRITE = 128
        WPENSPRITE = 440
        HPENSPRITE = 252
        
        XENDSPRITE = 0
        YENDSPRITE = 876
        WENDSPRITE = 800
        HENDSPRITE = 179
        
        XGOALIESPRITE = 0
        YGOALIESPRITE = 382
        WGOALIESPRITE = 440
        HGOALIESPRITE = 244
        
         XVSSPRITE = 0
        YVSSPRITE = 628
        WVSSPRITE = 440
        HVSSPRITE = 244
        
  GoalspriteX = RightscreenX - 500
  GoalspriteY = BottomscreenY -400
  StatspriteX = GoalspriteX
    StatspriteY = GoalspriteY
  PortraitX = GoalspriteX + 35
  PortraitY = GoalspriteY + 76
  

    PenspriteX = GoalspriteX
    PenspriteY = GoalspriteY
    
        EndspriteX = CenterscreenX - (WENDSPRITE/2)
    EndspriteY = BottomscreenY - (HENDSPRITE + 128)
    
    EndHPogoffset = 139
    EndAPogoffset = -141
    
    PPortraitX = PortraitX
    PPortraitY = PortraitY
    ScorerTeamX = GoalspriteX + RightscreenX
    ScorerTeamY = GoalspriteY + BottomscreenY
  
    GOALIESprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/Goalieoverlay.png")
    FightSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/Fightoverlay.png")
     VersusSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/VSoverlay.png")
    
     
  elseif Launcher.Config.Int("broadcaster",1) == 2 then
    -- Colors are ARGB
FontColor1 = 0xeeffffff
FontColor2 = 0xeeffffff
FontColor3 = 0xeeecc10d
FontColor4 = 0xeeffcc1b
FontColor6 = 0xeeEC0D0D
             ClockX = 30
    ClockY = 30
         FontFamily = "Trebuchet MS"
FontFamily2 = "Trebuchet MS"
FontFamily3 = "Trebuchet MS"
FontSize3 = 25
FontSize2 = 20
FontSize4 = 42
SFontSize1 = 42
SFontSize2 = 35
SFontSize3 = 20
SFontSize4 = 10
SFontSize5 = 30
PPHXoffset = 400
PPAXoffset = 662
	ClockSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/2/clock.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/2/Pause.png")	
        STARTSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/2/Start.png")
   -- Nametype 1 means full name on same line
    NameType = 1      
   --  GOALSPRITEPOSX = 0
     --    GOALSPRITEPOSY = 411
       -- GOALSPRITEW = 680
        --GOALSPRITEH = 89
        
         WCLOCKSPRITE = 270
        HCLOCKSPRITE = 95
          
       EventoffsetX = RightscreenX - 300
       EventoffsetY = -20 
       
        XGOALSPRITE = 0
        YGOALSPRITE = 834
        WGOALSPRITE = 1024
        HGOALSPRITE = 94
        
        XPENSPRITE = 0
        YPENSPRITE = 834
        WPENSPRITE = 1024
        HPENSPRITE = 94
        
        XENDSPRITE = 0
        YENDSPRITE = 930
        WENDSPRITE = 1024
        HENDSPRITE = 94
        
      GoalspriteX = CenterscreenX - (WENDSPRITE/2)
  GoalspriteY = BottomscreenY - (HENDSPRITE + 30)
    StatspriteX = CenterscreenX - 100
    StatspriteY = BottomscreenY -380
    PenspriteX = GoalspriteX
    PenspriteY = GoalspriteY
  
      EndspriteX = CenterscreenX - (WENDSPRITE/2)
    EndspriteY = BottomscreenY - (HENDSPRITE + 30)
  
  PortraitX = GoalspriteX +1
  PortraitY = GoalspriteY-31
      ScorerTeamX = GoalspriteX + RightscreenX
    ScorerTeamY = GoalspriteY + BottomscreenY
  
  
    EndHPogoffset = 139
    EndAPogoffset = -141
    
    PPortraitX = PortraitX
    PPortraitY = PortraitY

    
    GOALIESprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/DELGoalieoverlay.png")
    FightSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/DELFightoverlay.png")
    VersusSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/DELVSoverlay.png")
    
    
   elseif Launcher.Config.Int("broadcaster",1) == 3 then
 FontColor1 = 0xeeffffff
FontColor2 = 0xee000000
FontColor3 = 0xeeecc10d
FontColor4 = 0xee3c3c3c
         ClockX = 30
    ClockY = 30
         FontFamily = "Trebuchet MS"
FontFamily2 = "Trebuchet MS"
FontFamily3 = "Trebuchet MS"
FontSize3 = 35

SFontSize3 = 25
SFontSize4 = 20
SFontSize5 = 20
PPHXoffset = 400
PPAXoffset = 662
     ClockSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/3/clock.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/3/Pause.png")	
        STARTSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/3/Start.png")
        
        WCLOCKSPRITE = 1024
        HCLOCKSPRITE = 64
          

        EventoffsetX = RightscreenX - 300
        EventoffsetY =-5
        XGOALSPRITE = 0
        YGOALSPRITE = 135
        WGOALSPRITE = 600
        HGOALSPRITE = 225
        
        XPENSPRITE = 0
        YPENSPRITE = 135
        WPENSPRITE = 600
        HPENSPRITE = 225
        
         XENDSPRITE = 0
        YENDSPRITE = 848
        WENDSPRITE = 800
        HENDSPRITE = 176
        
         XGOALIESPRITE = 0
        YGOALIESPRITE = 371
        WGOALIESPRITE = 434
        HGOALIESPRITE = 237
        
         XVSSPRITE = 0
        YVSSPRITE = 608
        WVSSPRITE = 434
        HVSSPRITE = 237
  
        
  GoalspriteX = 50
  GoalspriteY = BottomscreenY -375
   StatspriteX = RightscreenX - 500
    StatspriteY = BottomscreenY -400
  PortraitX = GoalspriteX + 35
  PortraitY = GoalspriteY + 77
  

    PenspriteX = GoalspriteX
    PenspriteY = GoalspriteY
    
        EndspriteX = CenterscreenX - (WENDSPRITE/2)
    EndspriteY = BottomscreenY - (HENDSPRITE + 130)
    
    EndHPogoffset = 139
    EndAPogoffset = -141
    
    PPortraitX = PortraitX
    PPortraitY = PortraitY
    ScorerTeamX = GoalspriteX + RightscreenX
    ScorerTeamY = GoalspriteY + BottomscreenY
     	ClockFontB = Launcher.Font.Load(FontFamily2,FontSize2,FontWeight2)   
          GOALSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/FGoaloverlay.png")	
    GOALIESprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/FGoalieoverlay.png")
    FightSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/FFightoverlay.png")
     VersusSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/FVSoverlay.png")
     
     
    elseif Launcher.Config.Int("broadcaster",1) == 4 then
      -- Colors are ARGB
FontColor1 = 0xeeffffff
FontColor2 = 0xee000000
FontColor3 = 0xeeecc10d
FontColor4 = 0xee3c3c3c
          ClockX = 30
    ClockY = 30
       FontFamily = "Tele Neo Bold"
       FontFamily2 = "Tele Neo Extrabold"
       FontFamily3 = "Tele Neo Bold"
       SFontSize5 = 20
	  ClockSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/4/clock.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/4/Pause.png")	
        STARTSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/4/Start.png")
    -- Nametype 1 means full name on same line
    NameType = 1
    --Locations on clock.png  X and Y Then Width and Length
        WCLOCKSPRITE = 293
        HCLOCKSPRITE = 176
    
        EventoffsetX = RightscreenX - 300
        EventoffsetY = 5
        XGOALSPRITE = 0
        YGOALSPRITE = 411
        WGOALSPRITE = 680
        HGOALSPRITE = 89
        
        XPENSPRITE = 0
        YPENSPRITE = 278
        WPENSPRITE = 680
        HPENSPRITE = 68
        
         XGOALIESPRITE = 0
        YGOALIESPRITE = 371
        WGOALIESPRITE = 434
        HGOALIESPRITE = 237
        
         XVSSPRITE = 0
        YVSSPRITE = 608
        WVSSPRITE = 434
        HVSSPRITE = 237
        
         XENDSPRITE = 85
        YENDSPRITE = 960
        WENDSPRITE = 596
        HENDSPRITE = 64
        
              EndHPogoffset = 0
    EndAPogoffset = 0
        
     --Positions of sprites on screen 
    GoalspriteX = 250
    GoalspriteY = BottomscreenY -294
        StatspriteX = CenterscreenX - 100
    StatspriteY = BottomscreenY -380
    PenspriteX =  293
    PenspriteY = 100
    EndspriteX = CenterscreenX - (WENDSPRITE/2)
    EndspriteY = BottomscreenY - (HENDSPRITE + 130)
    
    PortraitX = GoalspriteX + 161
    PortraitY = GoalspriteY -33
    PPortraitX = PenspriteX - 88
    PPortraitY = PenspriteY -60
    ScorerTeamX = GoalspriteX
    ScorerTeamY = GoalspriteY + 25
    GOALIESprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/DELGoalieoverlay.png")
    FightSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/DELFightoverlay.png")
    VersusSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/DELVSoverlay.png")
  end
  
  
    Width = Launcher.Sprite.Width(PauseSprite)
    Height = Launcher.Sprite.Height(PauseSprite)
    Launcher.Sprite.Scale(PauseSprite,(Launcher.Screen.Height()*(Width/Height))/Width,Launcher.Screen.Height()/Height)
 Launcher.Sprite.Scale(STARTSprite,(Launcher.Screen.Height()*(Width/Height))/Width,Launcher.Screen.Height()/Height)
    -- Next, let's load a font that we can use later to draw text
    -- The font handle will then be stored in the global variable, ClockFont
    ClockFont = Launcher.Font.Load(FontFamily2,FontSize,FontWeight)
	ClockFontB = Launcher.Font.Load(FontFamily2,FontSize2,FontWeight2)
  	ClockFontS2 = Launcher.Font.Load(FontFamily2,FontSize2,FontWeight,false, false, false, true)
    ClockFontS = Launcher.Font.Load(FontFamily2,FontSize4,FontWeight2)
	ClockFontPP = Launcher.Font.Load(FontFamily2,FontSize3,FontWeight)
  	ClockFontPP2 = Launcher.Font.Load(FontFamily2,35,FontWeight)
  ScoreFontXS = Launcher.Font.Load(FontFamily2,SFontSize4,FontWeight2)
  ScoreFontS = Launcher.Font.Load(FontFamily2,SFontSize3,FontWeight2)
  ScoreFontM = Launcher.Font.Load(FontFamily2,SFontSize2,FontWeight2)
  ScoreFontL = Launcher.Font.Load(FontFamily2,SFontsize1,FontWeight2)
  ScoreFontXL = Launcher.Font.Load(FontFamily2,SFontsize0,FontWeight2)
  StatsFontS = Launcher.Font.Load(FontFamily3,SFontSize5,FontWeight2)
  StatsFontM = Launcher.Font.Load(FontFamily3,SFontSize2,FontWeight2)
   StatsFontL = Launcher.Font.Load(FontFamily3,45,900)
 CommentFont = Launcher.Font.Load(FontFamily2,20,900,false, false, false, false)
 STARTFont = Launcher.Font.Load(FontFamily2,45,900,true, false, false, true)
  --GOAL
  TSNfont2 = Launcher.Font.Load("Arial Black",15,800, false, false, false, true)


    


	
    -- Let's retrieve the home and away team abbreviations for loading the pogs and store them in HomeAbbreviation and AwayAbbreviation global variables
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    HomeFullName = Launcher.Game.HomeFullName()
    AwayFullName = Launcher.Game.AwayFullName()
        ArenaName = Launcher.Game.ArenaName ()
    ArenaLocation = Launcher.Game.ArenaLocation ()
    -- Now that we have the abbreviations, we can load the pog images as sprites and store the sprite handles in HomePog and AwayPog
    HomePog = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/"..HomeAbbreviation..".png")
    AwayPog = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/"..AwayAbbreviation..".png")

end


function DeviceCreatedCallback()
    
	LoadAssets()

end

function PlayStoppedCallback(Reason)
Assist1ID = -1
		for loopcount=0, 39 do
			if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
				if Launcher.Player.Assists(loopcount) ~= assists [loopcount] then		
					Assist1ID = loopcount
					assists [loopcount] = assists [loopcount] + 1
					break
				end
			end
		end
		Assist2ID = -1
		if Assist1ID ~= -1 then
			for loopcount=0, 39 do
				if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
					if Launcher.Player.Assists(loopcount) ~= assists [loopcount] then		
						Assist2ID = loopcount
						assists [loopcount] = assists [loopcount] + 1
						break
					end
				end
			end
		end
    end
function ShotCallback()
if tonumber (string.sub(Launcher.Game.ShotSpeed(),1,2))>70 then
	Shotspeed = string.sub(Launcher.Game.ShotSpeed(),1,2)
end
end
function CutsceneStartedCallback(CutsceneID) 
Cutscenetype = CutsceneID
end
function ReloadedCallback()
	LoadAssets()
end
-- The following callback function is called every frame for doing our own drawing
function RenderCallback()
   
    if Launcher.Game.Paused() and not Launcher.Game.InReplay() then
        X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(PauseSprite)*0.5
        Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(PauseSprite)*0.5
        Launcher.Sprite.Draw(PauseSprite,X,Y)
        return
    end
   
  if Launcher.Game.InCutscene() then
       if SPOTPLAYER ==-1 then
    SPOTPLAYER = math.random(0, 39)
   end
-- Launcher.Font.DrawText(ScoreFontL,Cutscenetype, CenterscreenX ,ClockY +450,FontColor3) 
SPOTPLAYER = Launcher.Game.CutscenePlayer ()
 --Launcher.Font.DrawText(ScoreFontL,SPOTPLAYER, CenterscreenX ,ClockY +550,FontColor3)

 if SPOTPLAYER >-1 then
 --Launcher.Font.DrawText(ScoreFontL,Launcher.Player.LastName (SPOTPLAYER), CenterscreenX -50 ,ClockY +650,FontColor6)
  --Launcher.Font.DrawText(ScoreFontL,Launcher.Cutscene.PlayerText2 (), CenterscreenX ,ClockY +700,FontColor3)
 end
     local X, Y
        local HomeGoals = Launcher.Stats.HomeGoals()
        local AwayGoals = Launcher.Stats.AwayGoals()
         local PPAwayGoals = Launcher.Stats.AwayPowerPlayGoals()
          local PPHomeGoals = Launcher.Stats.HomePowerPlayGoals()
          
            local PPACount = Launcher.Stats.AwayPowerPlays()
           local PPHCount = Launcher.Stats.HomePowerPlays()
           
            local HP1Goals = Launcher.PeriodStats.GoalsHome(0)
           local HP2Goals = Launcher.PeriodStats.GoalsHome(1)
           local HP3Goals = Launcher.PeriodStats.GoalsHome(2)
           local HP1Shots = Launcher.PeriodStats.ShotsHome (0)
           local HP2Shots = Launcher.PeriodStats.ShotsHome (1)
           local HP3Shots = Launcher.PeriodStats.ShotsHome (2)
           
            local AP1Goals = Launcher.PeriodStats.GoalsAway(0)
           local AP2Goals = Launcher.PeriodStats.GoalsAway(1)
           local AP3Goals = Launcher.PeriodStats.GoalsAway(2)
           local AP1Shots = Launcher.PeriodStats.ShotsAway (0)
           local AP2Shots = Launcher.PeriodStats.ShotsAway (1)
           local AP3Shots = Launcher.PeriodStats.ShotsAway (2)
           local Period2 =  Launcher.Game.Period()
           Period3 = Period2 - 1
    	
    ScorePlayer = Launcher.Game.LastGoalPlayer ()
    ScorePlayerLName = Launcher.Player.LastName (ScorePlayer)
    ScorePlayerTeam = Launcher.Game.LastGoalTeam ()
    
ScorePlayerFName = Launcher.Player.FirstName (ScorePlayer)
ScorerPregameGoals = Launcher.Player.PregameGoals (ScorePlayer)
ScorerGoals = Launcher.Player.Goals (ScorePlayer)
ScorerAssists = Launcher.Player.Assists (ScorePlayer)
ScorerPoints = Launcher.Player.Points (ScorePlayer)
ScorerMinus = Launcher.Player.PlusMinus(ScorePlayer)
ScorerHits = Launcher.Player.Hits (ScorePlayer)
ScorerShots = Launcher.Player.Shots(ScorePlayer)
ScorerPhoto = Launcher.Player.Photo (ScorePlayer)
ScorerPhoto4 = string.format ("%04d" , ScorerPhoto )
ScorerPhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..ScorerPhoto4..".jpg")




Homegoalie = 18
Homegoalietime = Launcher.Player.Time (Homegoalie)
if Homegoalietime == 0
then Homegoalie =19
  end
HomegoalieLName = Launcher.Player.LastName (Homegoalie)
HomegoalieLenght = string.len(HomegoalieLName)
HomeGoalieOffset = (HomegoalieLenght * 6.5)/2
HomegoalieSA = Launcher.Player.ShotsAgainst (Homegoalie)
HomegoalieSV = Launcher.Player.Saves (Homegoalie)
HomegoaliePhoto = Launcher.Player.Photo (Homegoalie)
HomegoaliePhoto4 = string.format ("%04d" , HomegoaliePhoto )
HomegoaliePhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..HomegoaliePhoto4..".jpg")
Awaygoalie = 38
Awaygoalietime = Launcher.Player.Time (Awaygoalie)
if Awaygoalietime == 0
then Awaygoalie = 39
  end
AwaygoalieLName = Launcher.Player.LastName (Awaygoalie) 
AwaygoalieLenght = string.len(AwaygoalieLName)
AwayGoalieOffset = (AwaygoalieLenght * 6.5)/2
AwaygoalieSA = Launcher.Player.ShotsAgainst (Awaygoalie)
AwaygoalieSV = Launcher.Player.Saves (Awaygoalie)
AwaygoaliePhoto = Launcher.Player.Photo (Awaygoalie)
AwaygoaliePhoto4 = string.format ("%04d" , AwaygoaliePhoto )
AwaygoaliePhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..AwaygoaliePhoto4..".jpg")
-- intro overlay
if  Cutscenetype == 44 and Intro == true then
  
 
    StartX = CenterscreenX-220
    StartY = 40
 X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(STARTSprite)*0.5
        Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(STARTSprite)*0.5
        Launcher.Sprite.Draw(STARTSprite,X,Y)
  Launcher.Font.DrawText(ScoreFontL,HomeFullName, CenterscreenX -750 ,ClockY +250,FontColor3)   
  Launcher.Font.DrawText(ScoreFontL,AwayFullName, CenterscreenX +350 ,ClockY +250,FontColor3) 
 for i = 0, 17 do
   Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i), CenterscreenX -750 ,ClockY +300+22*i,FontColor1)
      Launcher.Font.DrawText(StatsFontS,"G:"..Launcher.Player.PregameGoals(i), CenterscreenX -400 ,ClockY +302+22*i,FontColor3)
      Launcher.Font.DrawText(StatsFontS,"| A:"..Launcher.Player.PregameAssists(i), CenterscreenX -340 ,ClockY +302+22*i,FontColor3)
    Launcher.Font.DrawText(StatsFontS,"| P:"..Launcher.Player.SeasonPoints(i), CenterscreenX -270 ,ClockY +302+22*i,FontColor3)
end
for i = 18, 19 do
  
  Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i), CenterscreenX -750 ,ClockY +320+22*i,FontColor3)
        Launcher.Font.DrawText(StatsFontS,"W:"..Launcher.Player.SeasonGoalieWins(i).." | L:"..Launcher.Player.SeasonGoalieLosses(i).." | T: "..Launcher.Player.SeasonGoalieTies(i), CenterscreenX -400 ,ClockY +320+22*i,FontColor1)

--   
--   
end

for k = 20, 37 do
   
  Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k), CenterscreenX +350 ,ClockY +300+22*(k-20),FontColor1)
    Launcher.Font.DrawText(StatsFontS,"G:"..Launcher.Player.PregameGoals(k), CenterscreenX +700 ,ClockY +302+22*(k-20),FontColor3)
      Launcher.Font.DrawText(StatsFontS,"| A:"..Launcher.Player.PregameAssists(k), CenterscreenX +760 ,ClockY +302+22*(k-20),FontColor3)
    Launcher.Font.DrawText(StatsFontS,"| P:"..Launcher.Player.SeasonPoints(k), CenterscreenX +830 ,ClockY +302+22*(k-20),FontColor3)
end
for k = 38, 39 do
   
  Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k), CenterscreenX +350 ,ClockY +320+22*(k-20),FontColor3)
     Launcher.Font.DrawText(StatsFontS,"W:"..Launcher.Player.SeasonGoalieWins(k).." | L:"..Launcher.Player.SeasonGoalieLosses(k).." | T: "..Launcher.Player.SeasonGoalieTies(k), CenterscreenX +700 ,ClockY +320+22*(k-20),FontColor1)
end

  
end
-- Test spotlight player
 if  Cutscenetype == 21  or Cutscenetype == 20 or Cutscenetype == 17 or Cutscenetype == 84  or Cutscenetype == 22 then
   SPOTPLAYER = Launcher.Game.CutscenePlayer ()
   --if SPOTPLAYER ==-1 then
    -- SPOTPLAYER = math.random(0, 39)
    -- end
    
    
    --   Launcher.Player.SeasonGoalieGames(PlayerID)
--   Launcher.Player.SeasonGoalieGoals(PlayerID)
--   Launcher.Player.SeasonGoalieAssists(PlayerID)
--   Launcher.Player.SeasonGoaliePIM(PlayerID)
--   Launcher.Player.SeasonGoalieMinutes(PlayerID)
--   Launcher.Player.SeasonGoalieGoalsAgainst(PlayerID)
--   Launcher.Player.SeasonGoalieShotsAgainst(PlayerID)
--   Launcher.Player.SeasonGoalieSaves(PlayerID)
--   Launcher.Player.SeasonGoalieWins(PlayerID)
--   Launcher.Player.SeasonGoalieLosses(PlayerID)
--   Launcher.Player.SeasonGoalieTies(PlayerID)
--   Launcher.Player.SeasonGoalieShutouts(PlayerID)
--   Launcher.Player.SeasonGoalieGAA(PlayerID)
--   Launcher.Player.SeasonGoalieSavePercentage(PlayerID)
--   Launcher.Player.GameGoalieGoalsAgainst(PlayerID)

   TOISpotPlayer = Launcher.Player.Time (SPOTPLAYER)
   SPOTPhoto = Launcher.Player.Photo (SPOTPLAYER)
SPOTPhoto4 = string.format ("%04d" , SPOTPhoto )
SPOTGoals = Launcher.Player.Goals (SPOTPLAYER)
SPOTAssists = Launcher.Player.Assists (SPOTPLAYER)
SPOTPoints = Launcher.Player.Points (SPOTPLAYER)
SPOTShots = Launcher.Player.Shots (SPOTPLAYER)
SPOTPIMs = Launcher.Player.PIM (SPOTPLAYER)
SPOTPPGs = Launcher.Player.PPG (SPOTPLAYER)
SPOTSHGs = Launcher.Player.SHG (SPOTPLAYER)
SPOTHits = Launcher.Player.Hits (SPOTPLAYER)
SPOTMinus = Launcher.Player.PlusMinus (SPOTPLAYER)
if  SPOTPLAYER == 38 or  SPOTPLAYER == 39 or SPOTPLAYER == 18 or SPOTPLAYER == 19 then
 SPOTGoalieSA = Launcher.Player.ShotsAgainst (SPOTPLAYER)
SPOTGoalieGP = Launcher.Player.SeasonGoalieGames (SPOTPLAYER)
SPOTGoalieSAS = Launcher.Player.SeasonGoalieShotsAgainst (SPOTPLAYER)
SPOTGoalieGA = Launcher.Player.SeasonGoalieGoalsAgainst (SPOTPLAYER)
SPOTGoalieWin = Launcher.Player.SeasonGoalieWins (SPOTPLAYER)
SPOTGoalieSO = Launcher.Player.SeasonGoalieShutouts (SPOTPLAYER)
SPOTGoalieT = Launcher.Player.SeasonGoalieTies (SPOTPLAYER)
SPOTGoalieL = Launcher.Player.SeasonGoalieLosses (SPOTPLAYER)
SPOTGoalieGAA = string.format("%.2f",Launcher.Player.SeasonGoalieGAA (SPOTPLAYER))
SPOTGoalieSV = Launcher.Player.SeasonGoalieSaves(SPOTPLAYER)
SPOTGoalieSVPercentage = string.format("%.3f",Launcher.Player.SeasonGoalieSavePercentage(SPOTPLAYER))
    SPOTGoalieHasSeasonStats =
        SPOTGoalieGP > 0
        or SPOTGoalieSAS > 0
        or SPOTGoalieGA > 0

    SPOTGoalieCurrentSA = Launcher.Player.ShotsAgainst(SPOTPLAYER) or 0
    SPOTGoalieCurrentGA = Launcher.Player.GameGoalieGoalsAgainst(SPOTPLAYER) or 0
    SPOTGoalieCurrentSaves = SPOTGoalieCurrentSA - SPOTGoalieCurrentGA

    if SPOTGoalieCurrentSA > 0 then
        SPOTGoalieCurrentSVPercentage =
            string.format("%.3f", SPOTGoalieCurrentSaves / SPOTGoalieCurrentSA)
    else
        SPOTGoalieCurrentSVPercentage = ".000"
    end
end
SPOTPhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..SPOTPhoto4..".jpg")

Launcher.Sprite.Clip(SPOTBCKSprite,0,0,640,245)
				Launcher.Sprite.Draw(SPOTBCKSprite, StatspriteX-180, StatspriteY+130)
 if SPOTPLAYER >= 20 then 
   SPOTTEAM = HomeAbbreviation
   
      Launcher.Sprite.Draw(AwayPog,StatspriteX-180,StatspriteY  +311)
      else 
     SPOTTEAM = AwayAbbreviation
    
    
				Launcher.Sprite.Draw(HomePog,StatspriteX-180 ,StatspriteY  +311)
     end
   if   SPOTPhotoSprite == nil then
  SPOTPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
 
end
Launcher.Sprite.Draw(SPOTPhotoSprite, StatspriteX -163 ,StatspriteY  +178 )

      
      
   			TOIMinutes = math.floor(TOISpotPlayer/60)
			if TOIMinutes < 10 then
				-- let's pad a zero if it's 9 or less so it looks nicer
				local TOIMinutes = "0"..TOIMinutes
			end
			
			-- % is modulo. Modulo means the remainder of a division
			-- So in our case, the remainder of dividing the time by 60 would be the seconds component
			TOISeconds = TOISpotPlayer % 60
			if TOISeconds < 10 then
				-- let's pad a zero if it's 9 or less so it looks nicer
				TOISeconds = "0"..TOISeconds
			end 
   Launcher.Font.DrawText(StatsFontL,Launcher.Player.FirstName (SPOTPLAYER).." "..Launcher.Player.LastName (SPOTPLAYER), StatspriteX -170 ,StatspriteY  +128,FontColor1)
   Launcher.Font.DrawText(StatsFontM,"TOI", StatspriteX -25 ,StatspriteY  +178,FontColor1)
   Launcher.Font.DrawText(ScoreFontL,TOIMinutes..":"..TOISeconds, StatspriteX -45 ,StatspriteY  +196,FontColor3)
if SPOTPLAYER == 38 or SPOTPLAYER == 39 or SPOTPLAYER == 18 or SPOTPLAYER == 19 then

    if SPOTGoalieHasSeasonStats then

        Launcher.Font.DrawText(StatsFontL,"GP: "..SPOTGoalieGP,StatspriteX +82 ,StatspriteY +310,FontColor1)
        Launcher.Font.DrawText(StatsFontL,"W: "..SPOTGoalieWin,StatspriteX +212 ,StatspriteY +310,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"Shutouts: "..SPOTGoalieSO,StatspriteX +215 ,StatspriteY +350,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"GAA: "..SPOTGoalieGAA,StatspriteX +334 ,StatspriteY +315,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"SV%: "..SPOTGoalieSVPercentage,StatspriteX +337 ,StatspriteY +340,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"W "..SPOTGoalieWin.." | L "..SPOTGoalieL.." | T "..SPOTGoalieT,StatspriteX -63 ,StatspriteY +282,FontColor1)
        Launcher.Font.DrawText(StatsFontL,"Shots against: "..SPOTGoalieSA,StatspriteX +100 ,StatspriteY +200,FontColor3)

    else

        Launcher.Font.DrawText(StatsFontL,"GA: "..SPOTGoalieCurrentGA,StatspriteX +82 ,StatspriteY +310,FontColor1)
        Launcher.Font.DrawText(StatsFontL,"SA: "..SPOTGoalieCurrentSA,StatspriteX +212 ,StatspriteY +310,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"Saves: "..SPOTGoalieCurrentSaves,StatspriteX +215 ,StatspriteY +350,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"SV%: "..SPOTGoalieCurrentSVPercentage,StatspriteX +337 ,StatspriteY +340,FontColor1)
        Launcher.Font.DrawText(StatsFontL,"Shots against: "..SPOTGoalieCurrentSA,StatspriteX +100 ,StatspriteY +200,FontColor3)

    end
if  Cutscenetype == 84 then
  
  if SPOTGoalieSO == 0 then
    Launcher.Font.DrawText(StatsFontL,"First shutout bid",StatspriteX +120 ,StatspriteY +300,FontColor1)
  elseif SPOTGoalieSO == 1 then
    Launcher.Font.DrawText(StatsFontL,"2nd shutout bid",StatspriteX +120 ,StatspriteY +300,FontColor1)
  elseif SPOTGoalieSO == 2 then
    Launcher.Font.DrawText(StatsFontL,"3rd shutout bid",StatspriteX +120 ,StatspriteY +300,FontColor1)
  else
    Bid = SPOTGoalieSO +1
    Launcher.Font.DrawText(StatsFontL,Bid.."th shutout bid",StatspriteX +120 ,StatspriteY +300,FontColor1)
  
   end -- existing skater display continues here
 end
     else
   Launcher.Font.DrawText(StatsFontL,"G: "..Launcher.Player.SeasonGoals (SPOTPLAYER),StatspriteX +82 ,StatspriteY  +310,FontColor1)
Launcher.Font.DrawText(StatsFontL,"A: "..Launcher.Player.SeasonAssists (SPOTPLAYER),StatspriteX +212 ,StatspriteY  +310,FontColor1)
Launcher.Font.DrawText(StatsFontL,"P: "..Launcher.Player.SeasonPoints (SPOTPLAYER),StatspriteX +338 ,StatspriteY  +310,FontColor1)
Launcher.Font.DrawText(StatsFontS,"Shot(s)   -   Hit(s)",StatspriteX -62 ,StatspriteY  +250,FontColor1)
Launcher.Font.DrawText(StatsFontS,Launcher.Player.Shots (SPOTPLAYER),StatspriteX -40, StatspriteY  +270,FontColor1)
Launcher.Font.DrawText(StatsFontS,Launcher.Player.Hits (SPOTPLAYER),StatspriteX +40 ,StatspriteY  +270,FontColor1)
if  SPOTGoals > 0  then
  Launcher.Font.DrawText(StatsFontM,"Tonight +"..SPOTGoals,StatspriteX +82 ,StatspriteY  +350,FontColor3)
end
if  SPOTAssists > 0  then
  Launcher.Font.DrawText(StatsFontM,"Tonight +"..SPOTAssists,StatspriteX +215 ,StatspriteY  +350,FontColor3)
end
if SPOTPLAYER < 20 then
  STATCOUNT = 0
for i = 0, 17 do
 
 if Launcher.Player.Points (i) > 1 or Launcher.Player.Goals (i) > 0 then
   if SPOTPLAYER == i then
     Launcher.Font.DrawText(StatsFontS,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i),StatspriteX +114 ,StatspriteY  +180 + STATCOUNT,FontColor3)
   Launcher.Font.DrawText(StatsFontS,"G: "..Launcher.Player.Goals (i).."     A: "..Launcher.Player.Assists (i),StatspriteX +290 ,StatspriteY  +180 + STATCOUNT,FontColor3)
     else
   Launcher.Font.DrawText(StatsFontS,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i),StatspriteX +114 ,StatspriteY  +180 + STATCOUNT,FontColor1)
   Launcher.Font.DrawText(StatsFontS,"G: "..Launcher.Player.Goals (i).."     A: "..Launcher.Player.Assists (i),StatspriteX +290 ,StatspriteY  +180 + STATCOUNT,FontColor1)
   end
   STATCOUNT = STATCOUNT + 15
 end
 end
end
if SPOTPLAYER > 20 and SPOTPLAYER <38 then
  STATCOUNT = 0
for k = 20, 37 do
  
 if Launcher.Player.Points (k) > 1 or Launcher.Player.Goals (k) > 0 then
   if SPOTPLAYER == k then
     Launcher.Font.DrawText(StatsFontS,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k),StatspriteX +114 ,StatspriteY  +180 + STATCOUNT,FontColor3)
   Launcher.Font.DrawText(StatsFontS,"G: "..Launcher.Player.Goals (k).."     A: "..Launcher.Player.Assists (k),StatspriteX +290 ,StatspriteY  +180 + STATCOUNT,FontColor3)
     else
   Launcher.Font.DrawText(StatsFontS,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k),StatspriteX +114 ,StatspriteY  +180 + STATCOUNT,FontColor1)
   Launcher.Font.DrawText(StatsFontS,"G: "..Launcher.Player.Goals (k).."     A: "..Launcher.Player.Assists (k),StatspriteX +290 ,StatspriteY  +180 + STATCOUNT,FontColor1)
   end
   STATCOUNT = STATCOUNT + 15
 end
 end
end


   end
   end

-- Goal scoring overlay
    if  Cutscenetype == 42 or Cutscenetype == 37 or Cutscenetype == 38  or Cutscenetype == 43 or Cutscenetype == 41 or Cutscenetype == 39 or Cutscenetype == 78 or Cutscenetype == 77 then
    if ScorePlayer >= 20 then  
      Launcher.Sprite.Draw(AwayPog,GoalspriteX +30 ,GoalspriteY  +30)
      else 
    
    
				Launcher.Sprite.Draw(HomePog,GoalspriteX +30 ,GoalspriteY  +30)
     end
if   ScorerPhotoSprite == nil then
  ScorerPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
 
end
		
    	if Assist1ID ~= -1 then
					Assist1Name = string.sub(Launcher.Player.FirstName(Assist1ID), 1, 1).. " " .. Launcher.Player.LastName(Assist1ID).." ("..Launcher.Player.Assists (Assist1ID)..")"
									else
					Assist1Name = "UNASSISTED"
				end
				if Assist2ID ~= -1 then
					Assist2Name = "- "..string.sub(Launcher.Player.FirstName(Assist2ID), 1, 1).. " " .. Launcher.Player.LastName(Assist2ID).." ("..Launcher.Player.Assists (Assist2ID)..")"
				
				else
					Assist2Name = " "
				end
Launcher.Sprite.Draw(ScorerPhotoSprite, PortraitX,PortraitY )

      Launcher.Sprite.Clip(ClockSprite,XGOALSPRITE,YGOALSPRITE,WGOALSPRITE,HGOALSPRITE)
				Launcher.Sprite.Draw(ClockSprite, GoalspriteX, GoalspriteY)
        if ScorePlayer < 20 then 
    ScorerTeam = HomeFullName

  else
    ScorerTeam = AwayFullName

				
    end
        if NameType == 1 then  
          Launcher.Font.DrawText(ScoreFontL,ScorePlayerFName.." "..ScorePlayerLName,GoalspriteX +277 ,GoalspriteY  +4,FontColor1)
          if Launcher.Config.Int("broadcaster",1) ~= 4 then
          Launcher.Font.DrawText(ScoreFontS,"TONIGHT G:"..ScorerGoals.." A:"..ScorerAssists.." / PTS:"..ScorerPoints,GoalspriteX +241 ,GoalspriteY  +38,FontColor4)
           
          else
          end
          if Assist1Name == "UNASSISTED" then
            Launcher.Font.DrawText(ScoreFontM,"UNASSISTED",GoalspriteX +277 ,GoalspriteY  +52,FontColor1)
            else
          Launcher.Font.DrawText(ScoreFontM,"A: "..Assist1Name.." "..Assist2Name,GoalspriteX +277 ,GoalspriteY  +52,FontColor1)
          end
        else 
Launcher.Font.DrawText(ScoreFontM,ScorePlayerFName,GoalspriteX +140 ,GoalspriteY  +100,FontColor1)
Launcher.Font.DrawText(ScoreFontL,ScorePlayerLName,GoalspriteX +140 ,GoalspriteY  +120,FontColor1)
Launcher.Font.DrawText(StatsFontS,ScorerShots.." SHOT(s)",GoalspriteX +45 ,GoalspriteY  +195,FontColor1)
Launcher.Font.DrawText(StatsFontM,ScorerGoals.." GOAL(s)",GoalspriteX +140 ,GoalspriteY  +74,FontColor1)
Launcher.Font.DrawText(StatsFontM,ScorerAssists.." ASSIST(s)",GoalspriteX +240 ,GoalspriteY  +74,FontColor1)
Launcher.Font.DrawText(StatsFontS,"G: "..Launcher.Player.SeasonGoals (ScorePlayer),GoalspriteX +140 ,GoalspriteY  +201,FontColor3)
Launcher.Font.DrawText(StatsFontS,"| A: "..Launcher.Player.SeasonAssists (ScorePlayer),GoalspriteX +190 ,GoalspriteY  +201,FontColor3)
Launcher.Font.DrawText(StatsFontS,"| P: "..Launcher.Player.SeasonPoints (ScorePlayer),GoalspriteX +255 ,GoalspriteY  +201,FontColor3)

if Assist1Name == "UNASSISTED" then
            Launcher.Font.DrawText(ScoreFontS,"UNASSISTED",GoalspriteX +140 ,GoalspriteY  +155,FontColor1)
            else
          Launcher.Font.DrawText(ScoreFontS,Assist1Name.." "..Assist2Name,GoalspriteX +140 ,GoalspriteY  +155,FontColor1)
          end

end




if Launcher.Config.Int("broadcaster",1) == 1 or Launcher.Config.Int("broadcaster",1) == 3 then
  
if Launcher.Game.ShotSpeed() ~= nil then
if tonumber (string.sub(Launcher.Game.ShotSpeed(),1,2))>80 then
Launcher.Font.DrawText(ScoreFontS,"SHOT SPEED: "..Shotspeed.." MPH",GoalspriteX +140 ,GoalspriteY  +31,FontColor4)
end
end


  
if HomeGoals == 1 and AwayGoals == 0 then
  Launcher.Font.DrawText(StatsFontS,"FIRST GOAL OF THE GAME",GoalspriteX +150 ,GoalspriteY  +10,FontColor1)
elseif  HomeGoals == 0 and AwayGoals == 1 then
   Launcher.Font.DrawText(StatsFontS,"FIRST GOAL OF THE GAME",GoalspriteX +150 ,GoalspriteY  +10,FontColor1)
   elseif (HomeGoals + AwayGoals) > 1 then
if HomeGoals == AwayGoals then
Launcher.Font.DrawText(StatsFontS,"GAME-TYING GOAL",GoalspriteX +170 ,GoalspriteY  +10,FontColor1)
elseif HomeGoals == AwayGoals + 1 and ScorePlayer < 20 or  AwayGoals == HomeGoals + 1 and ScorePlayer >= 20 then
Launcher.Font.DrawText(StatsFontS,"GO-AHEAD GOAL",GoalspriteX +160 ,GoalspriteY  +10,FontColor1)
  end

end
end 
if Launcher.Config.Int("broadcaster",1) == 2 then
  Launcher.Sprite.Clip(ClockSprite,724,216 +((Launcher.Config.Int("events",1)-1)*128),300,128)
		Launcher.Sprite.Draw(ClockSprite, EventoffsetX , GoalspriteY + EventoffsetY)
  
  Launcher.Font.DrawText(ScoreFontS,ScorerTeam,GoalspriteX +700 ,GoalspriteY  +4,FontColor4)
if Launcher.Game.ShotSpeed() ~= nil then
if tonumber (string.sub(Launcher.Game.ShotSpeed(),1,2))>80 then
Launcher.Font.DrawText(STatsFontM,"SHOT SPEED: "..Shotspeed.." MPH",GoalspriteX +130 ,GoalspriteY  - 30,FontColor4)
end
end
if HomeGoals == 1 and AwayGoals == 0 then
  Launcher.Font.DrawText(StatsFontS,"FIRST GOAL OF THE GAME",GoalspriteX +700 ,GoalspriteY  +18,FontColor1)
elseif  HomeGoals == 0 and AwayGoals == 1 then
   Launcher.Font.DrawText(StatsFontS,"FIRST GOAL OF THE GAME",GoalspriteX +700 ,GoalspriteY  +18,FontColor1)
   elseif (HomeGoals + AwayGoals) > 1 then
if HomeGoals == AwayGoals then
Launcher.Font.DrawText(StatsFontS,"GAME-TYING GOAL",GoalspriteX +700 ,GoalspriteY  +18,FontColor1)
elseif HomeGoals == AwayGoals + 1 and ScorePlayer < 20 or  AwayGoals == HomeGoals + 1 and ScorePlayer >= 20 then
Launcher.Font.DrawText(StatsFontS,"GO-AHEAD GOAL",GoalspriteX +700 ,GoalspriteY  +18,FontColor1)
  end
end
end 
 if Cutscenetype == 77 then
   Launcher.Font.DrawText(StatsFontS,"HAT TRICK",GoalspriteX +190 ,GoalspriteY  +17,FontColor1)
 end
 end
 if  ScorerPhotoSprite ~= nil then
  Launcher.Sprite.Release(ScorerPhotoSprite)
  if AwayPog ~= nil then
Launcher.Sprite.Release(AwayPog)
    AwayPog = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/"..AwayAbbreviation..".png")
end
if HomePog ~= nil then
Launcher.Sprite.Release(HomePog)
HomePog = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/"..HomeAbbreviation..".png")
end
end

 -- goalies overlay
 if Launcher.Config.Int("Overlays",1) == 3 then
 if Cutscenetype == 17 or Cutscenetype == 57 or Cutscenetype == 62 or Cutscenetype == 63 or Cutscenetype == 64 then
   
if  HomegoalieSA ==nil or AwaygoalieSA== nil then
  HomeSavespercent = 0
  AwaySavespercent = 0
  else
HomeSavespercent = (HomegoalieSA-AwayGoals)/HomegoalieSA
AwaySavespercent = (AwaygoalieSA-HomeGoals)/AwaygoalieSA
HomeSavespercent2 = string.format("%.3f",HomeSavespercent)
AwaySavespercent2 = string.format("%.3f",AwaySavespercent)
end 
   if   HomegoaliePhotoSprite == nil then
 HomegoaliePhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
elseif  AwaygoaliePhotoSprite == nil then
AwaygoaliePhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
end
Launcher.Sprite.Draw(HomegoaliePhotoSprite, PortraitX,PortraitY )
Launcher.Sprite.Draw(AwaygoaliePhotoSprite, PortraitX+280,PortraitY )
 Launcher.Sprite.Clip(ClockSprite,XGOALIESPRITE,YGOALIESPRITE,WGOALIESPRITE,HGOALIESPRITE)
Launcher.Sprite.Draw(ClockSprite, GoalspriteX,GoalspriteY+6)
Launcher.Font.DrawText(ScoreFontM,"GA",GoalspriteX +155 ,GoalspriteY  +75,FontColor1)
Launcher.Font.DrawText(ScoreFontM,"GA",GoalspriteX +258 ,GoalspriteY  +75,FontColor1)
Launcher.Font.DrawText(ScoreFontL,AwayGoals,GoalspriteX +160,GoalspriteY  +104,FontColor3)
Launcher.Font.DrawText(ScoreFontL,HomeGoals,GoalspriteX +263 ,GoalspriteY  +104,FontColor3)
Launcher.Font.DrawText(ScoreFontM,"SA:"..HomegoalieSA,GoalspriteX +142 ,GoalspriteY  +150,FontColor1)
Launcher.Font.DrawText(ScoreFontM,"SA:"..AwaygoalieSA,GoalspriteX +245 ,GoalspriteY  +150,FontColor1)
Launcher.Font.DrawText(ScoreFontS,"GOALIES TONIGHT",GoalspriteX +170 ,GoalspriteY  +10,FontColor1)

Launcher.Font.DrawText(ScoreFontXS,HomegoalieLName,PortraitX+39-HomeGoalieOffset ,GoalspriteY  +203,FontColor1)
Launcher.Font.DrawText(ScoreFontXS,AwaygoalieLName,PortraitX +327-AwayGoalieOffset,GoalspriteY  +203,FontColor1)
Launcher.Font.DrawText(ScoreFontS,HomeSavespercent2,PortraitX+111 ,GoalspriteY  +182,FontColor1)
Launcher.Font.DrawText(ScoreFontS,AwaySavespercent2,PortraitX+221 ,GoalspriteY  +182,FontColor1)
end
end
 if HomegoaliePhotoSprite ~= nil then
  Launcher.Sprite.Release(HomegoaliePhotoSprite)
end
 if AwaygoaliePhotoSprite ~= nil then
  Launcher.Sprite.Release(AwaygoaliePhotoSprite)
end
-- fighters overlay
if Launcher.Config.Int("Overlays",1) == 3 then
  if Cutscenetype == 13  then
Homefighter = Launcher.Game.HomeFighter ()
HomefighterLName = Launcher.Player.LastName (Homefighter)
HomefighterLenght = string.len(HomefighterLName)
HomefighterOffset = (HomefighterLenght * 6.5)/2
HomefighterFName = Launcher.Player.FirstName (Homefighter)
HomefighterPhoto = Launcher.Player.Photo (Homefighter)
HomefighterPhoto4 = string.format ("%04d" , HomefighterPhoto )
HomefighterPhotoSprite =  Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..HomefighterPhoto4..".jpg")
HomefighterBalance = Launcher.Player.Balance (Homefighter)
HomefighterAggression = Launcher.Player.Aggression (Homefighter)
Awayfighter = Launcher.Game.AwayFighter ()
AwayfighterLName = Launcher.Player.LastName (Awayfighter)
AwayfighterLenght = string.len(AwayfighterLName)
AwayfighterOffset = (AwayfighterLenght * 6.5)/2
AwayfighterFName = Launcher.Player.FirstName (Awayfighter)
AwayfighterPhoto = Launcher.Player.Photo (Awayfighter)
AwayfighterPhoto4 = string.format ("%04d" , AwayfighterPhoto )
AwayfighterPhotoSprite =  Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..AwayfighterPhoto4..".jpg")
AwayfighterBalance = Launcher.Player.Balance (Awayfighter)
AwayfighterAggression = Launcher.Player.Aggression (Awayfighter)
if   HomefighterPhotoSprite == nil then
 HomefighterPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
elseif  AwayfighterPhotoSprite == nil then
AwayfighterPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
end
Odds = (AwayfighterAggression + AwayfighterBalance) - (HomefighterAggression + HomefighterBalance)
if Odds == 0
then
  Odds = "  --"
elseif Odds > 0 then
    Odds = "     >"
  else
      Odds = "<"
  end
  end
end

-- fighters overlay
if Launcher.Config.Int("Overlays",1) == 3 then
if Cutscenetype == 13 or Cutscenetype == 92 then
Launcher.Sprite.Draw(HomefighterPhotoSprite, PortraitX,PortraitY )
Launcher.Sprite.Draw(AwayfighterPhotoSprite, PortraitX+280,PortraitY )
 Launcher.Sprite.Clip(ClockSprite,XVSSPRITE,YVSSPRITE,WVSSPRITE,HVSSPRITE)
Launcher.Sprite.Draw(ClockSprite, GoalspriteX,GoalspriteY+6)
Launcher.Font.DrawText(ScoreFontM,HomeAbbreviation,PortraitX+108 ,GoalspriteY  +155,FontColor1)
Launcher.Font.DrawText(ScoreFontXS,HomefighterLName,PortraitX+39-HomefighterOffset ,GoalspriteY  +203,FontColor1)
Launcher.Font.DrawText(ScoreFontM,AwayAbbreviation,PortraitX+219 ,GoalspriteY  +155,FontColor1)
Launcher.Font.DrawText(ScoreFontXS,AwayfighterLName,PortraitX +327-AwayfighterOffset,GoalspriteY  +203,FontColor1)
Launcher.Font.DrawText(ScoreFontL,Odds,PortraitX+140 ,GoalspriteY  +168,FontColor1)
--elseif Cutscenetype == 93 then
--Launcher.Sprite.Draw(HomefighterPhotoSprite, PortraitX,PortraitY )
--Launcher.Sprite.Draw(GOALSprite, GoalspriteX,GoalspriteY )
--Launcher.Font.DrawText(ScoreFontM,HomefighterFName,GoalspriteX +160 ,GoalspriteY  +100,FontColor1)
--Launcher.Font.DrawText(ScoreFontL,HomefighterLName,GoalspriteX +160 ,GoalspriteY  +120,FontColor1)
--elseif Cutscenetype == 94 then
--Launcher.Sprite.Draw(AwayfighterPhotoSprite, PortraitX,PortraitY )
--Launcher.Sprite.Draw(GOALSprite, GoalspriteX,GoalspriteY )
--Launcher.Font.DrawText(ScoreFontM,AwayfighterFName,GoalspriteX +160 ,GoalspriteY  +100,FontColor1)
--Launcher.Font.DrawText(ScoreFontL,AwayfighterLName,GoalspriteX +160 ,GoalspriteY  +120,FontColor1)
end
end
-- Penalty to player overlay
if Cutscenetype == 79 then
  PPlayerHits = Launcher.Player.Hits (PPlayer2)
  PPlayerShots = Launcher.Player.Shots (PPlayer2)
  PPlayerPhoto = Launcher.Player.Photo (PPlayer2)
PPlayerPhoto4 = string.format ("%04d" , PPlayerPhoto )
PPlayerPhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..PPlayerPhoto4..".jpg")

   
if   PPlayerPhotoSprite == nil then
  PPlayerPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
end
if PTeam2 == 0 then
      Launcher.Sprite.Draw(HomePog,GoalspriteX +30 ,GoalspriteY  +30)
      else 
    
      Launcher.Sprite.Draw(AwayPog,GoalspriteX +30 ,GoalspriteY  +30)
     end
Launcher.Sprite.Draw(PPlayerPhotoSprite, PPortraitX,PPortraitY )

      Launcher.Sprite.Clip(ClockSprite,XPENSPRITE,YPENSPRITE,WPENSPRITE,HPENSPRITE)
				Launcher.Sprite.Draw(ClockSprite, PenspriteX, PenspriteY)
        if NameType == 1 and  Launcher.Config.Int("broadcaster",1) == 4 then  
          Launcher.Font.DrawText(ScoreFontL,string.sub(PPlayerFName2, 1, 1).." "..PPlayerLName2,PenspriteX+10 ,PenspriteY  +5,FontColor2)
          Launcher.Font.DrawText(ScoreFontL,PenaltyString2.." "..PTimeFormatted2,PenspriteX+355 ,PenspriteY  +5,FontColor2)
        elseif NameType == 1 and  Launcher.Config.Int("broadcaster",1) == 2 then
         Launcher.Font.DrawText(ScoreFontL,PPlayerFName2.." "..PPlayerLName2,PenspriteX+160 ,PenspriteY  +5,FontColor1)
          Launcher.Font.DrawText(ScoreFontM,PenaltyString2.." "..PTimeFormatted2,PenspriteX+160 ,PenspriteY  +40,FontColor1)
          --penalty team
          Launcher.Font.DrawText(StatsFontS,PTeamFName,GoalspriteX +700 ,GoalspriteY  +4,FontColor4)
          Launcher.Font.DrawText(ScoreFontS,"PENALTY TO PLAYER",GoalspriteX +700 ,GoalspriteY  +18,FontColor1)
          
         else
-- Launcher.Font.DrawText(ScoreFontS,"Penalty",GoalspriteX +140 ,GoalspriteY  +80,FontColor3)
Launcher.Font.DrawText(ScoreFontM,PPlayerFName2,GoalspriteX +140 ,GoalspriteY  +100,FontColor1)
Launcher.Font.DrawText(ScoreFontL,PPlayerLName2,GoalspriteX +140 ,GoalspriteY  +120,FontColor1)
Launcher.Font.DrawText(StatsFontS,PTeamFName2,GoalspriteX +140 ,GoalspriteY  +10,FontColor1)
Launcher.Font.DrawText(ScoreFontM,PenaltyString2,GoalspriteX +140 ,GoalspriteY  +170,FontColor1)
Launcher.Font.DrawText(ScoreFontL,PTimeFormatted2,GoalspriteX +140 ,GoalspriteY  +190,FontColor3)
Launcher.Font.DrawText(StatsFontS,"Hits: "..PPlayerHits,GoalspriteX +48 ,GoalspriteY  +195,FontColor1)
end
end
-- End game overlay
if Launcher.Config.Int("Overlays",1) == 3 or Launcher.Config.Int("Overlays",1) == 2 then
  if Cutscenetype == 30 or Cutscenetype == 32 or Cutscenetype == 34 or Cutscenetype == 35 or Cutscenetype == 9 then 
   
 HomeshortLength = string.len(tostring(HomeShortName))
  AwayshortLength = string.len(tostring(AwayShortName))
  LocationLength = string.len(tostring(ArenaLocation))
   ArenaLength = string.len(tostring(ArenaName))
  Launcher.Sprite.Clip(HomePog,0,0,90,64)
    Launcher.Sprite.Draw(HomePog, EndspriteX-88 + EndHPogoffset,EndspriteY+5)
     Launcher.Sprite.Clip(AwayPog,0,0,90,64)
  Launcher.Sprite.Draw(AwayPog, EndspriteX -8 + WENDSPRITE + EndAPogoffset,EndspriteY+5)
     Launcher.Sprite.Clip(ClockSprite,XENDSPRITE,YENDSPRITE,WENDSPRITE,HENDSPRITE)
  Launcher.Sprite.Draw(ClockSprite, EndspriteX,EndspriteY)
  
  
  Launcher.Font.DrawText(ScoreFontM,HomeShortName,EndspriteX + 15 + EndHPogoffset,EndspriteY  + 30,FontColor1)
   
  Launcher.Font.DrawText(ScoreFontM,AwayShortName,(EndspriteX + WENDSPRITE) - ((AwayshortLength *( SFontSize2/1.5)) + EndHPogoffset),EndspriteY  + 30,FontColor1)
if Cutscenetype == 9 then
  UArenaName = string.upper (ArenaName)
  UArenaLocation  = string.upper (ArenaLocation)
  Launcher.Font.DrawText(ScoreFontS,UArenaName.."-"..UArenaLocation,EndspriteX + ((WENDSPRITE/2)-((ArenaLength+LocationLength)/2)*(SFontSize3/2)),EndspriteY  + 1,FontColor1)
  Launcher.Font.DrawText(ScoreFontL,"VS",EndspriteX +((WENDSPRITE/2)-20),EndspriteY  + 20,FontColor2)
  else
  Launcher.Font.DrawText(ScoreFontL,HomeGoals.."-"..AwayGoals,EndspriteX +((WENDSPRITE/2)-30),EndspriteY  + 20,FontColor2)
  Launcher.Font.DrawText(ScoreFontM,ArenaName.."-"..ArenaLocation,EndspriteX +((WENDSPRITE/2)-(((ArenaLength+LocationLength+1)/2)*(SFontSize2/2))),EndspriteY  +HENDSPRITE-3,FontColor4)
  end
if AwayPog ~= nil then
Launcher.Sprite.Release(AwayPog)
    AwayPog = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/"..AwayAbbreviation..".png")
end
if HomePog ~= nil then
Launcher.Sprite.Release(HomePog)
HomePog = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/"..HomeAbbreviation..".png")
end
  if Cutscenetype == 32 or Cutscenetype == 30 then
    
    if Launcher.Config.Int("broadcaster",1) == 4 then
      Launcher.Font.DrawText(ScoreFontS,"ENDERGEBNIS",EndspriteX + ((WENDSPRITE/2)-80),EndspriteY  + 1,FontColor1)
    
    else
      Launcher.Sprite.Draw(HomePog,CenterscreenX -802 ,ClockY +133)
      Launcher.Sprite.Draw(AwayPog,CenterscreenX +398 ,ClockY +133)
     Launcher.Sprite.Draw(Statoverlay,CenterscreenX -832 ,ClockY +121)
      Launcher.Sprite.Draw(Statoverlay,CenterscreenX +368 ,ClockY +121)
      for i = 0, 17 do
    if Launcher.Player.Points (i) >= 2    then
      if Launcher.Player.Goals (i) >= 1
      then
        Launcher.Sprite.Draw(Redstat,CenterscreenX -538 ,ClockY +203+22*i)
      end
        if Launcher.Player.Assists (i) >= 1
      then
        Launcher.Sprite.Draw(Redstat,CenterscreenX -491 ,ClockY +203+22*i)
        end
      Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i), CenterscreenX -799 ,ClockY +200+22*i,FontColor6)
    else
      Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i), CenterscreenX -799 ,ClockY +200+22*i,FontColor2)
      end
   
   Launcher.Font.DrawText(StatsFontS,Launcher.Player.Goals (i), CenterscreenX -520 ,ClockY +202+22*i,FontColor1)
   Launcher.Font.DrawText(StatsFontS,Launcher.Player.Assists (i), CenterscreenX -475 ,ClockY +202+22*i,FontColor1)
   Launcher.Font.DrawText(StatsFontS,Launcher.Player.Shots (i), CenterscreenX -430 ,ClockY +202+22*i,FontColor1)
   Launcher.Font.DrawText(StatsFontS,Launcher.Player.Hits (i), CenterscreenX -385 ,ClockY +202+22*i,FontColor1)
end
for i = 18, 19 do
  
  Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (i).." "..Launcher.Player.LastName (i), CenterscreenX -799 ,ClockY +220+22*i,FontColor2)
  Launcher.Font.DrawText(StatsFontS,Launcher.Player.ShotsAgainst (i).." Shots Against", CenterscreenX -520 ,ClockY +220+22*i,FontColor1)

end

for k = 20, 37 do
 if Launcher.Player.Points (k) >= 2    then
      if Launcher.Player.Goals (k) >= 1
      then
        Launcher.Sprite.Draw(Redstat,CenterscreenX +662 ,ClockY +203+22*(k-20))
      end
        if Launcher.Player.Assists (k) >= 1
      then
        Launcher.Sprite.Draw(Redstat,CenterscreenX +709 ,ClockY +203+22*(k-20))
      end
       Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k), CenterscreenX +401 ,ClockY +200+22*(k-20),FontColor3)
    else
  Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k), CenterscreenX +401 ,ClockY +200+22*(k-20),FontColor2)
  end
  Launcher.Font.DrawText(StatsFontS,Launcher.Player.Goals (k), CenterscreenX +680 ,ClockY +202+22*(k-20),FontColor1)
  Launcher.Font.DrawText(StatsFontS,Launcher.Player.Assists (k), CenterscreenX +725 ,ClockY +202+22*(k-20),FontColor1)
  Launcher.Font.DrawText(StatsFontS,Launcher.Player.Shots (k), CenterscreenX +770 ,ClockY +202+22*(k-20),FontColor1)
  Launcher.Font.DrawText(StatsFontS,Launcher.Player.Hits (k), CenterscreenX +815 ,ClockY +202+22*(k-20),FontColor1)
  
end
for k = 38, 39 do
   
  Launcher.Font.DrawText(ScoreFontM,Launcher.Player.FirstName (k).." "..Launcher.Player.LastName (k), CenterscreenX +401 ,ClockY +220+22*(k-20),FontColor2)
  Launcher.Font.DrawText(StatsFontS,Launcher.Player.ShotsAgainst (k).." Shots Against", CenterscreenX +680 ,ClockY +220+22*(k-20),FontColor1)
  
end
       Launcher.Font.DrawText(ScoreFontS,"GAME COMPLETED",EndspriteX +((WENDSPRITE/2)-85),EndspriteY  + 1,FontColor1)
        Launcher.Font.DrawText(ScoreFontS,"FINAL",EndspriteX +((WENDSPRITE/2)-30),EndspriteY  + 80,FontColor1)
         Launcher.Font.DrawText(StatsFontS,"Goals: "..HP1Goals.."/"..HP2Goals.."/"..HP3Goals,EndspriteX-80 + EndHPogoffset,EndspriteY  + 120,FontColor1)
        Launcher.Font.DrawText(StatsFontS,"Shots: "..HP1Shots.."/"..HP2Shots.."/"..HP3Shots,EndspriteX-80 + EndHPogoffset,EndspriteY  + 145,FontColor1)
        
        Launcher.Font.DrawText(StatsFontS,"Goals: "..AP1Goals.."/"..AP2Goals.."/"..AP3Goals,EndspriteX + WENDSPRITE + EndAPogoffset-50,EndspriteY  + 120,FontColor1)
         Launcher.Font.DrawText(StatsFontS,"Shots: "..AP1Shots.."/"..AP2Shots.."/"..AP3Shots,EndspriteX + WENDSPRITE + EndAPogoffset-50,EndspriteY  + 145,FontColor1)
         
      end
    end
    if Cutscenetype == 34 then
      PerHGoals = Launcher.PeriodStats.GoalsHome(Period3)
      PerAGoals = Launcher.PeriodStats.GoalsAway(Period3)
      PerHShots = Launcher.PeriodStats.ShotsHome(Period3)
      PerAShots = Launcher.PeriodStats.ShotsAway(Period3)
   if Launcher.Config.Int("broadcaster",1) == 4 then

    else   
    Launcher.Font.DrawText(ScoreFontS,"INTERMISSION "..Period2,EndspriteX +((WENDSPRITE/2)-60),EndspriteY  + 80,FontColor1)
     Launcher.Font.DrawText(ScoreFontM,"Goals: "..PerHGoals,EndspriteX-80 + EndHPogoffset,EndspriteY  + 115,FontColor1)
        Launcher.Font.DrawText(ScoreFontM,"Shots: "..PerHShots,EndspriteX-80 + EndHPogoffset,EndspriteY  + 145,FontColor1)
        
        Launcher.Font.DrawText(ScoreFontM,"Goals: "..PerAGoals,EndspriteX + WENDSPRITE + EndAPogoffset-50,EndspriteY  + 115,FontColor1)
         Launcher.Font.DrawText(ScoreFontM,"Shots: "..PerAShots,EndspriteX + WENDSPRITE + EndAPogoffset-50,EndspriteY  + 145,FontColor1)
     end
     end
  end
  end
-- random players overlay
 if Launcher.Config.Int("Overlays",1) == 5 then
   if Cutscenetype == 20 or Cutscenetype == 21 or Cutscenetype == 22 or Cutscenetype == 24  then

    local RandH = RandHome
    local RandA = RandAway
   RandHomePlayerPhoto = Launcher.Player.Photo (RandH)
   RandHomePlayerLName = Launcher.Player.LastName (RandH)
   RandHomePlayerLenght = string.len(RandHomePlayerLName)
RandHomePlayerOffset = (RandHomePlayerLenght * 6.5)/2
   RandHomePlayerShots = Launcher.Player.Shots (RandH)
   RandHomePlayerHits = Launcher.Player.Hits (RandH)
   RandHomePlayerGoals = Launcher.Player.Goals (RandH)
   RandHomePlayerPlus = Launcher.Player.PlusMinus (RandH)
   --  If  RandHomePlayerPlus > 0 then RandHomePlayerPlus = "+"..RandHomePlayerPlus
   --  end
   RandHomePlayerPhoto4 = string.format ("%04d" , RandHomePlayerPhoto )
RandHomePlayerPhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..RandHomePlayerPhoto4..".jpg")
   
   RandAwayPlayerPhoto = Launcher.Player.Photo (RandA)
   RandAwayPlayerLName = Launcher.Player.LastName (RandA)
    RandAwayPlayerLenght = string.len(RandAwayPlayerLName)
RandAwayPlayerOffset = (RandAwayPlayerLenght * 6.5)/2
   RandAwayPlayerShots = Launcher.Player.Shots (RandA)
   RandAwayPlayerHits = Launcher.Player.Hits (RandA)
   RandAwayPlayerGoals = Launcher.Player.Goals (RandA)
   RandAwayPlayerPlus = Launcher.Player.PlusMinus (RandA)
  -- If  RandAwayPlayerPlus > 0 then RandAwayPlayerPlus = "+"..RandAwayPlayerPlus
    -- end
    RandAwayPlayerPhoto4 = string.format ("%04d" , RandAwayPlayerPhoto )
RandAwayPlayerPhotoSprite = Launcher.Sprite.Load("fe/nhl/images2/faces/med/"..RandAwayPlayerPhoto4..".jpg")

if   RandHomePlayerPhotoSprite == nil then
  RandHomePlayerPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
end

   if   RandAwayPlayerPhotoSprite == nil then
  RandAwayPlayerPhotoSprite = Launcher.Sprite.Load("launcher/media/textures/Broadcasts/pogs_C/player.png")
end

Launcher.Sprite.Draw(RandHomePlayerPhotoSprite, PortraitX,PortraitY )
Launcher.Sprite.Draw(RandAwayPlayerPhotoSprite, PortraitX+280,PortraitY )
 Launcher.Sprite.Clip(ClockSprite,XVSSPRITE,YVSSPRITE,WVSSPRITE,HVSSPRITE)
Launcher.Sprite.Draw(ClockSprite, GoalspriteX,GoalspriteY+6)
Launcher.Font.DrawText(ScoreFontM,RandAwayPlayerShots.."/"..RandAwayPlayerGoals,PortraitX+118 ,GoalspriteY  +90,FontColor1)
Launcher.Font.DrawText(ScoreFontM,RandHomePlayerPlus,PortraitX+121 ,GoalspriteY  +152,FontColor1)
Launcher.Font.DrawText(ScoreFontM,HomeAbbreviation,PortraitX+108 ,GoalspriteY  +178,FontColor1)
Launcher.Font.DrawText(ScoreFontXS,RandHomePlayerLName,PortraitX+39-RandHomePlayerOffset,GoalspriteY  +203,FontColor1)
Launcher.Font.DrawText(ScoreFontM,RandAwayPlayerShots.."/"..RandAwayPlayerGoals,PortraitX+219 ,GoalspriteY  +90,FontColor1)
Launcher.Font.DrawText(ScoreFontM,RandAwayPlayerPlus,PortraitX+229 ,GoalspriteY  +152,FontColor1)
Launcher.Font.DrawText(ScoreFontM,AwayAbbreviation,PortraitX+219 ,GoalspriteY  +178,FontColor1)
Launcher.Font.DrawText(ScoreFontXS,RandAwayPlayerLName,PortraitX +327-RandAwayPlayerOffset,GoalspriteY  +203,FontColor1)

   
 end
 end
end
--if HomefighterPhotoSprite ~= nil then
 --Launcher.Sprite.Release(HomefighterPhotoSprite)
--end
 --if AwayfighterPhotoSprite ~= nil then
  --Launcher.Sprite.Release(AwayfighterPhotoSprite)
--end
	if Launcher.Game.InCutscene() or Launcher.Game.IsShootout() or Launcher.Game.InReplay() then

		return
	end
	
	

	Launcher.Sprite.Draw(SurfaceSprite,0,0)
	
    
end

function PenaltyCallback(Index)
    local PPlayer = Launcher.Game.PenaltyPlayer(Index)
    local PTeam = Launcher.Game.PenaltyTeam(Index)
    local PenaltyID = Launcher.Game.PenaltyID(Index)
    local PTime = Launcher.Game.PenaltyTime(Index)
    local PPlayerFName = Launcher.Player.FirstName(PPlayer)
    local PPlayerLName = Launcher.Player.LastName(PPlayer) 
-- drgullen chaange started
    local PTimeFormatted = Launcher.Util.FormatTime(PTime)
-- drgullen chaange ended
	local PTeamName
    if PTeam == 0 then
        PTeamName = Launcher.Game.HomeNameAbbreviation()
        PTeamFName = Launcher.Game.HomeFullName()
    else
        PTeamName = Launcher.Game.AwayNameAbbreviation()
        PTeamFName = Launcher.Game.AwayFullName()
    end
   
    if PenaltyTextLookup[PenaltyID] == nil then
        PenaltyString = "unknown ("..PenaltyID..")"
    else
        PenaltyString = PenaltyTextLookup[PenaltyID]
    end
-- drgullen chaange started
	if PTime > 480 then
		PTimeFormatted = "(Game Misconduct)"
	elseif PTime == 480 then
		PTimeFormatted = "5:00"
	end
  -- drgullen change ended
PPlayer2 = PPlayer
PPlayerFName2 = PPlayerFName
PPlayerLName2 = PPlayerLName
PenaltyString2 = PenaltyString
PTimeFormatted2 = PTimeFormatted
PTeamFName2 = PTeamFName
PTeam2 = PTeam
end
function TickCallback()
    local HomeGoals, AwayGoals, Period, Minutes, Seconds, PowerPlayTime, Time, PenaltyTeam, PenaltyPendingTeam, PowerPlayTeam

	if Launcher.Game.InCutscene() or Launcher.Game.IsShootout() or Launcher.Game.InReplay() then
		return
	end

    
	Launcher.Screen.SetRenderTarget(1,SurfaceSprite)

	
	if Launcher.Screen.BeginScene() then
  Launcher.Screen.Clear(0)
		-- First, let's make sure we're not in a cutscene or the pause menu
       RandHome = math.random(0,17)
   RandAway = math.random(20,37)
		-- We can draw the home and away pogs at the bottom
    
    if Launcher.Config.Int("broadcaster",1) == 4  then
      --pogs
      Launcher.Sprite.Draw(HomePog, ClockX, ClockY+48)
		Launcher.Sprite.Draw(AwayPog, ClockX, ClockY+112)
    --and clock
    	Launcher.Sprite.Clip(ClockSprite,0,0,WCLOCKSPRITE,HCLOCKSPRITE)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)
    -- and abreviations
   Launcher.Font.DrawText(ClockFont,HomeAbbreviation,ClockX + 100,ClockY+52,FontColor2)
   Launcher.Font.DrawText(ClockFont,AwayAbbreviation,ClockX + 100,ClockY+119,FontColor2)
     if Launcher.Clock.Shown() and not Launcher.Game.PenaltyPending()  then 
   		Launcher.Sprite.Clip(ClockSprite,824,216 +((Launcher.Config.Int("events",1)-1)*128),300,128)
		Launcher.Sprite.Draw(ClockSprite, EventoffsetX, ClockY + EventoffsetY)
    end
  elseif Launcher.Config.Int("broadcaster",1) == 2  then
  Launcher.Sprite.Clip(ClockSprite,0,0,WCLOCKSPRITE,HCLOCKSPRITE)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)
    if Launcher.Clock.Shown() and not Launcher.Game.PenaltyPending()  then 
    	Launcher.Sprite.Clip(ClockSprite,724,216 +((Launcher.Config.Int("events",1)-1)*128),300,128)
		Launcher.Sprite.Draw(ClockSprite, EventoffsetX, ClockY + EventoffsetY)
    end
  
  else
      --Pogs
		Launcher.Sprite.Draw(HomePog, ClockX+479, ClockY)
		Launcher.Sprite.Draw(AwayPog, ClockX+215, ClockY)
		
		-- Clipping the sprite means you only draw a portion of the image
		-- This allows you to store multiple images in one image file, like a tileset
		-- Our base image is 64 pixels high. The fist 32 is our background, the next 32 is our foreground for the overlap effect on top of the pog      
		-- So in this case, we tell the game to draw the sprite from 0, 0 to 1024, 64 THE CLOCK
		Launcher.Sprite.Clip(ClockSprite,0,0,WCLOCKSPRITE,HCLOCKSPRITE)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)

   if Launcher.Clock.Shown() and not Launcher.Game.PenaltyPending()  then  
  Launcher.Sprite.Clip(ClockSprite,724,216 +((Launcher.Config.Int("events",1)-1)*128),300,128)
		Launcher.Sprite.Draw(ClockSprite,EventoffsetX, ClockY-20)
    end
end

    
    -- Now it's time to draw some basic game information
		-- First, let's store some of the information into local variables
		-- A local variable only exists in the current function. A global variable can be accessed from all functions
		-- By default, all variables are global. To make them local, simply add "local" before the declaration
		-- The next three lines retrieves the goals for each team and the current period
		HomeGoals = Launcher.Stats.HomeGoals()
		AwayGoals = Launcher.Stats.AwayGoals()
    HomePPGoals = Launcher.Stats.HomePowerPlayGoals ()
    AwayPPGoals = Launcher.Stats.AwayPowerPlayGoals ()
    HomeSHGoals = Launcher.Stats.HomeShortHandedGoals ()
     AwaySHGoals = Launcher.Stats.AwayShortHandedGoals ()
    HomeShots = Launcher.Stats.HomeShots()
    AwayShots = Launcher.Stats.AwayShots()
     HomePass = Launcher.Stats.HomePasses()
    AwayPass = Launcher.Stats.AwayPasses()
    HomePassAtt = Launcher.Stats.HomePassAttempts ()
    AwayPassAtt = Launcher.Stats.AwayPassAttempts ()
   HomeHits = Launcher.Stats.HomeHits ()
   AwayHits = Launcher.Stats.AwayHits ()

    HomePIM =  math.floor (Launcher.Stats.HomePIM () / 60)
   AwayPIM = math.floor (Launcher.Stats.AwayPIM () / 60)
		Period = Launcher.Game.Period()
    Suffixe =" "
		

		
		-- Let's create a nice string representation of the period
  
 if Launcher.Config.Int("broadcaster",1) == 4 then
    Suffixe = "/3"
      if Period == 1 then
			Period = "1"
		elseif Period == 2 then
			Period = "2"
		elseif Period == 3 then
			Period = "3"
		elseif Period > 3 then
      Suffixe = " "
			Period = "OT"
		end
    else
		if Period == 1 then
			Period = "1st"
		elseif Period == 2 then
			Period = "2nd"
		elseif Period == 3 then
			Period = "3rd"
		elseif Period > 3 then
			Period = "OT"
		end
    end
		

		
	-- Icing/Offside is pending
		if Launcher.Game.Warning() == 1 then
      if Launcher.Config.Int("broadcaster",1) == 4 then
         Launcher.Sprite.Clip(ClockSprite,295,96,384,48)
       
			Launcher.Sprite.Draw(ClockSprite, ClockX + 293, ClockY)
        else
			Launcher.Sprite.Clip(ClockSprite,738,64,286,32)
			Launcher.Sprite.Draw(ClockSprite, ClockX + 738, ClockY + 64)
      end
		elseif Launcher.Game.Warning() == 2 then
      if Launcher.Config.Int("broadcaster",1) == 4 then
         Launcher.Sprite.Clip(ClockSprite,295,48,384,48)
			Launcher.Sprite.Draw(ClockSprite, ClockX + 293, ClockY)
        else
			Launcher.Sprite.Clip(ClockSprite,738,96,286,32)
			Launcher.Sprite.Draw(ClockSprite, ClockX + 738, ClockY + 64)
		end
end


	-- Penalty is pending
		if Launcher.Game.PenaltyPending() then
      PenaltyPendingTeam = Launcher.Game.PenaltyPendingTeam()
      if Launcher.Config.Int("broadcaster",1) == 4 then
        if PenaltyPendingTeam == 0 then
          PenaltyPendingABR = HomeAbbreviation
          
        else
           PenaltyPendingABR = AwayAbbreviation
           
          end
          Launcher.Sprite.Clip(ClockSprite,295,0,384,48)
			Launcher.Sprite.Draw(ClockSprite, ClockX + 293, ClockY)
      	Launcher.Font.DrawText(ClockFontPP2,PenaltyPendingABR,ClockX + 602,ClockY+3,FontColor4)
      elseif Launcher.Config.Int("broadcaster",1) == 2 then
        
        else
						if PenaltyPendingTeam == 0 then
				Launcher.Sprite.Clip(ClockSprite,475,64,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 476, ClockY + 64)
			else
				Launcher.Sprite.Clip(ClockSprite,475,64,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 212, ClockY + 64)
			end
      end
 		end

	-- POWERPLAY
		
		-- The next line retrieves the PP time in seconds
		local PowerPlayTime = Launcher.Game.PowerplayTime()
		if PowerPlayTime > 0 then
			PowerPlayTeam = Launcher.Game.PowerplayTeam()
      if Launcher.Config.Int("broadcaster",1) == 4 then
      Launcher.Sprite.Clip(ClockSprite,0,176,295,40)
				Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY+176)
        if PowerPlayTeam == 1 then 
        Launcher.Font.DrawText(ClockFontPP2,"5 VS 4",ClockX + 40,ClockY + 181,FontColor2)  
        else 
          Launcher.Font.DrawText(ClockFontPP2,"4 VS 5",ClockX + 40,ClockY + 181,FontColor2)   
          end
        elseif Launcher.Config.Int("broadcaster",1) == 2 then
        Launcher.Sprite.Clip(ClockSprite,270,0,75,75)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 270, ClockY)
        else 
			if PowerPlayTeam == 1 then
				Launcher.Sprite.Clip(ClockSprite,475,96,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 476, ClockY + 64)
			else
				Launcher.Sprite.Clip(ClockSprite,475,96,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 212, ClockY + 64)
			end
      end





			
			-- Lets convert these seconds into minutes and seconds
			-- For minutes, simply divide by 60 and round down
			Minutes = math.floor(PowerPlayTime/60)
			if Minutes < 10 then
				-- let's pad a zero if it's 9 or less so it looks nicer
				local Minutes = "0"..Minutes
			end
			
			-- % is modulo. Modulo means the remainder of a division
			-- So in our case, the remainder of dividing the time by 60 would be the seconds component
			Seconds = PowerPlayTime % 60
			if Seconds < 10 then
				-- let's pad a zero if it's 9 or less so it looks nicer
				Seconds = "0"..Seconds
			end 
       
      if Launcher.Config.Int("broadcaster",1) == 4 then
            Launcher.Font.DrawText(ClockFontPP2," "..Minutes..":"..Seconds,ClockX + 205,ClockY + 181,FontColor4)
        elseif Launcher.Config.Int("broadcaster",1) == 2 then
          Launcher.Font.DrawText(ClockFontPP2," "..Minutes..":"..Seconds,ClockX + 270,ClockY + 40,FontColor4)
          else
			if PowerPlayTeam == 0 then
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + PPHXoffset,ClockY + 65,FontColor1)
			else
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + PPAXoffset,ClockY + 65,FontColor1)
			end
     end
		end

	-- Now we can render all of the information to the screen using the DrawText function.

		-- The next line retrieves the game time in seconds
		Time = Launcher.Game.Time()
		
		-- Lets convert these seconds into minutes and seconds
		-- For minutes, simply divide by 60 and round down
		Minutes = math.floor(Time/60)
		if Minutes < 10 then
			-- let's pad a zero if it's 9 or less so it looks nicer
			Minutes = "0"..Minutes
		end
		
		-- % is modulo. Modulo means the remainder of a division
		-- So in our case, the remainder of dividing the time by 60 would be the seconds component
		Seconds = Time % 60
		if Seconds < 10 then
			-- let's pad a zero if it's 9 or less so it looks nicer
			Seconds = "0"..Seconds
		end
    if Launcher.Config.Int("broadcaster",1) == 1 then
  Launcher.Font.DrawText(ClockFont,AwayGoals,450,ClockY+6,FontColor1)
	Launcher.Font.DrawText(ClockFont,HomeGoals,710,ClockY+6,FontColor1)
  
Launcher.Font.DrawText(ClockFont,Period.."   "..Minutes..":"..Seconds,ClockX + 770,ClockY + 6,FontColor2)  
end
if Launcher.Config.Int("broadcaster",1) == 4 then
  Launcher.Font.DrawText(ClockFont,HomeGoals,ClockX + 250,ClockY+53,FontColor1)
		Launcher.Font.DrawText(ClockFont,AwayGoals,ClockX + 250,ClockY+119,FontColor1)
		Launcher.Font.DrawText(ClockFont," "..Period.."     "..Minutes..":"..Seconds,ClockX+15,ClockY,FontColor1)
    Launcher.Font.DrawText(ScoreFontM,Suffixe,ClockX+50,ClockY+16,FontColor1)

    if not Launcher.Clock.Shown() and not Launcher.Game.PenaltyPending()  then 
      Launcher.Sprite.Clip(ClockSprite,681,0,280,172)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 293, ClockY)
     Launcher.Font.DrawText(ClockFontS,"SCHÜSSE",ClockX + 340,ClockY+5,FontColor1)   
     Launcher.Font.DrawText(ClockFontS,HomeShots,ClockX + 430,ClockY+55,FontColor2)
		Launcher.Font.DrawText(ClockFontS,AwayShots,ClockX + 430,ClockY+123,FontColor2)  
      end
  
elseif Launcher.Config.Int("broadcaster",1) == 3 then 
      Launcher.Font.DrawText(ClockFont,HomeAbbreviation,ClockX + HomeGoalsX - 111,ClockY+5,FontColor1)
    Launcher.Font.DrawText(ClockFont,AwayAbbreviation,ClockX + AwayGoalsX - 111,ClockY+5,FontColor1)
     	Launcher.Font.DrawText(ClockFontB,HomeGoals,ClockX + HomeGoalsX,ClockY,FontColor1)
		Launcher.Font.DrawText(ClockFontB,AwayGoals,ClockX + AwayGoalsX,ClockY,FontColor1)
		Launcher.Font.DrawText(ClockFont,Period.."   "..Minutes..":"..Seconds,ClockX + TimeX,ClockY + 6,FontColor2)
    
      
	local PowerPlayTime = Launcher.Game.PowerplayTime()
elseif Launcher.Config.Int("broadcaster",1) == 1 then
  if not Launcher.Clock.Shown() then
      Launcher.Sprite.Clip(ClockSprite,607,143,261,40)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 347, ClockY-40)
          Launcher.Font.DrawText(ClockFontS,AwayShots,ClockX + 359,ClockY-39,FontColor2)
		Launcher.Font.DrawText(ClockFontS,HomeShots,ClockX + 557,ClockY-39,FontColor2)
    end
    
  elseif Launcher.Config.Int("broadcaster",1) == 2 then
    	Launcher.Font.DrawText(ScoreFontL,HomeAbbreviation.." "..HomeGoals,ClockX + 15,ClockY+35,FontColor1)
		Launcher.Font.DrawText(ScoreFontL,AwayAbbreviation.." "..AwayGoals,ClockX +155, ClockY+35,FontColor1)
    Launcher.Font.DrawText(ScoreFontM,Period,ClockX + 40,ClockY,FontColor1)
    Launcher.Font.DrawText(ScoreFontM,Minutes..":"..Seconds,ClockX + 160,ClockY,FontColor1)
      Launcher.Font.DrawText(ScoreFontS,HomeShots,ClockX + 15,ClockY+72,FontColor1)
		   Launcher.Font.DrawText(ScoreFontS,AwayShots,ClockX + 240,ClockY+72,FontColor1) 
       if not Launcher.Clock.Shown()  and PowerPlayTime == 0 and HomeShots > 1 and AwayShots > 1   then
         HomePassEff = math.floor((HomePass/HomePassAtt)*100)
         AwayPassEff = math.floor((AwayPass/AwayPassAtt)*100)
         if HomePassAtt == 0 then
           HomePassEff = "-"
         end
         if AwayPassAtt == 0 then
           AwayPassEff = "-"
         end
         if  HomegoalieSA ==nil or AwaygoalieSA== nil then
  HomeSavespercent = 0
  AwaySavespercent = 0
  else
HomeSavespercent = (HomegoalieSA-AwayGoals)/HomegoalieSA
AwaySavespercent = (AwaygoalieSA-HomeGoals)/AwaygoalieSA
HomeSavespercent2 = string.format("%.3f",HomeSavespercent)
AwaySavespercent2 = string.format("%.3f",AwaySavespercent)
end 
if HomeSavespercent2 == nil then
  HomeSavespercent2 ="-.---"
  
end
if tostring (HomeSavespercent2) == 'nan' then
  HomeSavespercent2 ="     "
  end
if AwaySavespercent2 == nil then
  AwaySavespercent2 ="-.---"
end
if tostring (AwaySavespercent2) == 'nan' then
  AwaySavespercent2 ="     "
  end
        Launcher.Sprite.Clip(ClockSprite,340,0,400,75)
				Launcher.Sprite.Draw(ClockSprite, ClockX + WCLOCKSPRITE, ClockY)
         Launcher.Font.DrawText(ScoreFontS,HomeAbbreviation,ClockX + 300,ClockY+10,FontColor1)
       Launcher.Font.DrawText(ScoreFontS,HomePassEff.."%   "..HomeSavespercent2.."    "..HomePPGoals.."      "..HomeSHGoals.."      "..HomeHits.."     "..HomePIM,ClockX + 352,ClockY+10,FontColor1)
       Launcher.Font.DrawText(ScoreFontS,AwayAbbreviation,ClockX + 300,ClockY+45,FontColor1) 
		   Launcher.Font.DrawText(ScoreFontS,AwayPassEff.."%   "..AwaySavespercent2.."    "..AwayPPGoals.."      "..AwaySHGoals.."      "..AwayHits.."     "..AwayPIM,ClockX + 352,ClockY+45,FontColor1)    
     -- elseif Launcher.Config.Int("broadcaster",1) == 1 then
    -- Launcher.Font.DrawText(ClockFont,HomeAbbreviation,ClockX + HomeGoalsX - 111,ClockY+2,FontColor1)
   -- Launcher.Font.DrawText(ClockFont,AwayAbbreviation,ClockX + AwayGoalsX - 111,ClockY+5,FontColor1)
   --  	Launcher.Font.DrawText(ClockFont,HomeGoals,HomeGoalsX,ClockY,FontColor1)
	--	Launcher.Font.DrawText(ClockFont,AwayGoals,HomeGoalsX,ClockY,FontColor1)
	--	Launcher.Font.DrawText(ClockFont,Period.."   "..Minutes..":"..Seconds,ClockX + 500,ClockY + 6,FontColor2)
  
    --if not Launcher.Clock.Shown() then
      --  Launcher.Sprite.Clip(ClockSprite,605,140,265,42)
			--	Launcher.Sprite.Draw(ClockSprite, ClockX + 350, ClockY - 40)
      -- Launcher.Font.DrawText(ClockFontS,AwayShots,ClockX + 365,ClockY-37,FontColor2)
		  -- Launcher.Font.DrawText(ClockFontS,HomeShots,ClockX + 562,ClockY-37,FontColor2)    
   --   end 
  
       
       
    end


    
        Launcher.Screen.EndScene()		
	end
	Launcher.Screen.ResetRenderTarget()	
end
end



-- ************ CALLBACK DEFINITIONS ************ 

-- Callbacks are functions we define that will be called if an in-game event happens
-- There are many kinds of callbacks, but for our case we only need Render and DeviceCreated
-- Render is called every time a frame is rendered
-- DeviceCreated is called right after creating the D3D device, which is right before the in-game loading screen
-- The DeviceCreated callback function is where we load our assets
-- The Render callback function is where we draw everything

Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
Launcher.Callback.Register("RenderBackground",RenderCallback)
Launcher.Callback.Register("ShotHome",ShotCallback)
Launcher.Callback.Register("Penalty",PenaltyCallback)
Launcher.Callback.Register("ShotAway",ShotCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)

